// WA Panel - Pterodactyl Style
class WAPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.scripts = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadScripts();
        this.updateDashboardStats();
        this.setupNavigation();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.getAttribute('href').substring(1);
                this.showSection(section);
            });
        });

        // Sidebar toggle
        document.querySelector('.sidebar-toggle').addEventListener('click', () => {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Upload forms
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.uploadScript(e.target);
        });

        document.getElementById('modalUploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.uploadScript(e.target);
        });

        // System update form
        document.getElementById('updateForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSystemUpdate(e.target);
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.hideAllModals();
            });
        });

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.hideAllModals();
                }
            });
        });

        // File upload styling
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const label = e.target.nextElementSibling;
                    label.querySelector('span').textContent = file.name;
                }
            });
        });
    }

    setupNavigation() {
        // Set active nav item
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('section').forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionName;
        }

        // Update page title
        const pageTitle = document.querySelector('.page-title');
        switch(sectionName) {
            case 'dashboard':
                pageTitle.textContent = 'Dashboard';
                break;
            case 'scripts':
                pageTitle.textContent = 'Script Management';
                break;
            case 'upload':
                pageTitle.textContent = 'Upload Script';
                break;
            case 'logs':
                pageTitle.textContent = 'System Logs';
                break;
            case 'system':
                pageTitle.textContent = 'System Management';
                break;
        }

        // Load section-specific content
        if (sectionName === 'scripts') {
            this.renderScriptsTable();
        } else if (sectionName === 'dashboard') {
            this.updateDashboardStats();
            this.renderRecentScripts();
        } else if (sectionName === 'system') {
            this.refreshSystemStatus();
        }
    }

    async loadScripts() {
        try {
            const response = await fetch('/api/scripts');
            this.scripts = await response.json();
            this.updateDashboardStats();
            this.renderRecentScripts();
        } catch (error) {
            console.error('Failed to load scripts:', error);
        }
    }

    updateDashboardStats() {
        const running = this.scripts.filter(s => s.status === '🟢 Online').length;
        const stopped = this.scripts.filter(s => s.status === 'stopped').length;
        const tested = this.scripts.filter(s => s.testResult === '✅ OK').length;
        const errors = this.scripts.filter(s => s.testResult === '❌ ERROR').length;

        document.getElementById('runningScripts').textContent = running;
        document.getElementById('stoppedScripts').textContent = stopped;
        document.getElementById('testedScripts').textContent = tested;
        document.getElementById('errorScripts').textContent = errors;
    }

    renderRecentScripts() {
        const container = document.getElementById('recentScriptsList');
        const recentScripts = this.scripts.slice(0, 5); // Show last 5 scripts

        if (recentScripts.length === 0) {
            container.innerHTML = '<p style="color: #9ca3af; text-align: center; padding: 2rem;">No scripts uploaded yet</p>';
            return;
        }

        container.innerHTML = recentScripts.map(script => `
            <div class="script-item">
                <div>
                    <div style="font-weight: 600; color: #f3f4f6;">${script.name}</div>
                    <div style="font-size: 0.875rem; color: #9ca3af;">${script.command}</div>
                </div>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                    <div class="action-buttons">
                        <button class="btn-sm btn-info" onclick="waPanel.showLog('${script.name}')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderScriptsTable() {
        const tbody = document.querySelector('#scriptsTable tbody');
        
        if (this.scripts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #9ca3af;">No scripts found</td></tr>';
            return;
        }

        tbody.innerHTML = this.scripts.map(script => `
            <tr>
                <td>
                    <div style="font-weight: 600; color: #f3f4f6;">${script.name}</div>
                    <div style="font-size: 0.75rem; color: #9ca3af;">${script.folder}</div>
                </td>
                <td style="font-family: monospace; font-size: 0.875rem;">${script.command}</td>
                <td>
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                </td>
                <td>
                    <span class="status-badge ${script.testResult === '✅ OK' ? 'running' : 'error'}">${script.testResult}</span>
                </td>
                <td style="font-size: 0.875rem; color: #9ca3af;">Just now</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-sm btn-success" onclick="waPanel.startScript('${script.name}')" title="Start">
                            <i class="fas fa-play"></i>
                        </button>
                        <button class="btn-sm btn-warning" onclick="waPanel.stopScript('${script.name}')" title="Stop">
                            <i class="fas fa-pause"></i>
                        </button>
                        <button class="btn-sm btn-info" onclick="waPanel.restartScript('${script.name}')" title="Restart">
                            <i class="fas fa-redo"></i>
                        </button>
                        <button class="btn-sm btn-info" onclick="waPanel.showLog('${script.name}')" title="View Log">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-sm btn-secondary" onclick="waPanel.showTerminal('${script.name}')" title="Terminal">
                            <i class="fas fa-terminal"></i>
                        </button>
                        <button class="btn-sm btn-secondary" onclick="waPanel.showFileViewer('${script.name}')" title="Files">
                            <i class="fas fa-folder"></i>
                        </button>
                        <button class="btn-sm btn-danger" onclick="waPanel.deleteScript('${script.name}')" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getStatusClass(status) {
        if (status === '🟢 Online') return 'running';
        if (status === 'stopped') return 'stopped';
        return 'error';
    }

    async uploadScript(form) {
        const formData = new FormData(form);
        const resultDiv = form.id === 'modalUploadForm' ? 
            document.getElementById('modalUploadResult') : 
            document.getElementById('uploadResult');

        try {
            console.log('Starting script upload...');
            resultDiv.textContent = 'Uploading script...';
            resultDiv.className = 'upload-result';

            // Validate form data
            const name = formData.get('name');
            const command = formData.get('command');
            const file = formData.get('file');

            console.log('Form data:', { name, command, file: file ? file.name : 'no file' });

            if (!name || !command || !file) {
                resultDiv.textContent = 'Please fill all required fields';
                resultDiv.className = 'upload-result error';
                return;
            }

            if (!file.name.endsWith('.js') && !file.name.endsWith('.zip')) {
                resultDiv.textContent = 'Please select a .js or .zip file';
                resultDiv.className = 'upload-result error';
                return;
            }

            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            console.log('Upload response status:', response.status);

            if (!response.ok) {
                const errorText = await response.text();
                console.error('Upload failed:', errorText);
                resultDiv.textContent = `Upload failed: ${response.status} ${response.statusText}`;
                resultDiv.className = 'upload-result error';
                return;
            }

            const result = await response.json();
            console.log('Upload result:', result);

            resultDiv.textContent = result.message;
            resultDiv.className = 'upload-result success';
            form.reset();
            this.loadScripts();

            if (form.id === 'modalUploadForm') {
                setTimeout(() => this.hideUploadModal(), 2000);
            }
        } catch (error) {
            console.error('Upload error:', error);
            resultDiv.textContent = 'Upload failed: ' + error.message;
            resultDiv.className = 'upload-result error';
        }
    }

    async startScript(name) {
        try {
            const response = await fetch('/api/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to start script', 'error');
        }
    }

    async stopScript(name) {
        try {
            const response = await fetch('/api/stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to stop script', 'error');
        }
    }

    async restartScript(name) {
        try {
            const response = await fetch('/api/restart', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to restart script', 'error');
        }
    }

    async deleteScript(name) {
        if (!confirm('Are you sure you want to delete this script?')) return;
        
        try {
            const response = await fetch('/api/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to delete script', 'error');
        }
    }

    async showLog(name) {
        try {
            const response = await fetch(`/api/log/${name}`);
            const result = await response.json();
            
            document.getElementById('logContent').textContent = result.log || 'No logs available';
            this.showModal('logModal');
        } catch (error) {
            this.showNotification('Failed to load logs', 'error');
        }
    }

    showUploadModal() {
        this.showModal('uploadModal');
    }

    hideUploadModal() {
        this.hideModal('uploadModal');
    }

    hideLogModal() {
        this.hideModal('logModal');
    }

    showModal(modalId) {
        document.getElementById(modalId).classList.add('active');
    }

    hideModal(modalId) {
        document.getElementById(modalId).classList.remove('active');
    }

    hideAllModals() {
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.classList.remove('active');
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            color: white;
            font-weight: 500;
            z-index: 3000;
            animation: slideIn 0.3s ease;
            ${type === 'success' ? 'background: #10b981;' : 'background: #ef4444;'}
        `;

        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    refreshAll() {
        this.loadScripts();
        this.showNotification('Refreshed all data', 'success');
    }

    async refreshSystemStatus() {
        try {
            const response = await fetch('/api/update-status');
            const status = await response.json();
            
            document.getElementById('systemVersion').textContent = status.version;
            document.getElementById('systemUptime').textContent = this.formatUptime(status.serverUptime);
            document.getElementById('lastUpdate').textContent = new Date(status.lastUpdate).toLocaleString();
            
            this.showNotification('System status refreshed', 'success');
        } catch (error) {
            this.showNotification('Failed to refresh system status', 'error');
        }
    }

    async handleSystemUpdate(form) {
        const formData = new FormData(form);
        const resultDiv = document.getElementById('updateResult');
        
        try {
            resultDiv.textContent = 'Preparing update...';
            resultDiv.className = 'update-result warning';
            
            // Check if file is selected
            const fileInput = form.querySelector('input[type="file"]');
            if (!fileInput.files[0]) {
                resultDiv.textContent = 'Please select a ZIP file';
                resultDiv.className = 'update-result error';
                return;
            }
            
            const file = fileInput.files[0];
            if (!file.name.endsWith('.zip')) {
                resultDiv.textContent = 'Please select a valid ZIP file';
                resultDiv.className = 'update-result error';
                return;
            }
            
            resultDiv.textContent = 'Uploading update file...';
            
            const response = await fetch('/api/self-update', {
                method: 'POST',
                body: formData
            });
            
            console.log('Update response status:', response.status);
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error('Update failed:', errorText);
                resultDiv.textContent = `Update failed: ${response.status} ${response.statusText}`;
                resultDiv.className = 'update-result error';
                return;
            }
            
            const result = await response.json();
            console.log('Update result:', result);
            
            resultDiv.textContent = result.message;
            resultDiv.className = 'update-result success';
            form.reset();
            
            // Show countdown for restart
            let countdown = 3;
            const countdownInterval = setInterval(() => {
                resultDiv.textContent = `Update applied! Server restarting in ${countdown} seconds...`;
                countdown--;
                if (countdown < 0) {
                    clearInterval(countdownInterval);
                    resultDiv.textContent = 'Server is restarting... Please wait and refresh the page.';
                }
            }, 1000);
            
            // Auto refresh after 5 seconds
            setTimeout(() => {
                window.location.reload();
            }, 5000);
            
        } catch (error) {
            console.error('Update error:', error);
            resultDiv.textContent = 'Update failed: ' + error.message;
            resultDiv.className = 'update-result error';
        }
    }

    formatUptime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        if (hours > 0) {
            return `${hours}h ${minutes}m ${secs}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${secs}s`;
        } else {
            return `${secs}s`;
        }
    }

    // Terminal Management
    showTerminal(scriptName) {
        this.currentScript = scriptName;
        this.setupTerminalTabs();
        this.showModal('terminalModal');
    }

    hideTerminalModal() {
        this.hideModal('terminalModal');
    }

    setupTerminalTabs() {
        const tabButtons = document.getElementById('terminalTabButtons');
        const tabContent = document.getElementById('terminalTabContent');
        
        // Clear existing tabs
        tabButtons.innerHTML = '';
        tabContent.innerHTML = '';
        
        // Create tabs for each script
        this.scripts.forEach(script => {
            const tabButton = document.createElement('button');
            tabButton.className = `tab-button ${script.name === this.currentScript ? 'active' : ''}`;
            tabButton.textContent = script.name;
            tabButton.onclick = () => this.switchTerminalTab(script.name);
            tabButtons.appendChild(tabButton);
            
            const tabPane = document.createElement('div');
            tabPane.className = `tab-content ${script.name === this.currentScript ? 'active' : ''}`;
            tabPane.id = `terminal-${script.name}`;
            tabPane.innerHTML = `
                <div class="terminal-output" id="output-${script.name}">Terminal ready...</div>
                <div class="terminal-input">
                    <input type="text" id="input-${scriptName}" placeholder="Enter command...">
                    <button onclick="waPanel.executeCommand('${script.name}')">Execute</button>
                </div>
            `;
            tabContent.appendChild(tabPane);
        });
    }

    switchTerminalTab(scriptName) {
        // Update tab buttons
        document.querySelectorAll('.tab-button').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[onclick="waPanel.switchTerminalTab('${scriptName}')"]`).classList.add('active');
        
        // Update tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`terminal-${scriptName}`).classList.add('active');
        
        this.currentScript = scriptName;
    }

    async executeCommand(scriptName) {
        const input = document.getElementById(`input-${scriptName}`);
        const command = input.value.trim();
        
        if (!command) return;
        
        const output = document.getElementById(`output-${scriptName}`);
        output.textContent += `\n$ ${command}\n`;
        
        try {
            const response = await fetch('/api/terminal/execute', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: scriptName, command: command })
            });
            
            const result = await response.json();
            
            if (response.ok) {
                // Poll for output
                this.pollTerminalOutput(result.sessionId, scriptName);
            } else {
                output.textContent += `Error: ${result.message}\n`;
            }
        } catch (error) {
            output.textContent += `Error: ${error.message}\n`;
        }
        
        input.value = '';
        output.scrollTop = output.scrollHeight;
    }

    async pollTerminalOutput(sessionId, scriptName) {
        const output = document.getElementById(`output-${scriptName}`);
        
        const poll = async () => {
            try {
                const response = await fetch(`/api/terminal/output/${sessionId}`);
                const result = await response.json();
                
                if (result.output) {
                    output.textContent += result.output;
                }
                if (result.error) {
                    output.textContent += `Error: ${result.error}\n`;
                }
                
                output.scrollTop = output.scrollHeight;
                
                if (!result.finished) {
                    setTimeout(poll, 1000);
                }
            } catch (error) {
                output.textContent += `Polling error: ${error.message}\n`;
            }
        };
        
        poll();
    }

    // File Viewer Management
    showFileViewer(scriptName) {
        this.currentScript = scriptName;
        this.loadFileList(scriptName);
        this.showModal('fileViewerModal');
    }

    hideFileViewerModal() {
        this.hideModal('fileViewerModal');
    }

    async loadFileList(scriptName) {
        try {
            const response = await fetch(`/api/script/files/${scriptName}`);
            const result = await response.json();
            
            const fileList = document.getElementById('fileList');
            fileList.innerHTML = '';
            
            result.files.forEach(file => {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                fileItem.onclick = () => this.loadFileContent(scriptName, file.name);
                fileItem.innerHTML = `
                    <i class="fas fa-${file.type === 'directory' ? 'folder' : 'file'}"></i>
                    <span class="file-name">${file.name}</span>
                    <span class="file-size">${this.formatFileSize(file.size)}</span>
                `;
                fileList.appendChild(fileItem);
            });
        } catch (error) {
            console.error('Failed to load file list:', error);
        }
    }

    async loadFileContent(scriptName, filename) {
        try {
            const response = await fetch(`/api/script/file/${scriptName}/${filename}`);
            const result = await response.json();
            
            const fileContent = document.getElementById('fileContent');
            fileContent.innerHTML = `<pre>${result.content}</pre>`;
            
            // Update active file item
            document.querySelectorAll('.file-item').forEach(item => {
                item.classList.remove('active');
            });
            event.target.closest('.file-item').classList.add('active');
        } catch (error) {
            const fileContent = document.getElementById('fileContent');
            fileContent.innerHTML = `<div class="no-file">Failed to load file: ${error.message}</div>`;
        }
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
    }

    // Debug functions
    async testUpload() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.js,.zip';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const formData = new FormData();
            formData.append('file', file);
            
            try {
                console.log('Testing upload with file:', file.name);
                const response = await fetch('/api/test-upload', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                console.log('Test upload result:', result);
                this.showNotification('Test upload: ' + result.message, response.ok ? 'success' : 'error');
            } catch (error) {
                console.error('Test upload error:', error);
                this.showNotification('Test upload failed: ' + error.message, 'error');
            }
        };
        
        input.click();
    }

    async checkPermissions() {
        try {
            const response = await fetch('/api/check-permissions');
            const result = await response.json();
            console.log('Permission check result:', result);
            
            let message = 'Permission check:\n';
            Object.entries(result.checks).forEach(([key, check]) => {
                message += `${key}: ${check.exists ? 'exists' : 'missing'}, `;
                message += `r:${check.readable ? 'yes' : 'no'}, `;
                message += `w:${check.writable ? 'yes' : 'no'}\n`;
            });
            
            this.showNotification(message, 'info');
        } catch (error) {
            console.error('Permission check error:', error);
            this.showNotification('Permission check failed: ' + error.message, 'error');
        }
    }
}

// Initialize the panel when DOM is loaded
let waPanel;
document.addEventListener('DOMContentLoaded', () => {
    waPanel = new WAPanel();
});

// Global functions for onclick handlers
function showUploadModal() {
    waPanel.showUploadModal();
}

function hideUploadModal() {
    waPanel.hideUploadModal();
}

function hideLogModal() {
    waPanel.hideLogModal();
}

function hideTerminalModal() {
    waPanel.hideTerminalModal();
}

function hideFileViewerModal() {
    waPanel.hideFileViewerModal();
}

function refreshAll() {
    waPanel.refreshAll();
}

function testUpload() {
    waPanel.testUpload();
}

function checkPermissions() {
    waPanel.checkPermissions();
} 