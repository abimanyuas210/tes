const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const multer = require('multer');
const { spawn } = require('child_process');
const unzipper = require('unzipper');
const pm2 = require('pm2');

const app = express();
const PORT = 3000;

const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const DB_PATH = path.join(__dirname, 'db.json');

fs.ensureDirSync(SCRIPTS_DIR);

const upload = multer({ dest: '/tmp' });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Helper: update status dari pm2 list
async function updatePM2Status() {
  return new Promise((resolve) => {
    pm2.connect((err) => {
      if (err) return resolve();
      pm2.list((err, list) => {
        let db = [];
        try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
        db.forEach(script => {
          const found = list.find(proc => proc.name === script.name);
          if (found) {
            script.status = found.pm2_env.status === 'online' ? '🟢 Online' : '🔴 Offline';
          } else {
            script.status = 'stopped';
          }
        });
        fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
        pm2.disconnect();
        resolve();
      });
    });
  });
}

// API: Get all scripts (with PM2 status)
app.get('/api/scripts', async (req, res) => {
  await updatePM2Status();
  let db = [];
  try {
    db = fs.readJsonSync(DB_PATH);
  } catch (e) {}
  res.json(db);
});

// API: Upload script
app.post('/api/upload', upload.single('file'), async (req, res) => {
  const { name, command } = req.body;
  const file = req.file;
  if (!name || !command || !file) {
    return res.status(400).json({ message: 'Lengkapi semua field!' });
  }
  const folder = name.replace(/[^a-zA-Z0-9_-]/g, '_');
  const scriptPath = path.join(SCRIPTS_DIR, folder);
  await fs.ensureDir(scriptPath);
  let entryFile = '';
  try {
    if (file.originalname.endsWith('.zip')) {
      // Ekstrak zip
      await fs.createReadStream(file.path).pipe(unzipper.Extract({ path: scriptPath })).promise();
      entryFile = path.join(scriptPath, 'index.js');
    } else if (file.originalname.endsWith('.js')) {
      entryFile = path.join(scriptPath, 'index.js');
      await fs.move(file.path, entryFile, { overwrite: true });
    } else {
      return res.status(400).json({ message: 'File harus .js atau .zip' });
    }
    // Uji coba script (tanpa PM2)
    const [cmd, ...args] = command.split(' ');
    const testProc = spawn(cmd, args, { cwd: scriptPath });
    let stdout = '', stderr = '';
    let finished = false;
    const timeout = setTimeout(() => {
      if (!finished) {
        testProc.kill('SIGKILL');
        finished = true;
      }
    }, 10000);
    testProc.stdout.on('data', d => { stdout += d.toString(); });
    testProc.stderr.on('data', d => { stderr += d.toString(); });
    testProc.on('close', code => {
      clearTimeout(timeout);
      if (finished) return;
      finished = true;
      let db = [];
      try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
      let testResult = '', lastError = '';
      if (code === 0) {
        testResult = '✅ OK';
        lastError = '';
      } else {
        testResult = '❌ ERROR';
        lastError = stderr || stdout || 'Unknown error';
      }
      const scriptData = {
        name,
        folder,
        command,
        status: 'stopped',
        testResult,
        lastError
      };
      db = db.filter(s => s.name !== name);
      db.push(scriptData);
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      if (testResult === '✅ OK') {
        res.json({ message: 'Upload & test berhasil!' });
      } else {
        res.json({ message: 'Test gagal: ' + lastError });
      }
    });
  } catch (err) {
    return res.status(500).json({ message: 'Gagal upload: ' + err.message });
  }
});

// API: Start script
app.post('/api/start', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.start({
      name: script.name,
      script: script.command.split(' ')[0],
      args: script.command.split(' ').slice(1),
      cwd: path.join(SCRIPTS_DIR, script.folder)
    }, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal start: ' + err.message });
      script.status = '🟢 Online';
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      res.json({ message: 'Script dijalankan!' });
    });
  });
});

// API: Stop script
app.post('/api/stop', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.stop(name, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal stop: ' + err.message });
      script.status = 'stopped';
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      res.json({ message: 'Script distop!' });
    });
  });
});

// API: Restart script
app.post('/api/restart', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.restart(name, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal restart: ' + err.message });
      script.status = '🟢 Online';
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      res.json({ message: 'Script direstart!' });
    });
  });
});

// API: Delete script
app.post('/api/delete', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.delete(name, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal delete: ' + err.message });
      // Hapus dari db dan folder
      db = db.filter(s => s.name !== name);
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      fs.removeSync(path.join(SCRIPTS_DIR, script.folder));
      res.json({ message: 'Script dihapus!' });
    });
  });
});

// API: Get last log/error
app.get('/api/log/:name', (req, res) => {
  const { name } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  // Cek log/error dari PM2
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.describe(name, (err, desc) => {
      pm2.disconnect();
      if (err || !desc || !desc[0]) return res.json({ log: script.lastError || '-' });
      const out = desc[0].pm2_env.pm_out_log_path;
      const errLog = desc[0].pm2_env.pm_err_log_path;
      let log = '';
      try {
        log = fs.readFileSync(errLog, 'utf8').split('\n').slice(-10).join('\n');
      } catch (e) {}
      res.json({ log: log || script.lastError || '-' });
    });
  });
});

app.listen(PORT, () => {
  console.log(`WA Panel aktif di http://localhost:${PORT}`);
}); 