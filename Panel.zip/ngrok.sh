#!/usr/bin/env bash

if [ "$(uname -o)" = "Android" ]; then
  # Termux
  cd "$(dirname "$0")"
  if [ ! -f "ngrok" ]; then
    pkg install wget -y
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip -O ngrok.zip
    unzip ngrok.zip
    chmod +x ngrok
  fi
  ./ngrok http 3000
else
  # Ubuntu/Linux
  cd "$(dirname "$0")"
  if [ ! -f "ngrok" ]; then
    sudo apt update && sudo apt install wget unzip -y
    wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip -O ngrok.zip
    unzip ngrok.zip
    chmod +x ngrok
  fi
  ./ngrok http 3000
fi 