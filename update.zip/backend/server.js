const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
const fs = require('fs-extra');
const multer = require('multer');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { exec } = require('child_process');
const util = require('util');
const cron = require('node-cron');
const chalk = require('chalk');
const figlet = require('figlet');
const Table = require('cli-table3');

const execAsync = util.promisify(exec);

// Configuration
const config = {
  port: process.env.PORT || 3000,
  jwtSecret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this',
  uploadDir: path.join(__dirname, 'uploads'),
  scriptsDir: path.join(__dirname, 'scripts'),
  logsDir: path.join(__dirname, 'logs'),
  maxFileSize: 100 * 1024 * 1024, // 100MB
  allowedFileTypes: ['.js', '.json', '.zip', '.tar.gz', '.rar'],
  rateLimitWindow: 15 * 60 * 1000, // 15 minutes
  rateLimitMax: 100 // requests per window
};

// Initialize app
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      scriptSrc: ["'self'", "'unsafe-inline'", "https://cdnjs.cloudflare.com"],
      imgSrc: ["'self'", "data:", "https:"],
      connectSrc: ["'self'", "ws:", "wss:"]
    }
  }
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: config.rateLimitWindow,
  max: config.rateLimitMax,
  message: {
    error: 'Too many requests from this IP, please try again later.'
  },
  standardHeaders: true,
  legacyHeaders: false
});

app.use(limiter);

// Middleware
app.use(compression());
app.use(morgan('combined'));
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Create directories
[config.uploadDir, config.scriptsDir, config.logsDir].forEach(dir => {
  fs.ensureDirSync(dir);
});

// File upload configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, config.uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: config.maxFileSize
  },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (config.allowedFileTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error(`File type ${ext} not allowed`), false);
    }
  }
});

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, config.jwtSecret, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Utility functions
const logActivity = (action, details) => {
  const logEntry = {
    timestamp: new Date().toISOString(),
    action,
    details,
    ip: req?.ip || 'unknown'
  };
  
  fs.appendFileSync(
    path.join(config.logsDir, 'activity.log'),
    JSON.stringify(logEntry) + '\n'
  );
};

const getSystemStats = async () => {
  try {
    const { stdout: cpuInfo } = await execAsync('top -bn1 | grep "Cpu(s)" | awk \'{print $2}\' | cut -d\'%\' -f1');
    const { stdout: memInfo } = await execAsync('free | grep Mem | awk \'{printf "%.2f", $3/$2 * 100.0}\'');
    const { stdout: diskInfo } = await execAsync('df / | tail -1 | awk \'{print $5}\' | cut -d\'%\' -f1');
    
    return {
      cpu: parseFloat(cpuInfo.trim()),
      memory: parseFloat(memInfo.trim()),
      disk: parseFloat(diskInfo.trim()),
      uptime: process.uptime()
    };
  } catch (error) {
    return { error: 'Failed to get system stats' };
  }
};

// PM2 Management functions
const pm2List = async () => {
  try {
    const { stdout } = await execAsync('pm2 jlist');
    return JSON.parse(stdout);
  } catch (error) {
    return [];
  }
};

const pm2Start = async (name, scriptPath) => {
  try {
    await execAsync(`pm2 start "${scriptPath}" --name "${name}"`);
    return { success: true, message: `Started ${name}` };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

const pm2Stop = async (name) => {
  try {
    await execAsync(`pm2 stop "${name}"`);
    return { success: true, message: `Stopped ${name}` };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

const pm2Restart = async (name) => {
  try {
    await execAsync(`pm2 restart "${name}"`);
    return { success: true, message: `Restarted ${name}` };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

const pm2Delete = async (name) => {
  try {
    await execAsync(`pm2 delete "${name}"`);
    return { success: true, message: `Deleted ${name}` };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

const pm2Logs = async (name, lines = 100) => {
  try {
    const { stdout } = await execAsync(`pm2 logs "${name}" --lines ${lines} --nostream`);
    return { success: true, logs: stdout };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// API Routes

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: '2.0.0'
  });
});

// Authentication
app.post('/api/auth/login', async (req, res) => {
  const { username, password } = req.body;
  
  // Default admin credentials (should be changed in production)
  const adminUser = {
    username: 'admin',
    password: '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' // password
  };
  
  if (username === adminUser.username) {
    const validPassword = await bcrypt.compare(password, adminUser.password);
    if (validPassword) {
      const token = jwt.sign({ username, role: 'admin' }, config.jwtSecret, { expiresIn: '24h' });
      res.json({ token, user: { username, role: 'admin' } });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } else {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

// Dashboard stats
app.get('/api/dashboard/stats', authenticateToken, async (req, res) => {
  try {
    const [pm2Processes, systemStats] = await Promise.all([
      pm2List(),
      getSystemStats()
    ]);
    
    const runningApps = pm2Processes.filter(p => p.pm2_env?.status === 'online').length;
    const totalApps = pm2Processes.length;
    
    res.json({
      applications: {
        total: totalApps,
        running: runningApps,
        stopped: totalApps - runningApps
      },
      system: systemStats,
      recentActivity: await getRecentActivity()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Applications management
app.get('/api/applications', authenticateToken, async (req, res) => {
  try {
    const processes = await pm2List();
    const applications = processes.map(p => ({
      id: p.pm_id,
      name: p.name,
      status: p.pm2_env?.status || 'unknown',
      cpu: p.monit?.cpu || 0,
      memory: p.monit?.memory || 0,
      uptime: p.pm2_env?.pm_uptime || 0,
      restarts: p.pm2_env?.restart_time || 0,
      path: p.pm2_env?.pm_cwd || '',
      script: p.pm2_env?.script || ''
    }));
    
    res.json(applications);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Application actions
app.post('/api/applications/:name/start', authenticateToken, async (req, res) => {
  const { name } = req.params;
  const { scriptPath } = req.body;
  
  const result = await pm2Start(name, scriptPath);
  if (result.success) {
    io.emit('application:status', { name, status: 'started' });
    res.json(result);
  } else {
    res.status(400).json(result);
  }
});

app.post('/api/applications/:name/stop', authenticateToken, async (req, res) => {
  const { name } = req.params;
  const result = await pm2Stop(name);
  
  if (result.success) {
    io.emit('application:status', { name, status: 'stopped' });
    res.json(result);
  } else {
    res.status(400).json(result);
  }
});

app.post('/api/applications/:name/restart', authenticateToken, async (req, res) => {
  const { name } = req.params;
  const result = await pm2Restart(name);
  
  if (result.success) {
    io.emit('application:status', { name, status: 'restarted' });
    res.json(result);
  } else {
    res.status(400).json(result);
  }
});

app.delete('/api/applications/:name', authenticateToken, async (req, res) => {
  const { name } = req.params;
  const result = await pm2Delete(name);
  
  if (result.success) {
    io.emit('application:deleted', { name });
    res.json(result);
  } else {
    res.status(400).json(result);
  }
});

// Application logs
app.get('/api/applications/:name/logs', authenticateToken, async (req, res) => {
  const { name } = req.params;
  const { lines = 100 } = req.query;
  
  const result = await pm2Logs(name, lines);
  if (result.success) {
    res.json(result);
  } else {
    res.status(400).json(result);
  }
});

// File upload
app.post('/api/upload', authenticateToken, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const file = req.file;
    const fileName = path.parse(file.originalname).name;
    const fileExt = path.extname(file.originalname);
    
    // Extract if it's a zip file
    if (fileExt === '.zip') {
      const extractPath = path.join(config.scriptsDir, fileName);
      await fs.ensureDir(extractPath);
      
      const unzipper = require('unzipper');
      await fs.createReadStream(file.path)
        .pipe(unzipper.Extract({ path: extractPath }))
        .promise();
      
      // Find package.json and install dependencies
      const packageJsonPath = path.join(extractPath, 'package.json');
      if (await fs.pathExists(packageJsonPath)) {
        await execAsync(`cd "${extractPath}" && npm install`);
      }
      
      await fs.remove(file.path);
      
      res.json({
        success: true,
        message: 'File uploaded and extracted successfully',
        path: extractPath,
        name: fileName
      });
    } else {
      // Move file to scripts directory
      const targetPath = path.join(config.scriptsDir, file.originalname);
      await fs.move(file.path, targetPath);
      
      res.json({
        success: true,
        message: 'File uploaded successfully',
        path: targetPath,
        name: fileName
      });
    }
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// File management
app.get('/api/files', authenticateToken, async (req, res) => {
  try {
    const { dir = config.scriptsDir } = req.query;
    const files = await fs.readdir(dir);
    const fileStats = await Promise.all(
      files.map(async (file) => {
        const filePath = path.join(dir, file);
        const stat = await fs.stat(filePath);
        return {
          name: file,
          path: filePath,
          size: stat.size,
          isDirectory: stat.isDirectory(),
          modified: stat.mtime,
          created: stat.birthtime
        };
      })
    );
    
    res.json(fileStats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Terminal/Command execution
app.post('/api/terminal/execute', authenticateToken, async (req, res) => {
  const { command, cwd = config.scriptsDir } = req.body;
  
  if (!command) {
    return res.status(400).json({ error: 'Command is required' });
  }
  
  try {
    const { stdout, stderr } = await execAsync(command, { cwd });
    res.json({
      success: true,
      output: stdout,
      error: stderr,
      command
    });
  } catch (error) {
    res.json({
      success: false,
      output: error.stdout || '',
      error: error.stderr || error.message,
      command
    });
  }
});

// System information
app.get('/api/system/info', authenticateToken, async (req, res) => {
  try {
    const { stdout: nodeVersion } = await execAsync('node --version');
    const { stdout: npmVersion } = await execAsync('npm --version');
    const { stdout: pm2Version } = await execAsync('pm2 --version');
    
    res.json({
      nodeVersion: nodeVersion.trim(),
      npmVersion: npmVersion.trim(),
      pm2Version: pm2Version.trim(),
      platform: process.platform,
      arch: process.arch,
      uptime: process.uptime()
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Serve static files
app.use(express.static(path.join(__dirname, '../frontend')));

// Catch all route for SPA
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Socket.IO events
io.on('connection', (socket) => {
  console.log(chalk.green('Client connected:', socket.id));
  
  socket.on('disconnect', () => {
    console.log(chalk.red('Client disconnected:', socket.id));
  });
  
  socket.on('terminal:command', async (data) => {
    try {
      const { stdout, stderr } = await execAsync(data.command, { cwd: data.cwd || config.scriptsDir });
      socket.emit('terminal:output', {
        output: stdout,
        error: stderr,
        command: data.command
      });
    } catch (error) {
      socket.emit('terminal:output', {
        output: error.stdout || '',
        error: error.stderr || error.message,
        command: data.command
      });
    }
  });
});

// Scheduled tasks
cron.schedule('*/30 * * * *', async () => {
  // Update system stats every 30 minutes
  const stats = await getSystemStats();
  io.emit('system:stats', stats);
});

cron.schedule('0 */6 * * *', async () => {
  // Clean up old logs every 6 hours
  try {
    const logFiles = await fs.readdir(config.logsDir);
    const now = Date.now();
    const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days
    
    for (const file of logFiles) {
      const filePath = path.join(config.logsDir, file);
      const stats = await fs.stat(filePath);
      if (now - stats.mtime.getTime() > maxAge) {
        await fs.remove(filePath);
      }
    }
  } catch (error) {
    console.error('Log cleanup error:', error);
  }
});

// Error handling
app.use((error, req, res, next) => {
  console.error(chalk.red('Error:', error));
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
server.listen(config.port, () => {
  console.clear();
  console.log(chalk.cyan(figlet.textSync('Pterodactyl', { horizontalLayout: 'full' })));
  console.log(chalk.cyan(figlet.textSync('NodeJS Panel', { horizontalLayout: 'full' })));
  console.log(chalk.yellow('\n🚀 Server is running on port', config.port));
  console.log(chalk.green('📊 Dashboard: http://localhost:' + config.port));
  console.log(chalk.blue('🔧 API: http://localhost:' + config.port + '/api'));
  console.log(chalk.magenta('⚡ Socket.IO: ws://localhost:' + config.port));
  console.log(chalk.gray('\nPress Ctrl+C to stop the server\n'));
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log(chalk.yellow('\n🛑 Received SIGTERM, shutting down gracefully...'));
  server.close(() => {
    console.log(chalk.green('✅ Server closed'));
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log(chalk.yellow('\n🛑 Received SIGINT, shutting down gracefully...'));
  server.close(() => {
    console.log(chalk.green('✅ Server closed'));
    process.exit(0);
  });
});

module.exports = app; 