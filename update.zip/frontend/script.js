// WA Panel - Script Management System
class WAPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.scripts = [];
        this.isLoading = false;
        this.retryAttempts = 0;
        this.maxRetries = 3;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadScripts();
        this.updateDashboardStats();
        this.setupNavigation();
        this.setupErrorHandling();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.getAttribute('href').substring(1);
                this.showSection(section);
            });
        });

        // Sidebar toggle
        document.querySelector('.sidebar-toggle').addEventListener('click', () => {
            this.toggleSidebar();
        });

        // Upload forms
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.uploadScript(e.target);
        });

        document.getElementById('modalUploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.uploadScript(e.target);
        });

        // System update form
        document.getElementById('updateForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSystemUpdate(e.target);
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.hideAllModals();
            });
        });

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.hideAllModals();
                }
            });
        });

        // File upload styling
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', (e) => {
                this.handleFileUpload(e);
            });
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
    }

    setupNavigation() {
        // Set active nav item
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });
    }

    setupErrorHandling() {
        // Global error handler
        window.addEventListener('error', (e) => {
            console.error('Global error:', e.error);
            this.showNotification('An unexpected error occurred', 'error');
        });

        // Unhandled promise rejection
        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled promise rejection:', e.reason);
            this.showNotification('Network error occurred', 'error');
        });
    }

    handleFileUpload(e) {
        const file = e.target.files[0];
        if (file) {
            const label = e.target.nextElementSibling;
            const span = label.querySelector('span');
            if (span) {
                span.textContent = file.name;
            }
            
            // Auto-fill script name if empty
            const nameInput = e.target.closest('form').querySelector('input[name="name"]');
            if (nameInput && !nameInput.value) {
                const name = file.name.replace(/\.[^/.]+$/, '');
                nameInput.value = name;
            }
        }
    }

    handleKeyboardShortcuts(e) {
        // Ctrl/Cmd + K to focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            // Add search functionality if needed
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            this.hideAllModals();
        }
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('section').forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionName;
        }

        // Update page title
        this.updatePageTitle(sectionName);

        // Load section-specific content
        this.loadSectionContent(sectionName);
    }

    updatePageTitle(sectionName) {
        const pageTitle = document.querySelector('.page-title');
        const titles = {
            'dashboard': 'Dashboard',
            'scripts': 'Script Management',
            'upload': 'Upload Script',
            'logs': 'System Logs',
            'system': 'System Management'
        };
        
        if (pageTitle && titles[sectionName]) {
            pageTitle.textContent = titles[sectionName];
        }
    }

    loadSectionContent(sectionName) {
        switch(sectionName) {
            case 'scripts':
                this.renderScriptsTable();
                break;
            case 'dashboard':
                this.updateDashboardStats();
                this.renderRecentScripts();
                break;
            case 'system':
                this.refreshSystemStatus();
                break;
            case 'logs':
                this.loadSystemLogs();
                break;
        }
    }

    async loadScripts() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.setLoadingState(true);
        
        try {
            const response = await this.makeRequest('/api/scripts');
            this.scripts = response;
            this.updateDashboardStats();
            this.renderRecentScripts();
            this.retryAttempts = 0; // Reset retry attempts on success
        } catch (error) {
            console.error('Failed to load scripts:', error);
            this.handleLoadError(error);
        } finally {
            this.isLoading = false;
            this.setLoadingState(false);
        }
    }

    async makeRequest(url, options = {}) {
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        };

        const finalOptions = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(url, finalOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            throw new Error(`Request failed: ${error.message}`);
        }
    }

    handleLoadError(error) {
        this.retryAttempts++;
        
        if (this.retryAttempts < this.maxRetries) {
            this.showNotification(`Loading failed, retrying... (${this.retryAttempts}/${this.maxRetries})`, 'warning');
            setTimeout(() => this.loadScripts(), 2000 * this.retryAttempts);
        } else {
            this.showNotification('Failed to load scripts after multiple attempts', 'error');
            this.showErrorState();
        }
    }

    setLoadingState(loading) {
        const refreshBtn = document.querySelector('.btn-secondary i.fa-sync-alt');
        if (refreshBtn) {
            if (loading) {
                refreshBtn.classList.add('fa-spin');
            } else {
                refreshBtn.classList.remove('fa-spin');
            }
        }
    }

    showErrorState() {
        const tbody = document.querySelector('#scriptsTable tbody');
        if (tbody) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="5" class="error-state">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3>Failed to Load Scripts</h3>
                        <p>Please check your connection and try again</p>
                        <button class="btn btn-primary" onclick="waPanel.loadScripts()">
                            <i class="fas fa-sync-alt"></i>
                            Retry
                        </button>
                    </td>
                </tr>
            `;
        }
    }

    updateDashboardStats() {
        const running = this.scripts.filter(s => s.status === '🟢 Online').length;
        const stopped = this.scripts.filter(s => s.status === 'stopped').length;
        const tested = this.scripts.filter(s => s.testResult === '✅ OK').length;
        const errors = this.scripts.filter(s => s.testResult === '❌ ERROR').length;

        this.updateStatElement('runningScripts', running);
        this.updateStatElement('stoppedScripts', stopped);
        this.updateStatElement('testedScripts', tested);
        this.updateStatElement('errorScripts', errors);
    }

    updateStatElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
            
            // Add animation
            element.style.transform = 'scale(1.1)';
            setTimeout(() => {
                element.style.transform = 'scale(1)';
            }, 200);
        }
    }

    renderRecentScripts() {
        const container = document.getElementById('recentScriptsList');
        const recentScripts = this.scripts.slice(0, 5);

        if (recentScripts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-code"></i>
                    <h3>No Scripts Yet</h3>
                    <p>Upload your first script to get started</p>
                    <button class="btn btn-primary" onclick="waPanel.showUploadModal()">
                        <i class="fas fa-plus"></i>
                        Upload Script
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = recentScripts.map(script => `
            <div class="script-item">
                <div>
                    <div style="font-weight: 600; color: #f3f4f6;">${script.name}</div>
                    <div style="font-size: 0.875rem; color: #9ca3af;">${script.command}</div>
                </div>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                    <div class="action-buttons">
                        <button class="btn-sm btn-info" onclick="waPanel.showLog('${script.name}')" title="View Logs">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-sm btn-success" onclick="waPanel.startScript('${script.name}')" title="Start Script">
                            <i class="fas fa-play"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderScriptsTable() {
        const tbody = document.querySelector('#scriptsTable tbody');
        
        if (this.scripts.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="empty-state">
                        <i class="fas fa-code"></i>
                        <h3>No Scripts Found</h3>
                        <p>Upload your first script to get started</p>
                        <button class="btn btn-primary" onclick="waPanel.showUploadModal()">
                            <i class="fas fa-plus"></i>
                            Upload Script
                        </button>
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = this.scripts.map(script => `
            <tr>
                <td>
                    <div style="font-weight: 600; color: #f3f4f6;">${script.name}</div>
                    <div style="font-size: 0.75rem; color: #9ca3af;">${script.folder} (${script.mainFile || 'index.js'})</div>
                </td>
                <td style="font-family: monospace; font-size: 0.875rem;">${script.command}</td>
                <td>
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                </td>
                <td>
                    <span class="status-badge ${script.testResult === '✅ OK' ? 'running' : 'error'}">${script.testResult}</span>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-sm btn-info" onclick="waPanel.showLog('${script.name}')" title="View Logs">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-sm btn-success" onclick="waPanel.startScript('${script.name}')" title="Start Script">
                            <i class="fas fa-play"></i>
                        </button>
                        <button class="btn-sm btn-warning" onclick="waPanel.restartScript('${script.name}')" title="Restart Script">
                            <i class="fas fa-redo"></i>
                        </button>
                        <button class="btn-sm btn-error" onclick="waPanel.stopScript('${script.name}')" title="Stop Script">
                            <i class="fas fa-stop"></i>
                        </button>
                        <button class="btn-sm btn-info" onclick="waPanel.installMissingModules('${script.name}')" title="Install Missing Modules">
                            <i class="fas fa-download"></i>
                        </button>
                        <button class="btn-sm btn-secondary" onclick="waPanel.deleteScript('${script.name}')" title="Delete Script">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getStatusClass(status) {
        if (status === '🟢 Online') return 'running';
        if (status === 'stopped') return 'stopped';
        return 'error';
    }

    async uploadScript(form) {
        const formData = new FormData(form);
        const resultDiv = form.id === 'modalUploadForm' ? 
            document.getElementById('modalUploadResult') : 
            document.getElementById('uploadResult');

        try {
            // Validate form data
            const name = formData.get('name');
            const command = formData.get('command');
            const file = formData.get('file');

            if (!name || !command || !file) {
                throw new Error('Please fill all required fields');
            }

            if (!file.name.endsWith('.js') && !file.name.endsWith('.zip')) {
                throw new Error('Please select a .js or .zip file');
            }

            // Show upload progress modal
            this.showUploadProgress();
            this.updateProgressStep(1, 'active');
            this.updateProgressAction('Uploading file to server...');
            this.addProgressLog('Starting upload process...');

            // Upload file
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Upload failed: ${response.status} ${response.statusText}`);
            }

            const result = await response.json();
            this.addProgressLog('File uploaded successfully');
            this.updateProgressStep(1, 'completed');
            this.updateProgressStep(2, 'active');
            this.updateProgressAction('Extracting and organizing files...');
            this.addProgressLog('Processing uploaded file...');

            // Simulate extraction process
            await this.delay(1000);
            this.updateProgressStep(2, 'completed');
            this.updateProgressStep(3, 'active');
            this.updateProgressAction('Creating project structure...');
            this.addProgressLog('Creating package.json and README...');

            // Simulate structure creation
            await this.delay(500);
            this.updateProgressStep(3, 'completed');
            this.updateProgressStep(4, 'active');
            this.updateProgressAction('Installing npm dependencies...');
            this.addProgressLog('Installing required modules...');

            // Simulate npm install
            await this.delay(2000);
            this.updateProgressStep(4, 'completed');
            this.updateProgressStep(5, 'active');
            this.updateProgressAction('Testing script functionality...');
            this.addProgressLog('Testing script...');

            // Simulate testing
            await this.delay(1000);
            this.updateProgressStep(5, 'completed');
            this.updateProgressAction('Upload completed successfully!');
            this.addProgressLog('Script uploaded and ready to use!');

            // Update progress bar
            this.updateProgressBar(100);

            // Wait a moment then redirect
            await this.delay(1500);
            this.hideUploadProgress();
            
            this.showNotification('Script uploaded successfully!', 'success');
            form.reset();
            await this.loadScripts();

            if (form.id === 'modalUploadForm') {
                this.hideUploadModal();
            }

        } catch (error) {
            console.error('Upload error:', error);
            this.addProgressLog(`Error: ${error.message}`, 'error');
            this.updateProgressAction('Upload failed');
            this.hideUploadProgress();
            
            resultDiv.textContent = 'Upload failed: ' + error.message;
            resultDiv.className = 'upload-result error';
            this.showNotification('Upload failed: ' + error.message, 'error');
        }
    }

    showUploadProgress() {
        const modal = document.getElementById('uploadProgressModal');
        if (modal) {
            modal.classList.add('active');
        }
        this.resetProgress();
    }

    hideUploadProgress() {
        const modal = document.getElementById('uploadProgressModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    resetProgress() {
        // Reset all steps
        for (let i = 1; i <= 5; i++) {
            const step = document.getElementById(`step${i}`);
            if (step) {
                step.className = 'step';
            }
        }
        
        // Reset progress bar
        this.updateProgressBar(0);
        
        // Clear logs
        const logContainer = document.getElementById('progressLog');
        if (logContainer) {
            logContainer.innerHTML = '';
        }
    }

    updateProgressStep(stepNumber, status) {
        const step = document.getElementById(`step${stepNumber}`);
        if (step) {
            step.className = `step ${status}`;
            
            const icon = step.querySelector('.step-icon i');
            if (icon) {
                if (status === 'active') {
                    icon.className = 'fas fa-spinner fa-spin';
                } else if (status === 'completed') {
                    icon.className = 'fas fa-check';
                }
            }
        }
    }

    updateProgressAction(action) {
        const actionElement = document.getElementById('currentAction');
        if (actionElement) {
            const span = actionElement.querySelector('span');
            if (span) {
                span.textContent = action;
            }
        }
    }

    addProgressLog(message, type = 'info') {
        const logContainer = document.getElementById('progressLog');
        if (logContainer) {
            const logEntry = document.createElement('div');
            logEntry.className = `log-entry ${type}`;
            logEntry.innerHTML = `
                <span class="log-time">${new Date().toLocaleTimeString()}</span>
                <span class="log-message">${message}</span>
            `;
            logContainer.appendChild(logEntry);
            logContainer.scrollTop = logContainer.scrollHeight;
        }
    }

    updateProgressBar(percentage) {
        const progressFill = document.getElementById('progressFill');
        if (progressFill) {
            progressFill.style.width = `${percentage}%`;
        }
    }

    cancelUpload() {
        this.hideUploadProgress();
        this.showNotification('Upload cancelled', 'warning');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async installMissingModules(name) {
        try {
            this.showNotification(`Installing missing modules for ${name}...`, 'info');
            
            const response = await this.makeRequest(`/api/install-missing/${name}`, {
                method: 'POST'
            });
            
            this.showNotification(response.message, 'success');
            await this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to install missing modules: ' + error.message, 'error');
        }
    }

    async checkMissingModules(name) {
        try {
            const response = await this.makeRequest(`/api/check-missing/${name}`);
            return response.hasMissing;
        } catch (error) {
            console.error('Failed to check missing modules:', error);
            return false;
        }
    }

    async startScript(name) {
        try {
            // Check for missing modules first
            const hasMissing = await this.checkMissingModules(name);
            
            if (hasMissing) {
                this.showNotification(`Installing missing modules for ${name}...`, 'info');
                await this.installMissingModules(name);
            }
            
            this.showNotification(`Starting ${name}...`, 'info');
            
            const response = await this.makeRequest(`/api/pm2/start/${name}`, {
                method: 'POST',
                body: JSON.stringify({ name })
            });
            
            this.showNotification(response.message, 'success');
            await this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to start script: ' + error.message, 'error');
        }
    }

    async stopScript(name) {
        try {
            const response = await this.makeRequest(`/api/pm2/stop/${name}`, {
                method: 'POST'
            });
            
            this.showNotification(response.message, 'success');
            await this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to stop script: ' + error.message, 'error');
        }
    }

    async restartScript(name) {
        try {
            // Check for missing modules first
            const hasMissing = await this.checkMissingModules(name);
            
            if (hasMissing) {
                this.showNotification(`Installing missing modules for ${name}...`, 'info');
                await this.installMissingModules(name);
            }
            
            this.showNotification(`Restarting ${name}...`, 'info');
            
            const response = await this.makeRequest(`/api/pm2/restart/${name}`, {
                method: 'POST',
                body: JSON.stringify({ name })
            });
            
            this.showNotification(response.message, 'success');
            await this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to restart script: ' + error.message, 'error');
        }
    }

    async deleteScript(name) {
        if (!confirm('Are you sure you want to delete this script? This action cannot be undone.')) {
            return;
        }
        
        try {
            const response = await this.makeRequest(`/api/pm2/delete/${name}`, {
                method: 'POST'
            });
            
            this.showNotification(response.message, 'success');
            await this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to delete script: ' + error.message, 'error');
        }
    }

    async showLog(name) {
        try {
            const response = await this.makeRequest(`/api/log/${name}`);
            
            const logContent = document.getElementById('logContent');
            if (logContent) {
                logContent.textContent = response.log || 'No logs available';
            }
            
            this.showModal('logModal');
        } catch (error) {
            this.showNotification('Failed to load logs: ' + error.message, 'error');
        }
    }

    async loadSystemLogs() {
        try {
            const response = await this.makeRequest('/api/system/logs');
            const logsContent = document.getElementById('logsContent');
            
            if (logsContent) {
                if (response.logs && response.logs.length > 0) {
                    logsContent.innerHTML = response.logs.map(log => `
                        <div class="log-entry">
                            <span class="log-time">${log.timestamp}</span>
                            <span class="log-level ${log.level}">${log.level}</span>
                            <span class="log-message">${log.message}</span>
                        </div>
                    `).join('');
                } else {
                    logsContent.innerHTML = `
                        <div class="empty-state">
                            <i class="fas fa-file-alt"></i>
                            <h3>No Logs Available</h3>
                            <p>System logs will appear here when available</p>
                        </div>
                    `;
                }
            }
        } catch (error) {
            console.error('Failed to load system logs:', error);
        }
    }

    showUploadModal() {
        this.showModal('uploadModal');
    }

    hideUploadModal() {
        this.hideModal('uploadModal');
    }

    hideLogModal() {
        this.hideModal('logModal');
    }

    hideTerminalModal() {
        this.hideModal('terminalModal');
    }

    hideFileViewerModal() {
        this.hideModal('fileViewerModal');
    }

    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
        }
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    }

    hideAllModals() {
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.classList.remove('active');
        });
    }

    toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        if (sidebar) {
            sidebar.classList.toggle('active');
        }
    }

    showNotification(message, type = 'info') {
        // Remove existing notifications
        document.querySelectorAll('.notification').forEach(notification => {
            notification.remove();
        });

        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 0.5rem;">
                <i class="fas ${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
        `;

        document.body.appendChild(notification);

        // Remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    getNotificationIcon(type) {
        const icons = {
            'success': 'fa-check-circle',
            'error': 'fa-exclamation-circle',
            'warning': 'fa-exclamation-triangle',
            'info': 'fa-info-circle'
        };
        return icons[type] || 'fa-info-circle';
    }

    refreshAll() {
        this.loadScripts();
        this.showNotification('Refreshed all data', 'success');
    }

    async refreshSystemStatus() {
        try {
            const response = await this.makeRequest('/api/update-status');
            
            this.updateSystemStatus(response);
        } catch (error) {
            this.showNotification('Failed to refresh system status: ' + error.message, 'error');
        }
    }

    updateSystemStatus(status) {
        const elements = {
            'systemVersion': status.version || 'Unknown',
            'systemUptime': this.formatUptime(status.uptime || 0),
            'lastUpdate': status.lastUpdate || 'Never'
        };

        Object.entries(elements).forEach(([id, value]) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        });
    }

    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        
        if (days > 0) {
            return `${days}d ${hours}h ${minutes}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes}m`;
        }
    }

    async handleSystemUpdate(form) {
        const formData = new FormData(form);
        const resultDiv = document.getElementById('updateResult');

        try {
            this.showNotification('Applying system update...', 'info');
            resultDiv.textContent = 'Applying update...';
            resultDiv.className = 'update-result';

            const response = await fetch('/api/update', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Update failed: ${response.status} ${response.statusText}`);
            }

            const result = await response.json();
            resultDiv.textContent = result.message;
            resultDiv.className = 'update-result success';
            this.showNotification('System update applied successfully', 'success');

            form.reset();
        } catch (error) {
            console.error('Update error:', error);
            resultDiv.textContent = 'Update failed: ' + error.message;
            resultDiv.className = 'update-result error';
            this.showNotification('Update failed: ' + error.message, 'error');
        }
    }
}

// Initialize the application
const waPanel = new WAPanel();

// Global functions for backward compatibility
function showUploadModal() {
    waPanel.showUploadModal();
}

function hideUploadModal() {
    waPanel.hideUploadModal();
}

function hideLogModal() {
    waPanel.hideLogModal();
}

function hideTerminalModal() {
    waPanel.hideTerminalModal();
}

function hideFileViewerModal() {
    waPanel.hideFileViewerModal();
}

function refreshAll() {
    waPanel.refreshAll();
}

function testUpload() {
    waPanel.showNotification('Testing upload functionality...', 'info');
}

function checkPermissions() {
    waPanel.showNotification('Checking permissions...', 'info');
} 