// Pterodactyl NodeJS Panel - Modern JavaScript

class PterodactylPanel {
    constructor() {
        this.socket = null;
        this.currentPage = 'dashboard';
        this.applications = [];
        this.systemStats = {};
        this.notifications = [];
        this.terminalHistory = [];
        this.terminalHistoryIndex = -1;
        
        this.init();
    }

    async init() {
        this.setupEventListeners();
        this.checkAuthentication();
        await this.initializeSocket();
        this.loadDashboard();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.dataset.page;
                this.navigateToPage(page);
            });
        });

        // Login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.handleLogout());
        }

        // Upload functionality
        const uploadBtn = document.getElementById('upload-btn');
        if (uploadBtn) {
            uploadBtn.addEventListener('click', () => this.showUploadModal());
        }

        const uploadForm = document.getElementById('upload-form');
        if (uploadForm) {
            uploadForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleUpload();
            });
        }

        const cancelUploadBtn = document.getElementById('cancel-upload');
        if (cancelUploadBtn) {
            cancelUploadBtn.addEventListener('click', () => this.hideUploadModal());
        }

        // Terminal
        const terminalInput = document.getElementById('terminal-input');
        if (terminalInput) {
            terminalInput.addEventListener('keydown', (e) => this.handleTerminalInput(e));
        }

        const clearTerminalBtn = document.getElementById('clear-terminal');
        if (clearTerminalBtn) {
            clearTerminalBtn.addEventListener('click', () => this.clearTerminal());
        }

        // Logs
        const logsAppSelect = document.getElementById('logs-app');
        if (logsAppSelect) {
            logsAppSelect.addEventListener('change', () => this.loadApplicationLogs());
        }

        const refreshLogsBtn = document.getElementById('refresh-logs');
        if (refreshLogsBtn) {
            refreshLogsBtn.addEventListener('click', () => this.loadApplicationLogs());
        }

        // Notifications
        const notificationsBtn = document.getElementById('notifications-btn');
        if (notificationsBtn) {
            notificationsBtn.addEventListener('click', () => this.toggleNotifications());
        }
    }

    checkAuthentication() {
        const token = localStorage.getItem('auth_token');
        if (!token) {
            this.showLoginModal();
        } else {
            this.hideLoginModal();
            this.loadApp();
        }
    }

    showLoginModal() {
        document.getElementById('login-modal').classList.remove('hidden');
        document.getElementById('app').classList.add('hidden');
    }

    hideLoginModal() {
        document.getElementById('login-modal').classList.add('hidden');
        document.getElementById('app').classList.remove('hidden');
    }

    async handleLogin() {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('login-error');

        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
                localStorage.setItem('auth_token', data.token);
                localStorage.setItem('user', JSON.stringify(data.user));
                this.hideLoginModal();
                this.loadApp();
                this.showNotification('Login successful!', 'success');
            } else {
                errorDiv.textContent = data.error || 'Login failed';
                errorDiv.classList.remove('hidden');
            }
        } catch (error) {
            errorDiv.textContent = 'Network error. Please try again.';
            errorDiv.classList.remove('hidden');
        }
    }

    handleLogout() {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('user');
        this.showLoginModal();
        this.showNotification('Logged out successfully', 'info');
    }

    async initializeSocket() {
        this.socket = io();

        this.socket.on('connect', () => {
            this.updateConnectionStatus('Connected', 'success');
            console.log('Connected to server');
        });

        this.socket.on('disconnect', () => {
            this.updateConnectionStatus('Disconnected', 'error');
            console.log('Disconnected from server');
        });

        this.socket.on('application:status', (data) => {
            this.updateApplicationStatus(data);
        });

        this.socket.on('application:deleted', (data) => {
            this.removeApplication(data.name);
        });

        this.socket.on('system:stats', (stats) => {
            this.updateSystemStats(stats);
        });
    }

    updateConnectionStatus(status, type) {
        const statusElement = document.getElementById('connection-status');
        if (statusElement) {
            statusElement.textContent = status;
            statusElement.className = `text-xs px-2 py-1 rounded-full ${
                type === 'success' ? 'bg-green-500' : 'bg-red-500'
            } text-white`;
        }
    }

    navigateToPage(page) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-page="${page}"]`).classList.add('active');

        // Hide all pages
        document.querySelectorAll('.page-content').forEach(content => {
            content.classList.add('hidden');
        });

        // Show selected page
        document.getElementById(`${page}-page`).classList.remove('hidden');

        // Update page title and description
        this.updatePageInfo(page);

        // Load page-specific content
        this.loadPageContent(page);

        this.currentPage = page;
    }

    updatePageInfo(page) {
        const titles = {
            dashboard: 'Dashboard',
            applications: 'Applications',
            files: 'File Manager',
            terminal: 'Terminal',
            logs: 'Application Logs',
            system: 'System Information'
        };

        const descriptions = {
            dashboard: 'Overview of your applications and system',
            applications: 'Manage your Node.js applications',
            files: 'Browse and manage your files',
            terminal: 'Execute commands in your application directories',
            logs: 'View and manage application logs',
            system: 'Monitor system performance and information'
        };

        document.getElementById('page-title').textContent = titles[page];
        document.getElementById('page-description').textContent = descriptions[page];
    }

    loadPageContent(page) {
        switch (page) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'applications':
                this.loadApplications();
                break;
            case 'files':
                this.loadFiles();
                break;
            case 'terminal':
                this.loadTerminal();
                break;
            case 'logs':
                this.loadLogs();
                break;
            case 'system':
                this.loadSystemInfo();
                break;
        }
    }

    async loadDashboard() {
        try {
            const response = await this.apiRequest('/api/dashboard/stats');
            if (response) {
                this.updateDashboardStats(response);
            }
        } catch (error) {
            this.showNotification('Failed to load dashboard', 'error');
        }
    }

    updateDashboardStats(data) {
        // Update stats cards
        document.getElementById('total-apps').textContent = data.applications.total;
        document.getElementById('running-apps').textContent = data.applications.running;
        
        if (data.system && !data.system.error) {
            document.getElementById('cpu-usage').textContent = `${data.system.cpu.toFixed(1)}%`;
            document.getElementById('memory-usage').textContent = `${data.system.memory.toFixed(1)}%`;
            
            // Update sidebar stats
            document.getElementById('sidebar-cpu').textContent = data.system.cpu.toFixed(1);
            document.getElementById('sidebar-memory').textContent = data.system.memory.toFixed(1);
        }

        // Update recent applications
        this.updateRecentApplications(data.applications);
    }

    updateRecentApplications(applications) {
        const container = document.getElementById('recent-apps');
        if (!container) return;

        container.innerHTML = '';
        
        if (applications.total === 0) {
            container.innerHTML = '<p class="text-gray-400 text-center py-4">No applications found</p>';
            return;
        }

        // Show recent applications (limit to 5)
        const recentApps = this.applications.slice(0, 5);
        recentApps.forEach(app => {
            const appElement = this.createApplicationCard(app);
            container.appendChild(appElement);
        });
    }

    createApplicationCard(app) {
        const div = document.createElement('div');
        div.className = 'flex items-center justify-between p-3 bg-gray-700 rounded-lg';
        
        const statusClass = app.status === 'online' ? 'status-online' : 'status-stopped';
        
        div.innerHTML = `
            <div class="flex items-center space-x-3">
                <div class="w-3 h-3 rounded-full ${app.status === 'online' ? 'bg-green-400' : 'bg-gray-400'}"></div>
                <div>
                    <div class="font-medium">${app.name}</div>
                    <div class="text-sm text-gray-400">${app.status}</div>
                </div>
            </div>
            <div class="flex space-x-2">
                <button onclick="panel.toggleApplication('${app.name}')" class="text-blue-400 hover:text-blue-300">
                    <i class="fas fa-${app.status === 'online' ? 'pause' : 'play'}"></i>
                </button>
                <button onclick="panel.viewApplicationLogs('${app.name}')" class="text-gray-400 hover:text-gray-300">
                    <i class="fas fa-file-alt"></i>
                </button>
            </div>
        `;
        
        return div;
    }

    async loadApplications() {
        try {
            const response = await this.apiRequest('/api/applications');
            if (response) {
                this.applications = response;
                this.updateApplicationsTable();
                this.updateApplicationsSelect();
            }
        } catch (error) {
            this.showNotification('Failed to load applications', 'error');
        }
    }

    updateApplicationsTable() {
        const tbody = document.getElementById('applications-table');
        if (!tbody) return;

        tbody.innerHTML = '';

        if (this.applications.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" class="text-center py-8 text-gray-400">
                        No applications found. Upload your first application to get started.
                    </td>
                </tr>
            `;
            return;
        }

        this.applications.forEach(app => {
            const row = this.createApplicationRow(app);
            tbody.appendChild(row);
        });
    }

    createApplicationRow(app) {
        const row = document.createElement('tr');
        
        const uptime = app.uptime ? this.formatUptime(app.uptime) : 'N/A';
        const statusClass = app.status === 'online' ? 'status-online' : 'status-stopped';
        
        row.innerHTML = `
            <td class="px-6 py-4">
                <div class="flex items-center">
                    <div class="flex-shrink-0 h-10 w-10">
                        <div class="h-10 w-10 rounded-full bg-blue-500 flex items-center justify-center">
                            <i class="fas fa-server text-white"></i>
                        </div>
                    </div>
                    <div class="ml-4">
                        <div class="text-sm font-medium text-white">${app.name}</div>
                        <div class="text-sm text-gray-400">${app.path}</div>
                    </div>
                </div>
            </td>
            <td class="px-6 py-4 whitespace-nowrap">
                <span class="status-badge ${statusClass}">${app.status}</span>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                ${app.cpu.toFixed(1)}%
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                ${(app.memory / 1024 / 1024).toFixed(1)} MB
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                ${uptime}
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <div class="flex space-x-2">
                    <button onclick="panel.toggleApplication('${app.name}')" class="text-blue-400 hover:text-blue-300">
                        <i class="fas fa-${app.status === 'online' ? 'pause' : 'play'}"></i>
                    </button>
                    <button onclick="panel.restartApplication('${app.name}')" class="text-yellow-400 hover:text-yellow-300">
                        <i class="fas fa-redo"></i>
                    </button>
                    <button onclick="panel.viewApplicationLogs('${app.name}')" class="text-green-400 hover:text-green-300">
                        <i class="fas fa-file-alt"></i>
                    </button>
                    <button onclick="panel.deleteApplication('${app.name}')" class="text-red-400 hover:text-red-300">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        
        return row;
    }

    updateApplicationsSelect() {
        const selects = ['terminal-app', 'logs-app'];
        
        selects.forEach(selectId => {
            const select = document.getElementById(selectId);
            if (select) {
                select.innerHTML = '<option value="">Select Application</option>';
                this.applications.forEach(app => {
                    const option = document.createElement('option');
                    option.value = app.name;
                    option.textContent = app.name;
                    select.appendChild(option);
                });
            }
        });
    }

    async toggleApplication(name) {
        const app = this.applications.find(a => a.name === name);
        if (!app) return;

        try {
            const action = app.status === 'online' ? 'stop' : 'start';
            const response = await this.apiRequest(`/api/applications/${name}/${action}`, {
                method: 'POST',
                body: app.status === 'online' ? {} : { scriptPath: app.script }
            });

            if (response) {
                this.showNotification(`Application ${action}ed successfully`, 'success');
                this.loadApplications();
            }
        } catch (error) {
            this.showNotification(`Failed to ${action} application`, 'error');
        }
    }

    async restartApplication(name) {
        try {
            const response = await this.apiRequest(`/api/applications/${name}/restart`, {
                method: 'POST'
            });

            if (response) {
                this.showNotification('Application restarted successfully', 'success');
                this.loadApplications();
            }
        } catch (error) {
            this.showNotification('Failed to restart application', 'error');
        }
    }

    async deleteApplication(name) {
        if (!confirm(`Are you sure you want to delete "${name}"?`)) return;

        try {
            const response = await this.apiRequest(`/api/applications/${name}`, {
                method: 'DELETE'
            });

            if (response) {
                this.showNotification('Application deleted successfully', 'success');
                this.loadApplications();
            }
        } catch (error) {
            this.showNotification('Failed to delete application', 'error');
        }
    }

    showUploadModal() {
        document.getElementById('upload-modal').classList.remove('hidden');
    }

    hideUploadModal() {
        document.getElementById('upload-modal').classList.add('hidden');
        document.getElementById('upload-form').reset();
        document.getElementById('upload-progress').classList.add('hidden');
    }

    async handleUpload() {
        const formData = new FormData();
        const fileInput = document.getElementById('app-file');
        const appName = document.getElementById('app-name').value;

        if (!fileInput.files[0] || !appName) {
            this.showNotification('Please select a file and enter application name', 'warning');
            return;
        }

        formData.append('file', fileInput.files[0]);
        formData.append('appName', appName);

        const progressDiv = document.getElementById('upload-progress');
        const progressBar = document.getElementById('progress-bar');
        const progressText = document.getElementById('progress-text');

        progressDiv.classList.remove('hidden');
        progressText.textContent = 'Uploading...';

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('auth_token')}`
                },
                body: formData
            });

            const data = await response.json();

            if (response.ok) {
                progressBar.style.width = '100%';
                progressText.textContent = 'Upload complete!';
                this.showNotification('Application uploaded successfully', 'success');
                this.hideUploadModal();
                this.loadApplications();
            } else {
                throw new Error(data.error || 'Upload failed');
            }
        } catch (error) {
            progressText.textContent = 'Upload failed';
            this.showNotification(error.message, 'error');
        }
    }

    loadFiles() {
        this.loadFileList();
    }

    async loadFileList(path = '/scripts') {
        try {
            const response = await this.apiRequest(`/api/files?dir=${encodeURIComponent(path)}`);
            if (response) {
                this.updateFileList(response, path);
            }
        } catch (error) {
            this.showNotification('Failed to load files', 'error');
        }
    }

    updateFileList(files, currentPath) {
        const container = document.getElementById('files-list');
        const pathElement = document.getElementById('current-path');
        
        if (container) {
            container.innerHTML = '';
            pathElement.textContent = currentPath;

            files.forEach(file => {
                const fileElement = this.createFileElement(file);
                container.appendChild(fileElement);
            });
        }
    }

    createFileElement(file) {
        const div = document.createElement('div');
        div.className = 'flex items-center justify-between p-3 hover:bg-gray-700 rounded-lg cursor-pointer';
        
        const icon = file.isDirectory ? 'fa-folder' : 'fa-file';
        const size = file.isDirectory ? '' : this.formatFileSize(file.size);
        
        div.innerHTML = `
            <div class="flex items-center space-x-3">
                <i class="fas ${icon} text-blue-400"></i>
                <div>
                    <div class="font-medium">${file.name}</div>
                    <div class="text-sm text-gray-400">${size}</div>
                </div>
            </div>
            <div class="text-gray-400">
                <i class="fas fa-chevron-right"></i>
            </div>
        `;
        
        div.addEventListener('click', () => {
            if (file.isDirectory) {
                this.loadFileList(file.path);
            } else {
                this.downloadFile(file.path);
            }
        });
        
        return div;
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    downloadFile(path) {
        const link = document.createElement('a');
        link.href = `/api/files/download?path=${encodeURIComponent(path)}`;
        link.download = path.split('/').pop();
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }

    loadTerminal() {
        const terminalOutput = document.getElementById('terminal-output');
        if (terminalOutput) {
            terminalOutput.innerHTML = `
                <div class="text-green-400">Welcome to Pterodactyl Terminal</div>
                <div class="text-gray-400">Select an application and type your commands below...</div>
            `;
        }
    }

    handleTerminalInput(e) {
        if (e.key === 'Enter') {
            const input = e.target.value.trim();
            if (input) {
                this.executeTerminalCommand(input);
                e.target.value = '';
            }
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.navigateTerminalHistory('up');
        } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.navigateTerminalHistory('down');
        }
    }

    async executeTerminalCommand(command) {
        const appSelect = document.getElementById('terminal-app');
        const selectedApp = appSelect.value;
        
        if (!selectedApp) {
            this.appendTerminalOutput('Please select an application first', 'error');
            return;
        }

        this.appendTerminalOutput(`$ ${command}`, 'input');
        this.terminalHistory.push(command);
        this.terminalHistoryIndex = this.terminalHistory.length;

        try {
            const response = await this.apiRequest('/api/terminal/execute', {
                method: 'POST',
                body: {
                    command,
                    cwd: `/scripts/${selectedApp}`
                }
            });

            if (response) {
                if (response.output) {
                    this.appendTerminalOutput(response.output, 'output');
                }
                if (response.error) {
                    this.appendTerminalOutput(response.error, 'error');
                }
            }
        } catch (error) {
            this.appendTerminalOutput('Command execution failed', 'error');
        }
    }

    appendTerminalOutput(text, type) {
        const terminal = document.getElementById('terminal-output');
        if (!terminal) return;

        const div = document.createElement('div');
        div.className = `terminal-${type}`;
        div.textContent = text;
        terminal.appendChild(div);
        terminal.scrollTop = terminal.scrollHeight;
    }

    navigateTerminalHistory(direction) {
        if (this.terminalHistory.length === 0) return;

        const input = document.getElementById('terminal-input');
        if (direction === 'up') {
            if (this.terminalHistoryIndex > 0) {
                this.terminalHistoryIndex--;
                input.value = this.terminalHistory[this.terminalHistoryIndex];
            }
        } else {
            if (this.terminalHistoryIndex < this.terminalHistory.length - 1) {
                this.terminalHistoryIndex++;
                input.value = this.terminalHistory[this.terminalHistoryIndex];
            } else {
                this.terminalHistoryIndex = this.terminalHistory.length;
                input.value = '';
            }
        }
    }

    clearTerminal() {
        const terminal = document.getElementById('terminal-output');
        if (terminal) {
            terminal.innerHTML = `
                <div class="text-green-400">Terminal cleared</div>
                <div class="text-gray-400">Type your commands below...</div>
            `;
        }
    }

    async loadApplicationLogs() {
        const appSelect = document.getElementById('logs-app');
        const selectedApp = appSelect.value;
        const linesSelect = document.getElementById('log-lines');
        const lines = linesSelect.value;

        if (!selectedApp) {
            document.getElementById('logs-output').innerHTML = '<div class="text-gray-400">Select an application to view logs...</div>';
            return;
        }

        try {
            const response = await this.apiRequest(`/api/applications/${selectedApp}/logs?lines=${lines}`);
            if (response && response.logs) {
                document.getElementById('logs-output').innerHTML = `<pre class="text-green-400">${response.logs}</pre>`;
            }
        } catch (error) {
            document.getElementById('logs-output').innerHTML = '<div class="text-red-400">Failed to load logs</div>';
        }
    }

    viewApplicationLogs(appName) {
        this.navigateToPage('logs');
        const logsSelect = document.getElementById('logs-app');
        if (logsSelect) {
            logsSelect.value = appName;
            this.loadApplicationLogs();
        }
    }

    async loadSystemInfo() {
        try {
            const response = await this.apiRequest('/api/system/info');
            if (response) {
                this.updateSystemInfo(response);
            }
        } catch (error) {
            this.showNotification('Failed to load system information', 'error');
        }
    }

    updateSystemInfo(info) {
        const container = document.getElementById('system-info');
        if (!container) return;

        container.innerHTML = `
            <div class="space-y-4">
                <div class="flex justify-between">
                    <span class="text-gray-400">Node.js Version</span>
                    <span class="text-white">${info.nodeVersion}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">NPM Version</span>
                    <span class="text-white">${info.npmVersion}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">PM2 Version</span>
                    <span class="text-white">${info.pm2Version}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">Platform</span>
                    <span class="text-white">${info.platform}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">Architecture</span>
                    <span class="text-white">${info.arch}</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-gray-400">Uptime</span>
                    <span class="text-white">${this.formatUptime(info.uptime * 1000)}</span>
                </div>
            </div>
        `;
    }

    updateSystemStats(stats) {
        this.systemStats = stats;
        
        if (stats.cpu !== undefined) {
            document.getElementById('cpu-usage').textContent = `${stats.cpu.toFixed(1)}%`;
            document.getElementById('sidebar-cpu').textContent = stats.cpu.toFixed(1);
        }
        
        if (stats.memory !== undefined) {
            document.getElementById('memory-usage').textContent = `${stats.memory.toFixed(1)}%`;
            document.getElementById('sidebar-memory').textContent = stats.memory.toFixed(1);
        }
    }

    updateApplicationStatus(data) {
        const app = this.applications.find(a => a.name === data.name);
        if (app) {
            app.status = data.status;
            this.updateApplicationsTable();
        }
    }

    removeApplication(name) {
        this.applications = this.applications.filter(a => a.name !== name);
        this.updateApplicationsTable();
        this.updateApplicationsSelect();
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type} fade-in`;
        notification.innerHTML = `
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <i class="fas fa-${this.getNotificationIcon(type)}"></i>
                    <span>${message}</span>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" class="text-gray-400 hover:text-white">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        `;

        const container = document.getElementById('notifications');
        container.appendChild(notification);

        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }

    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || 'info-circle';
    }

    toggleNotifications() {
        // Implementation for notifications panel
        console.log('Toggle notifications');
    }

    async apiRequest(endpoint, options = {}) {
        const token = localStorage.getItem('auth_token');
        if (!token) {
            this.showLoginModal();
            return null;
        }

        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        };

        const config = { ...defaultOptions, ...options };

        try {
            const response = await fetch(endpoint, config);
            
            if (response.status === 401) {
                localStorage.removeItem('auth_token');
                this.showLoginModal();
                return null;
            }

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            return await response.json();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    formatUptime(milliseconds) {
        const seconds = Math.floor(milliseconds / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${minutes % 60}m`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }

    loadApp() {
        document.getElementById('loading-screen').classList.add('hidden');
        this.navigateToPage('dashboard');
    }
}

// Initialize the panel when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.panel = new PterodactylPanel();
}); 