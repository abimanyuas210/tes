const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const multer = require('multer');
const { spawn } = require('child_process');
const unzipper = require('unzipper');
const pm2 = require('pm2');
const { exec } = require('child_process');
const util = require('util');
const execAsync = util.promisify(exec);

const app = express();
const PORT = process.env.PORT || 3000;

const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const DB_PATH = path.join(__dirname, 'db.json');

fs.ensureDirSync(SCRIPTS_DIR);

const upload = multer({ 
  dest: '/tmp',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
    files: 1
  }
});

// Terminal session storage
const terminalSessions = new Map();

app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Helper: update status dari pm2 list
async function updatePM2Status() {
  return new Promise((resolve) => {
    pm2.connect((err) => {
      if (err) {
        console.error('PM2 connection error:', err);
        return resolve();
      }
      
      pm2.list((err, list) => {
        if (err) {
          console.error('PM2 list error:', err);
          pm2.disconnect();
          return resolve();
        }
        
        let db = [];
        try { 
          db = fs.readJsonSync(DB_PATH); 
        } catch (e) {
          console.error('Failed to read DB:', e);
          pm2.disconnect();
          return resolve();
        }
        
        db.forEach(script => {
          const found = list.find(proc => proc.name === script.name);
          if (found) {
            script.status = found.pm2_env.status === 'online' ? '🟢 Online' : '🔴 Offline';
          } else {
            script.status = 'stopped';
          }
        });
        
        try {
          fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
        } catch (e) {
          console.error('Failed to write DB:', e);
        }
        
        pm2.disconnect();
        resolve();
      });
    });
  });
}

// API: Get all scripts (with PM2 status)
app.get('/api/scripts', async (req, res) => {
  await updatePM2Status();
  let db = [];
  try {
    db = fs.readJsonSync(DB_PATH);
  } catch (e) {}
  res.json(db);
});

// API: Upload script
app.post('/api/upload', upload.single('file'), async (req, res) => {
  console.log('Script upload request received');
  console.log('Request body:', req.body);
  console.log('Request file:', req.file);
  
  const { name, command } = req.body;
  const file = req.file;
  
  if (!name || !command || !file) {
    console.log('Missing required fields:', { name, command, file: !!file });
    return res.status(400).json({ message: 'Lengkapi semua field!' });
  }
  
  console.log('Processing upload for:', name, 'Command:', command, 'File:', file.originalname);
  
  const folder = name.replace(/[^a-zA-Z0-9_-]/g, '_');
  const scriptPath = path.join(SCRIPTS_DIR, folder);
  
  try {
    // Create script directory
    await fs.ensureDir(scriptPath);
    console.log('Script directory created:', scriptPath);
    
    let mainFile = '';
    
    if (file.originalname.endsWith('.zip')) {
      console.log('Processing ZIP file...');
      
      // Extract ZIP to temporary directory first
      const tempExtractPath = path.join(SCRIPTS_DIR, 'temp_' + Date.now());
      await fs.ensureDir(tempExtractPath);
      
      const extractStream = fs.createReadStream(file.path).pipe(unzipper.Extract({ path: tempExtractPath }));
      await new Promise((resolve, reject) => {
        extractStream.on('close', resolve);
        extractStream.on('error', reject);
      });
      console.log('ZIP extracted to temp directory');
      
      // Find the main entry file
      const extractedFiles = await fs.readdir(tempExtractPath);
      console.log('Extracted files:', extractedFiles);
      
      // Check if there's only one folder and it contains index.js
      let shouldMoveContents = false;
      let sourceFolder = null;
      
      if (extractedFiles.length === 1) {
        const singleItem = extractedFiles[0];
        const singleItemPath = path.join(tempExtractPath, singleItem);
        const singleItemStat = await fs.stat(singleItemPath);
        
        if (singleItemStat.isDirectory()) {
          console.log('Found single folder:', singleItem);
          const folderContents = await fs.readdir(singleItemPath);
          console.log('Folder contents:', folderContents);
          
          // Check if folder contains index.js or other entry files
          const possibleEntryFiles = ['index.js', 'main.js', 'app.js', 'bot.js', 'start.js'];
          const hasEntryFile = folderContents.some(file => possibleEntryFiles.includes(file));
          
          if (hasEntryFile) {
            console.log('Single folder contains entry file, will move contents out');
            shouldMoveContents = true;
            sourceFolder = singleItemPath;
          }
        }
      }
      
      // Look for common entry files
      const possibleEntryFiles = ['index.js', 'main.js', 'app.js', 'bot.js', 'start.js'];
      let foundEntryFile = null;
      
      for (const entryFile of possibleEntryFiles) {
        const entryPath = path.join(tempExtractPath, entryFile);
        if (await fs.pathExists(entryPath)) {
          foundEntryFile = entryFile;
          break;
        }
      }
      
      if (!foundEntryFile) {
        // If no entry file found, use the first .js file
        for (const file of extractedFiles) {
          if (file.endsWith('.js')) {
            foundEntryFile = file;
            break;
          }
        }
      }
      
      if (foundEntryFile) {
        mainFile = foundEntryFile;
        console.log('Found entry file:', mainFile);
      } else {
        // Create a default index.js if no entry file found
        mainFile = 'index.js';
        console.log('No entry file found, will create default index.js');
      }
      
      // Copy files from temp to script directory
      if (shouldMoveContents && sourceFolder) {
        console.log('Moving contents from single folder to script directory');
        const folderContents = await fs.readdir(sourceFolder);
        
        for (const item of folderContents) {
          const sourcePath = path.join(sourceFolder, item);
          const targetPath = path.join(scriptPath, item);
          
          const stat = await fs.stat(sourcePath);
          if (stat.isDirectory()) {
            await fs.copy(sourcePath, targetPath);
          } else {
            await fs.copy(sourcePath, targetPath);
          }
        }
      } else {
        // Copy all files from temp to script directory
        for (const item of extractedFiles) {
          const sourcePath = path.join(tempExtractPath, item);
          const targetPath = path.join(scriptPath, item);
          
          const stat = await fs.stat(sourcePath);
          if (stat.isDirectory()) {
            await fs.copy(sourcePath, targetPath);
          } else {
            await fs.copy(sourcePath, targetPath);
          }
        }
      }
      
      // Clean up temp directory
      await fs.remove(tempExtractPath);
      
    } else if (file.originalname.endsWith('.js')) {
      console.log('Processing JS file...');
      mainFile = 'index.js';
      await fs.copy(file.path, path.join(scriptPath, mainFile));
      console.log('JS file copied as index.js');
    } else {
      console.log('Invalid file type:', file.originalname);
      return res.status(400).json({ message: 'File harus .js atau .zip' });
    }
    
    // Create package.json if it doesn't exist
    const packageJsonPath = path.join(scriptPath, 'package.json');
    if (!await fs.pathExists(packageJsonPath)) {
      const packageJson = {
        name: folder,
        version: "1.0.0",
        description: `Script: ${name}`,
        main: mainFile,
        scripts: {
          start: command,
          test: "echo \"Error: no test specified\" && exit 1"
        },
        dependencies: {}
      };
      await fs.writeJson(packageJsonPath, packageJson, { spaces: 2 });
      console.log('Created package.json');
    }
    
    // Auto install npm modules if package.json exists
    console.log('Checking for npm dependencies...');
    if (await fs.pathExists(packageJsonPath)) {
      try {
        console.log('Installing npm dependencies...');
        const npmInstall = spawn('npm', ['install'], { 
          cwd: scriptPath,
          stdio: ['pipe', 'pipe', 'pipe']
        });
        
        let npmOutput = '', npmError = '';
        npmInstall.stdout.on('data', (data) => {
          npmOutput += data.toString();
          console.log('NPM stdout:', data.toString());
        });
        npmInstall.stderr.on('data', (data) => {
          npmError += data.toString();
          console.log('NPM stderr:', data.toString());
        });
        
        await new Promise((resolve, reject) => {
          npmInstall.on('close', (code) => {
            if (code === 0) {
              console.log('NPM install completed successfully');
              resolve();
            } else {
              console.log('NPM install failed with code:', code);
              console.log('NPM error:', npmError);
              // Don't reject, just log the error
              resolve();
            }
          });
        });
      } catch (npmErr) {
        console.error('NPM install error:', npmErr);
        // Continue even if npm install fails
      }
    }
    
    // Create README.md if it doesn't exist
    const readmePath = path.join(scriptPath, 'README.md');
    if (!await fs.pathExists(readmePath)) {
      const readme = `# ${name}

Script uploaded via WA Panel.

## Usage

\`\`\`bash
${command}
\`\`\`

## Files

- \`${mainFile}\` - Main entry file
- \`package.json\` - Project configuration

## Dependencies

Run \`npm install\` to install dependencies.
`;
      await fs.writeFile(readmePath, readme);
      console.log('Created README.md');
    }
    
    console.log('Testing script with command:', command);
    console.log('Working directory:', scriptPath);
    console.log('Main file:', mainFile);
    
    // Test the script
    const [cmd, ...args] = command.split(' ');
    const testProc = spawn(cmd, args, { 
      cwd: scriptPath,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let stdout = '', stderr = '';
    let finished = false;
    
    const timeout = setTimeout(() => {
      if (!finished) {
        console.log('Test timeout reached, killing process');
        testProc.kill('SIGKILL');
        finished = true;
      }
    }, 10000);
    
    testProc.stdout.on('data', d => { 
      stdout += d.toString(); 
      console.log('Test stdout:', d.toString());
    });
    testProc.stderr.on('data', d => { 
      stderr += d.toString(); 
      console.log('Test stderr:', d.toString());
    });
    
    testProc.on('close', code => {
      clearTimeout(timeout);
      if (finished) return;
      finished = true;
      
      console.log('Test process closed with code:', code);
      
      let db = [];
      try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
      let testResult = '', lastError = '';
      
      if (code === 0) {
        testResult = '✅ OK';
        lastError = '';
        console.log('Test passed');
      } else {
        testResult = '❌ ERROR';
        lastError = stderr || stdout || 'Unknown error';
        console.log('Test failed:', lastError);
      }
      
      const scriptData = {
        name,
        folder,
        command,
        mainFile: mainFile,
        status: 'stopped',
        testResult,
        lastError,
        uploadTime: new Date().toISOString()
      };
      
      db = db.filter(s => s.name !== name);
      db.push(scriptData);
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      
      if (testResult === '✅ OK') {
        res.json({ message: 'Upload & test berhasil!' });
      } else {
        res.json({ message: 'Test gagal: ' + lastError });
      }
    });
    
  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ message: 'Gagal upload: ' + err.message });
  }
});

// API: Start script (PM2)
app.post('/api/pm2/start/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    const mainFile = script.mainFile || 'index.js';
    const mainFilePath = path.join(scriptPath, mainFile);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script directory not found' });
    }
    
    if (!await fs.pathExists(mainFilePath)) {
      return res.status(404).json({ error: `Main file ${mainFile} not found` });
    }
    
    // Check and install missing modules
    const missingModules = await this.checkMissingModules(name);
    if (missingModules.length > 0) {
      console.log(`Installing missing modules for ${name}: ${missingModules.join(', ')}`);
      await this.installMissingModules(name);
    }
    
    console.log(`Starting ${name} with PM2: ${mainFilePath}`);
    
    const process = spawn('pm2', ['start', mainFilePath, '--name', name], {
      cwd: scriptPath,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let stdout = '', stderr = '';
    
    process.stdout.on('data', (data) => {
      stdout += data.toString();
      console.log(`PM2 start stdout: ${data.toString()}`);
    });
    
    process.stderr.on('data', (data) => {
      stderr += data.toString();
      console.log(`PM2 start stderr: ${data.toString()}`);
    });
    
    process.on('close', (code) => {
      console.log(`PM2 start completed with code: ${code}`);
      
      if (code === 0) {
        res.json({
          success: true,
          message: `${name} started successfully`,
          stdout: stdout
        });
      } else {
        res.status(500).json({
          success: false,
          error: `Failed to start ${name}`,
          stderr: stderr
        });
      }
    });
    
    process.on('error', (error) => {
      console.error('PM2 start error:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    });
    
  } catch (error) {
    console.error('Start script error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Restart script (PM2)
app.post('/api/pm2/restart/:name', async (req, res) => {
  try {
    const { name } = req.params;
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
    
    return new Promise((resolve, reject) => {
      pm2.connect((err) => {
        if (err) {
          pm2.disconnect();
          return res.status(500).json({ message: 'PM2 connection error' });
        }
        
        pm2.restart(name, (err) => {
          pm2.disconnect();
          if (err) {
            return res.status(500).json({ message: 'Gagal restart: ' + err.message });
          }
          
          script.status = '🟢 Online';
          fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
          res.json({ message: 'Script direstart!' });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// API: Stop script (PM2)
app.post('/api/pm2/stop/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    console.log(`Stopping ${name} with PM2`);
    
    const process = spawn('pm2', ['stop', name], {
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let stdout = '', stderr = '';
    
    process.stdout.on('data', (data) => {
      stdout += data.toString();
      console.log(`PM2 stop stdout: ${data.toString()}`);
    });
    
    process.stderr.on('data', (data) => {
      stderr += data.toString();
      console.log(`PM2 stop stderr: ${data.toString()}`);
    });
    
    process.on('close', (code) => {
      console.log(`PM2 stop completed with code: ${code}`);
      
      if (code === 0) {
        res.json({
          success: true,
          message: `${name} stopped successfully`,
          stdout: stdout
        });
      } else {
        res.status(500).json({
          success: false,
          error: `Failed to stop ${name}`,
          stderr: stderr
        });
      }
    });
    
    process.on('error', (error) => {
      console.error('PM2 stop error:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    });
    
  } catch (error) {
    console.error('Stop script error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Delete script (PM2)
app.post('/api/pm2/delete/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    console.log(`Deleting ${name} with PM2`);
    
    const process = spawn('pm2', ['delete', name], {
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let stdout = '', stderr = '';
    
    process.stdout.on('data', (data) => {
      stdout += data.toString();
      console.log(`PM2 delete stdout: ${data.toString()}`);
    });
    
    process.stderr.on('data', (data) => {
      stderr += data.toString();
      console.log(`PM2 delete stderr: ${data.toString()}`);
    });
    
    process.on('close', (code) => {
      console.log(`PM2 delete completed with code: ${code}`);
      
      if (code === 0) {
        res.json({
          success: true,
          message: `${name} deleted successfully`,
          stdout: stdout
        });
      } else {
        res.status(500).json({
          success: false,
          error: `Failed to delete ${name}`,
          stderr: stderr
        });
      }
    });
    
    process.on('error', (error) => {
      console.error('PM2 delete error:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    });
    
  } catch (error) {
    console.error('Delete script error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Get last log/error
app.get('/api/log/:name', (req, res) => {
  const { name } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  // Cek log/error dari PM2
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.describe(name, (err, desc) => {
      pm2.disconnect();
      if (err || !desc || !desc[0]) return res.json({ log: script.lastError || '-' });
      const out = desc[0].pm2_env.pm_out_log_path;
      const errLog = desc[0].pm2_env.pm_err_log_path;
      let log = '';
      try {
        log = fs.readFileSync(errLog, 'utf8').split('\n').slice(-10).join('\n');
      } catch (e) {}
      res.json({ log: log || script.lastError || '-' });
    });
  });
});

// API: Update system (alias for self-update)
app.post('/api/update', upload.single('update'), async (req, res) => {
  console.log('System update request received');
  
  const file = req.file;
  if (!file) {
    console.log('No file provided');
    return res.status(400).json({ message: 'No update file provided' });
  }

  console.log('File received:', file.originalname, 'Size:', file.size);

  if (!file.originalname.endsWith('.zip')) {
    console.log('Invalid file type:', file.originalname);
    return res.status(400).json({ message: 'Update file must be a ZIP file' });
  }

  if (file.size === 0) {
    console.log('Empty file received');
    return res.status(400).json({ message: 'Update file is empty' });
  }

  const updateDir = path.join(__dirname, '../temp_update');
  const backupDir = path.join(__dirname, '../backup_' + Date.now());
  const projectRoot = path.join(__dirname, '..');

  console.log('Paths:', { updateDir, backupDir, projectRoot });

  try {
    // Create backup - exclude temp and backup directories
    console.log('Creating backup...');
    await fs.ensureDir(backupDir);
    
    const projectFiles = await fs.readdir(projectRoot);
    for (const item of projectFiles) {
      // Skip backup and temp directories
      if (item.startsWith('backup_') || item === 'temp_update' || item === 'node_modules') {
        console.log('Skipping backup item:', item);
        continue;
      }
      
      const sourcePath = path.join(projectRoot, item);
      const targetPath = path.join(backupDir, item);
      
      const stat = await fs.stat(sourcePath);
      if (stat.isDirectory()) {
        await fs.copy(sourcePath, targetPath);
      } else {
        await fs.copy(sourcePath, targetPath);
      }
    }
    console.log('Backup created successfully');
    
    // Extract update
    console.log('Extracting update...');
    await fs.ensureDir(updateDir);
    await fs.emptyDir(updateDir); // Clear directory first
    
    const extractStream = fs.createReadStream(file.path).pipe(unzipper.Extract({ path: updateDir }));
    await new Promise((resolve, reject) => {
      extractStream.on('close', resolve);
      extractStream.on('error', reject);
    });
    console.log('Update extracted successfully');
    
    // Find the main project folder in extracted files
    const extractedFiles = await fs.readdir(updateDir);
    console.log('Extracted files:', extractedFiles);
    
    let sourceDir = updateDir;
    
    // If there's a single folder, use it as source
    if (extractedFiles.length === 1) {
      const firstItem = path.join(updateDir, extractedFiles[0]);
      const stat = await fs.stat(firstItem);
      if (stat.isDirectory()) {
        sourceDir = firstItem;
        console.log('Using single directory as source:', sourceDir);
      }
    }
    
    // Copy files to project root (excluding sensitive files)
    console.log('Applying update...');
    const filesToCopy = await fs.readdir(sourceDir);
    console.log('Files to copy:', filesToCopy);
    
    for (const item of filesToCopy) {
      const sourcePath = path.join(sourceDir, item);
      const targetPath = path.join(projectRoot, item);
      
      // Skip sensitive files and directories
      if (['node_modules', '.git', 'backup_', 'temp_update', 'package-lock.json'].some(skip => item.includes(skip))) {
        console.log('Skipping:', item);
        continue;
      }
      
      const stat = await fs.stat(sourcePath);
      if (stat.isDirectory()) {
        console.log('Copying directory:', item);
        // Remove existing directory first if it exists
        if (await fs.pathExists(targetPath)) {
          await fs.remove(targetPath);
        }
        await fs.copy(sourcePath, targetPath);
      } else {
        console.log('Copying file:', item);
        await fs.copy(sourcePath, targetPath);
      }
    }
    
    // Clean up
    console.log('Cleaning up...');
    await fs.remove(updateDir);
    await fs.remove(file.path);
    console.log('Cleanup completed');
    
    console.log('Update applied successfully');
    res.json({ 
      message: 'Update applied successfully! Server will restart in 3 seconds...',
      backupLocation: backupDir
    });
    
    // Restart server after 3 seconds
    setTimeout(() => {
      console.log('Restarting server...');
      process.exit(0);
    }, 3000);
    
  } catch (error) {
    console.error('Update failed:', error);
    
    // Try to restore from backup
    try {
      if (await fs.pathExists(backupDir)) {
        console.log('Restoring from backup...');
        
        const backupFiles = await fs.readdir(backupDir);
        for (const item of backupFiles) {
          const sourcePath = path.join(backupDir, item);
          const targetPath = path.join(projectRoot, item);
          
          const stat = await fs.stat(sourcePath);
          if (stat.isDirectory()) {
            if (await fs.pathExists(targetPath)) {
              await fs.remove(targetPath);
            }
            await fs.copy(sourcePath, targetPath);
          } else {
            await fs.copy(sourcePath, targetPath);
          }
        }
        
        await fs.remove(backupDir);
        console.log('Restore completed');
      }
    } catch (restoreError) {
      console.error('Failed to restore from backup:', restoreError);
    }
    
    // Clean up temp files
    try {
      if (await fs.pathExists(updateDir)) {
        await fs.remove(updateDir);
      }
      if (file && await fs.pathExists(file.path)) {
        await fs.remove(file.path);
      }
    } catch (cleanupError) {
      console.error('Failed to cleanup temp files:', cleanupError);
    }
    
    res.status(500).json({ 
      message: 'Update failed: ' + error.message,
      error: error.message,
      stack: error.stack
    });
  }
});

// Get update status
app.get('/api/update-status', (req, res) => {
  const packageJson = require('../package.json');
  res.json({
    version: packageJson.version || '1.0.0',
    lastUpdate: new Date().toISOString(),
    serverUptime: process.uptime()
  });
});

// Execute command in terminal with real-time output
app.post('/api/terminal/execute', (req, res) => {
  const { name, command } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const scriptPath = path.join(SCRIPTS_DIR, script.folder);
  const sessionId = `${name}_${Date.now()}`;
  
  console.log('Executing command:', command, 'in directory:', scriptPath);
  
  // Parse command
  const [cmd, ...args] = command.split(' ');
  const process = spawn(cmd, args, { 
    cwd: scriptPath,
    stdio: ['pipe', 'pipe', 'pipe'],
    env: {
      ...process.env,
      NODE_ENV: 'production'
    }
  });
  
  let output = '';
  let error = '';
  
  process.stdout.on('data', (data) => {
    output += data.toString();
    console.log('Terminal stdout:', data.toString());
  });
  
  process.stderr.on('data', (data) => {
    error += data.toString();
    console.log('Terminal stderr:', data.toString());
  });
  
  process.on('close', (code) => {
    console.log('Terminal process closed with code:', code);
    terminalSessions.set(sessionId, {
      output: output,
      error: error,
      exitCode: code,
      finished: true,
      pid: process.pid
    });
  });
  
  process.on('error', (err) => {
    console.error('Terminal process error:', err);
    terminalSessions.set(sessionId, {
      output: output,
      error: error + '\nProcess error: ' + err.message,
      exitCode: -1,
      finished: true,
      pid: null
    });
  });
  
  res.json({ 
    sessionId: sessionId,
    message: 'Command started',
    pid: process.pid
  });
});

// Get terminal output
app.get('/api/terminal/output/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const session = terminalSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ message: 'Session not found' });
  }
  
  res.json(session);
});

// API: Get script files
app.get('/api/script/files/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script directory not found' });
    }
    
    const files = await this.getDirectoryFiles(scriptPath);
    
    res.json({
      success: true,
      files: files,
      script: script
    });
    
  } catch (error) {
    console.error('Get script files error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Get file content
app.get('/api/script/file/:name/*', async (req, res) => {
  try {
    const { name } = req.params;
    const filePath = req.params[0];
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const fullPath = path.join(SCRIPTS_DIR, script.folder, filePath);
    
    // Security check: ensure file is within script directory
    const scriptDir = path.resolve(path.join(SCRIPTS_DIR, script.folder));
    const requestedPath = path.resolve(fullPath);
    
    if (!requestedPath.startsWith(scriptDir)) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    if (!await fs.pathExists(fullPath)) {
      return res.status(404).json({ error: 'File not found' });
    }
    
    const stat = await fs.stat(fullPath);
    if (stat.isDirectory()) {
      const files = await this.getDirectoryFiles(fullPath);
      return res.json({
        success: true,
        type: 'directory',
        files: files
      });
    }
    
    // Check if file is readable
    const content = await fs.readFile(fullPath, 'utf8');
    
    res.json({
      success: true,
      type: 'file',
      content: content,
      size: stat.size,
      modified: stat.mtime.toISOString()
    });
    
  } catch (error) {
    console.error('Get file content error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Helper function to get directory files
async function getDirectoryFiles(dirPath) {
  const files = await fs.readdir(dirPath);
  const fileStats = [];
  
  for (const file of files) {
    const filePath = path.join(dirPath, file);
    const stat = await fs.stat(filePath);
    fileStats.push({
      name: file,
      isDirectory: stat.isDirectory(),
      size: stat.size,
      modified: stat.mtime.toISOString()
    });
  }
  
  return fileStats;
}

// API: Install missing modules for script
app.post('/api/script/install/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script directory not found' });
    }
    
    const packageJsonPath = path.join(scriptPath, 'package.json');
    if (!await fs.pathExists(packageJsonPath)) {
      return res.status(400).json({ error: 'No package.json found' });
    }
    
    console.log(`Installing modules for ${name} in ${scriptPath}`);
    
    const process = spawn('npm', ['install'], {
      cwd: scriptPath,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let stdout = '', stderr = '';
    
    process.stdout.on('data', (data) => {
      stdout += data.toString();
      console.log(`npm install stdout: ${data.toString()}`);
    });
    
    process.stderr.on('data', (data) => {
      stderr += data.toString();
      console.log(`npm install stderr: ${data.toString()}`);
    });
    
    process.on('close', (code) => {
      console.log(`npm install completed with code: ${code}`);
      
      if (code === 0) {
        res.json({
          success: true,
          message: 'Modules installed successfully',
          stdout: stdout
        });
      } else {
        res.status(500).json({
          success: false,
          error: 'Failed to install modules',
          stderr: stderr
        });
      }
    });
    
    process.on('error', (error) => {
      console.error('npm install error:', error);
      res.status(500).json({
        success: false,
        error: error.message
      });
    });
    
  } catch (error) {
    console.error('Install modules error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Check missing modules for script
app.get('/api/script/check-modules/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script directory not found' });
    }
    
    const packageJsonPath = path.join(scriptPath, 'package.json');
    const nodeModulesPath = path.join(scriptPath, 'node_modules');
    
    const hasPackageJson = await fs.pathExists(packageJsonPath);
    const hasNodeModules = await fs.pathExists(nodeModulesPath);
    
    if (!hasPackageJson) {
      return res.json({
        success: true,
        missingModules: [],
        hasPackageJson: false,
        hasNodeModules: false
      });
    }
    
    if (hasNodeModules) {
      return res.json({
        success: true,
        missingModules: [],
        hasPackageJson: true,
        hasNodeModules: true
      });
    }
    
    // Read package.json to get dependencies
    const packageJson = await fs.readJson(packageJsonPath);
    const dependencies = {
      ...packageJson.dependencies,
      ...packageJson.devDependencies
    };
    
    const missingModules = Object.keys(dependencies);
    
    res.json({
      success: true,
      missingModules: missingModules,
      hasPackageJson: true,
      hasNodeModules: false
    });
    
  } catch (error) {
    console.error('Check modules error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Get PM2 status
app.get('/api/pm2/status', (req, res) => {
  pm2.connect((err) => {
    if (err) {
      return res.status(500).json({ message: 'PM2 connection error' });
    }
    
    pm2.list((err, list) => {
      pm2.disconnect();
      if (err) {
        return res.status(500).json({ message: 'PM2 list error' });
      }
      
      res.json({ processes: list || [] });
    });
  });
});

// API: Get script status
app.get('/api/pm2/status/:name', (req, res) => {
  const { name } = req.params;
  
  pm2.connect((err) => {
    if (err) {
      return res.status(500).json({ message: 'PM2 connection error' });
    }
    
    pm2.describe(name, (err, desc) => {
      pm2.disconnect();
      if (err || !desc || !desc[0]) {
        return res.json({ status: 'stopped' });
      }
      
      const process = desc[0];
      res.json({
        status: process.pm2_env.status,
        uptime: process.pm2_env.pm_uptime,
        memory: process.monit.memory,
        cpu: process.monit.cpu
      });
    });
  });
});

// API: Get system logs
app.get('/api/system/logs', (req, res) => {
  try {
    // For now, return empty logs since we don't have a proper logging system
    // In the future, this could read from actual log files
    res.json({
      logs: [
        {
          timestamp: new Date().toISOString(),
          level: 'info',
          message: 'System is running normally'
        },
        {
          timestamp: new Date(Date.now() - 60000).toISOString(),
          level: 'info',
          message: 'WA Panel started successfully'
        }
      ]
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load system logs' });
  }
});

// API: Execute command in script directory
app.post('/api/script/execute', async (req, res) => {
  try {
    const { name, command } = req.body;
    
    if (!name || !command) {
      return res.status(400).json({ error: 'Script name and command are required' });
    }
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script directory not found' });
    }
    
    console.log(`Executing command in ${scriptPath}: ${command}`);
    
    const [cmd, ...args] = command.split(' ');
    const process = spawn(cmd, args, {
      cwd: scriptPath,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, NODE_ENV: 'production' }
    });
    
    let stdout = '', stderr = '';
    let finished = false;
    
    const timeout = setTimeout(() => {
      if (!finished) {
        console.log('Command timeout reached, killing process');
        process.kill('SIGKILL');
        finished = true;
      }
    }, 30000); // 30 seconds timeout
    
    process.stdout.on('data', (data) => {
      stdout += data.toString();
      console.log('Command stdout:', data.toString());
    });
    
    process.stderr.on('data', (data) => {
      stderr += data.toString();
      console.log('Command stderr:', data.toString());
    });
    
    process.on('close', (code) => {
      clearTimeout(timeout);
      if (finished) return;
      finished = true;
      
      console.log(`Command completed with code: ${code}`);
      
      res.json({
        success: code === 0,
        exitCode: code,
        stdout: stdout,
        stderr: stderr,
        command: command,
        workingDirectory: scriptPath
      });
    });
    
    process.on('error', (error) => {
      clearTimeout(timeout);
      if (finished) return;
      finished = true;
      
      console.error('Command error:', error);
      res.status(500).json({
        success: false,
        error: error.message,
        command: command,
        workingDirectory: scriptPath
      });
    });
    
  } catch (error) {
    console.error('Execute command error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Get script directory info
app.get('/api/script/info/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script directory not found' });
    }
    
    // Get directory contents
    const files = await fs.readdir(scriptPath);
    const fileStats = [];
    
    for (const file of files) {
      const filePath = path.join(scriptPath, file);
      const stat = await fs.stat(filePath);
      fileStats.push({
        name: file,
        isDirectory: stat.isDirectory(),
        size: stat.size,
        modified: stat.mtime.toISOString()
      });
    }
    
    // Check for package.json
    const packageJsonPath = path.join(scriptPath, 'package.json');
    let packageInfo = null;
    if (await fs.pathExists(packageJsonPath)) {
      try {
        packageInfo = await fs.readJson(packageJsonPath);
      } catch (e) {
        console.error('Failed to read package.json:', e);
      }
    }
    
    // Check for node_modules
    const nodeModulesPath = path.join(scriptPath, 'node_modules');
    const hasNodeModules = await fs.pathExists(nodeModulesPath);
    
    res.json({
      script: script,
      directory: scriptPath,
      files: fileStats,
      packageJson: packageInfo,
      hasNodeModules: hasNodeModules,
      mainFile: script.mainFile || 'index.js'
    });
    
  } catch (error) {
    console.error('Get script info error:', error);
    res.status(500).json({ error: error.message });
  }
});

// API: Debug script directory
app.post('/api/script/debug/:name', async (req, res) => {
  try {
    const { name } = req.params;
    
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    
    if (!script) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    
    const debugInfo = {
      scriptName: name,
      scriptPath: scriptPath,
      exists: await fs.pathExists(scriptPath),
      permissions: null,
      files: [],
      errors: []
    };
    
    if (debugInfo.exists) {
      try {
        // Check permissions
        const stat = await fs.stat(scriptPath);
        debugInfo.permissions = {
          mode: stat.mode,
          uid: stat.uid,
          gid: stat.gid
        };
        
        // List files
        const files = await fs.readdir(scriptPath);
        debugInfo.files = files;
        
        // Check main file
        const mainFile = script.mainFile || 'index.js';
        const mainFilePath = path.join(scriptPath, mainFile);
        debugInfo.mainFile = {
          name: mainFile,
          path: mainFilePath,
          exists: await fs.pathExists(mainFilePath)
        };
        
        // Check package.json
        const packageJsonPath = path.join(scriptPath, 'package.json');
        debugInfo.packageJson = {
          exists: await fs.pathExists(packageJsonPath),
          path: packageJsonPath
        };
        
        // Check node_modules
        const nodeModulesPath = path.join(scriptPath, 'node_modules');
        debugInfo.nodeModules = {
          exists: await fs.pathExists(nodeModulesPath),
          path: nodeModulesPath
        };
        
      } catch (error) {
        debugInfo.errors.push(`Failed to read directory: ${error.message}`);
      }
    } else {
      debugInfo.errors.push('Script directory does not exist');
    }
    
    res.json(debugInfo);
    
  } catch (error) {
    console.error('Debug script error:', error);
    res.status(500).json({ error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`WA Panel aktif di http://localhost:${PORT}`);
}); 