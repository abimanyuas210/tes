# WA Panel

Panel web sederhana untuk mengelola dan menjalankan script WhatsApp (WA) via PM2. Kompatibel dengan Termux + Ngrok.

## Fitur Utama
- Upload file script WA (.zip/.js)
- Custom command untuk menjalankan script
- Integrasi PM2 (start/stop/restart/delete/status)
- Testing script otomatis sebelum dijalankan PM2
- Panel web simpel (HTML/CSS/JS tanpa framework)
- Ngrok ready (port 3000)
- 100% Termux compatible
- Data disimpan di `db.json`

## Struktur Direktori
```
wa-panel/
├── backend/
│   ├── server.js
│   ├── db.json
│   └── scripts/
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── start.sh
├── ngrok.sh
├── README.md
```

## Modul yang Digunakan
- express
- cors
- pm2
- multer
- fs-extra
- child_process

## Cara Pakai Singkat
1. Jalankan `start.sh` di Termux
2. Akses panel di port 3000
3. Untuk expose ke internet, jalankan `ngrok.sh` 