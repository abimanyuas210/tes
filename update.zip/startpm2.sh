#!/bin/bash

# WA Panel - Start with PM2
# This script starts the WA Panel using PM2 without installing modules

echo "🚀 Starting WA Panel with PM2..."

# Check if PM2 is installed
if ! command -v pm2 &> /dev/null; then
    echo "❌ PM2 is not installed. Installing PM2..."
    npm install -g pm2
fi

# Check if we're in the right directory
if [ ! -f "backend/server.js" ]; then
    echo "❌ Please run this script from the wa-panel directory"
    exit 1
fi

# Create scripts directory if it doesn't exist
mkdir -p backend/scripts

# Create db.json if it doesn't exist
if [ ! -f "backend/db.json" ]; then
    echo '[]' > backend/db.json
fi

# Stop existing process if running
pm2 stop wa-panel 2>/dev/null
pm2 delete wa-panel 2>/dev/null

# Start the application with PM2
echo "📦 Starting WA Panel..."
pm2 start backend/server.js --name "wa-panel" --cwd "$(pwd)" --env production

# Check if started successfully
if [ $? -eq 0 ]; then
    echo "✅ WA Panel started successfully!"
    echo "🌐 Access the panel at: http://localhost:3000"
    echo ""
    echo "📋 PM2 Commands:"
    echo "  pm2 status          - Check status"
    echo "  pm2 logs wa-panel   - View logs"
    echo "  pm2 restart wa-panel - Restart panel"
    echo "  pm2 stop wa-panel   - Stop panel"
    echo ""
    echo "🔧 To start with ngrok (for external access):"
    echo "  ./ngrok.sh"
else
    echo "❌ Failed to start WA Panel"
    exit 1
fi

# Show PM2 status
echo ""
echo "📊 Current PM2 Status:"
pm2 status

echo ""
echo "🎉 WA Panel is ready! Open http://localhost:3000 in your browser" 