// WA Panel - Script Management System
class WAPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.scripts = [];
        this.isLoading = false;
        this.retryAttempts = 0;
        this.maxRetries = 3;
        this.currentTerminalScript = null;
        this.terminalOutput = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadScripts();
        this.updateDashboardStats();
        this.setupNavigation();
        this.setupErrorHandling();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.getAttribute('href').substring(1);
                this.showSection(section);
            });
        });

        // Sidebar toggle
        const sidebarToggle = document.querySelector('.sidebar-toggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                this.toggleSidebar();
            });
        }

        // Upload forms
        const uploadForm = document.getElementById('uploadForm');
        if (uploadForm) {
            uploadForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.uploadScript(e.target);
            });
        }

        // System update form
        const updateForm = document.getElementById('updateForm');
        if (updateForm) {
            updateForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleSystemUpdate(e.target);
            });
        }

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.hideAllModals();
            });
        });

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.hideAllModals();
                }
            });
        });

        // File upload styling
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', (e) => {
                this.handleFileUpload(e);
            });
        });

        // Terminal command input
        const terminalCommand = document.getElementById('terminalCommand');
        if (terminalCommand) {
            terminalCommand.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.executeTerminalCommand();
                }
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
    }

    setupNavigation() {
        // Set active nav item
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });
    }

    setupErrorHandling() {
        // Global error handler
        window.addEventListener('error', (e) => {
            console.error('Global error:', e.error);
            this.showNotification('An unexpected error occurred', 'error');
        });

        // Unhandled promise rejection
        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled promise rejection:', e.reason);
            this.showNotification('Network error occurred', 'error');
        });
    }

    handleFileUpload(e) {
        const file = e.target.files[0];
        if (file) {
            const label = e.target.nextElementSibling;
            const span = label?.querySelector('span');
            if (span) {
                span.textContent = file.name;
            }
            
            // Auto-fill script name if empty
            const nameInput = e.target.closest('form')?.querySelector('input[name="name"]');
            if (nameInput && !nameInput.value) {
                const name = file.name.replace(/\.[^/.]+$/, '');
                nameInput.value = name;
            }
        }
    }

    handleKeyboardShortcuts(e) {
        // Ctrl/Cmd + K to focus search
        if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
            e.preventDefault();
            // Add search functionality if needed
        }
        
        // Escape to close modals
        if (e.key === 'Escape') {
            this.hideAllModals();
        }
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('section').forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionName;
        }

        // Update page title
        this.updatePageTitle(sectionName);

        // Load section-specific content
        this.loadSectionContent(sectionName);
    }

    updatePageTitle(sectionName) {
        const pageTitle = document.querySelector('.page-title');
        const titles = {
            'dashboard': 'Dashboard',
            'scripts': 'Script Management',
            'upload': 'Upload Script',
            'logs': 'System Logs',
            'system': 'System Management'
        };
        
        if (pageTitle && titles[sectionName]) {
            pageTitle.textContent = titles[sectionName];
        }
    }

    loadSectionContent(sectionName) {
        switch(sectionName) {
            case 'scripts':
                this.renderScriptsTable();
                break;
            case 'dashboard':
                this.updateDashboardStats();
                this.renderRecentScripts();
                break;
            case 'system':
                this.refreshSystemStatus();
                break;
            case 'logs':
                this.loadSystemLogs();
                break;
        }
    }

    async loadScripts() {
        if (this.isLoading) return;
        
        this.isLoading = true;
        this.showLoading('Loading scripts...');
        
        try {
            const response = await this.makeRequest('/api/scripts');
            this.scripts = response;
            this.updateDashboardStats();
            this.renderRecentScripts();
            this.retryAttempts = 0; // Reset retry attempts on success
        } catch (error) {
            console.error('Failed to load scripts:', error);
            this.handleLoadError(error);
        } finally {
            this.isLoading = false;
            this.hideLoading();
        }
    }

    async makeRequest(url, options = {}) {
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json'
            }
        };

        const finalOptions = { ...defaultOptions, ...options };
        
        try {
            const response = await fetch(url, finalOptions);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            return await response.json();
        } catch (error) {
            throw new Error(`Request failed: ${error.message}`);
        }
    }

    handleLoadError(error) {
        this.retryAttempts++;
        
        if (this.retryAttempts < this.maxRetries) {
            this.showNotification(`Loading failed, retrying... (${this.retryAttempts}/${this.maxRetries})`, 'warning');
            setTimeout(() => this.loadScripts(), 2000 * this.retryAttempts);
        } else {
            this.showNotification('Failed to load scripts after multiple attempts', 'error');
            this.showErrorState();
        }
    }

    showErrorState() {
        const scriptsTable = document.getElementById('scriptsTable');
        if (scriptsTable) {
            scriptsTable.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>Failed to Load Scripts</h3>
                    <p>Unable to load scripts from server. Please check your connection and try again.</p>
                    <button class="btn btn-primary" onclick="waPanel.loadScripts()">
                        <i class="fas fa-sync-alt"></i> Retry
                    </button>
                </div>
            `;
        }
    }

    updateDashboardStats() {
        const total = this.scripts.length;
        const running = this.scripts.filter(s => s.status === 'running').length;
        const stopped = this.scripts.filter(s => s.status === 'stopped').length;
        const errors = this.scripts.filter(s => s.status === 'error').length;

        this.updateStatElement('stat-total-scripts', total);
        this.updateStatElement('stat-running', running);
        this.updateStatElement('stat-stopped', stopped);
        this.updateStatElement('stat-errors', errors);
    }

    updateStatElement(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }

    renderRecentScripts() {
        const container = document.getElementById('recentScripts');
        if (!container) return;

        const recentScripts = this.scripts.slice(0, 5);
        
        if (recentScripts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-robot"></i>
                    <h3>No Scripts Found</h3>
                    <p>Upload your first script to get started.</p>
                </div>
            `;
            return;
        }

        const html = recentScripts.map(script => `
            <div class="script-item">
                <div class="script-info">
                    <h4>${script.name}</h4>
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                </div>
                <div class="script-actions">
                    <button class="btn btn-sm ${script.status === 'running' ? 'btn-warning' : 'btn-success'}" 
                            onclick="waPanel.${script.status === 'running' ? 'stopScript' : 'startScript'}('${script.name}')">
                        <i class="fas fa-${script.status === 'running' ? 'stop' : 'play'}"></i>
                        ${script.status === 'running' ? 'Stop' : 'Start'}
                    </button>
                    <button class="btn btn-sm btn-secondary" onclick="waPanel.showLog('${script.name}')">
                        <i class="fas fa-clipboard-list"></i> Log
                    </button>
                </div>
            </div>
        `).join('');

        container.innerHTML = html;
    }

    renderScriptsTable() {
        const container = document.getElementById('scriptsTable');
        if (!container) return;

        if (this.scripts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-robot"></i>
                    <h3>No Scripts Found</h3>
                    <p>Upload your first script to get started.</p>
                </div>
            `;
            return;
        }

        const html = `
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Status</th>
                            <th>Uptime</th>
                            <th>Memory</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${this.scripts.map(script => `
                            <tr>
                                <td>
                                    <div class="script-name">
                                        <strong>${script.name}</strong>
                                        <small>${script.folder}</small>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge ${this.getStatusClass(script.status)}">
                                        ${script.status}
                                    </span>
                                </td>
                                <td>${script.uptime || 'N/A'}</td>
                                <td>${script.memory || 'N/A'}</td>
                                <td>
                                    <div class="action-buttons">
                                        <button class="btn btn-sm ${script.status === 'running' ? 'btn-warning' : 'btn-success'}" 
                                                onclick="waPanel.${script.status === 'running' ? 'stopScript' : 'startScript'}('${script.name}')"
                                                title="${script.status === 'running' ? 'Stop' : 'Start'}">
                                            <i class="fas fa-${script.status === 'running' ? 'stop' : 'play'}"></i>
                                        </button>
                                        <button class="btn btn-sm btn-info" 
                                                onclick="waPanel.restartScript('${script.name}')"
                                                title="Restart">
                                            <i class="fas fa-redo"></i>
                                        </button>
                                        <button class="btn btn-sm btn-secondary" 
                                                onclick="waPanel.showLog('${script.name}')"
                                                title="View Log">
                                            <i class="fas fa-clipboard-list"></i>
                                        </button>
                                        <button class="btn btn-sm btn-secondary" 
                                                onclick="waPanel.showTerminal('${script.name}')"
                                                title="Terminal">
                                            <i class="fas fa-terminal"></i>
                                        </button>
                                        <button class="btn btn-sm btn-secondary" 
                                                onclick="waPanel.showFileViewer('${script.name}')"
                                                title="Files">
                                            <i class="fas fa-folder-open"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" 
                                                onclick="waPanel.deleteScript('${script.name}')"
                                                title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;

        container.innerHTML = html;
    }

    getStatusClass(status) {
        const classes = {
            'running': 'running',
            'stopped': 'stopped',
            'error': 'error',
            'restarting': 'warning'
        };
        return classes[status] || 'stopped';
    }

    async uploadScript(form) {
        const formData = new FormData(form);
        const name = formData.get('name');
        const file = formData.get('file');

        if (!name || !file) {
            this.showNotification('Please fill all fields', 'error');
            return;
        }

        this.showUploadProgress();
        this.updateProgressStep(1, 'active');
        this.updateProgressAction('Uploading file...');

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Upload failed: ${response.statusText}`);
            }

            const result = await response.json();
            
            if (result.success) {
                this.updateProgressStep(5, 'completed');
                this.updateProgressAction('Upload completed successfully!');
                this.addProgressLog('Script uploaded successfully', 'success');
                this.showNotification('Script uploaded successfully', 'success');
                
                // Reload scripts after successful upload
                setTimeout(() => {
                    this.loadScripts();
                    this.hideUploadProgress();
                }, 2000);
            } else {
                throw new Error(result.error || 'Upload failed');
            }
        } catch (error) {
            console.error('Upload error:', error);
            this.updateProgressStep(5, 'error');
            this.updateProgressAction('Upload failed');
            this.addProgressLog(`Error: ${error.message}`, 'error');
            this.showNotification(`Upload failed: ${error.message}`, 'error');
            
            setTimeout(() => {
                this.hideUploadProgress();
            }, 3000);
        }
    }

    showUploadProgress() {
        const modal = document.getElementById('uploadProgressModal');
        if (modal) {
            modal.classList.add('active');
            this.resetProgress();
        }
    }

    hideUploadProgress() {
        const modal = document.getElementById('uploadProgressModal');
        if (modal) {
            modal.classList.remove('active');
        }
    }

    resetProgress() {
        // Reset all steps
        for (let i = 1; i <= 5; i++) {
            this.updateProgressStep(i, 'pending');
        }
        
        // Reset progress bar
        const progressFill = document.getElementById('progressFill');
        if (progressFill) {
            progressFill.style.width = '0%';
        }
        
        // Clear logs
        const progressLog = document.getElementById('progressLog');
        if (progressLog) {
            progressLog.innerHTML = '';
        }
    }

    updateProgressStep(stepNumber, status) {
        const step = document.getElementById(`step${stepNumber}`);
        if (step) {
            step.className = `step ${status}`;
        }
    }

    updateProgressAction(action) {
        const currentAction = document.getElementById('currentAction');
        if (currentAction) {
            const span = currentAction.querySelector('span');
            if (span) {
                span.textContent = action;
            }
        }
    }

    addProgressLog(message, type = 'info') {
        const progressLog = document.getElementById('progressLog');
        if (progressLog) {
            const logEntry = document.createElement('div');
            logEntry.className = `log-entry ${type}`;
            logEntry.innerHTML = `
                <span class="log-time">${new Date().toLocaleTimeString()}</span>
                <span class="log-message">${message}</span>
            `;
            progressLog.appendChild(logEntry);
            progressLog.scrollTop = progressLog.scrollHeight;
        }
    }

    updateProgressBar(percentage) {
        const progressFill = document.getElementById('progressFill');
        if (progressFill) {
            progressFill.style.width = `${percentage}%`;
        }
    }

    cancelUpload() {
        this.hideUploadProgress();
        this.showNotification('Upload cancelled', 'warning');
    }

    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async installMissingModules(name) {
        try {
            const response = await this.makeRequest(`/api/script/install/${name}`, {
                method: 'POST'
            });
            return response.success;
        } catch (error) {
            console.error('Install error:', error);
            return false;
        }
    }

    async checkMissingModules(name) {
        try {
            const response = await this.makeRequest(`/api/script/check-modules/${name}`);
            return response.missingModules;
        } catch (error) {
            console.error('Check modules error:', error);
            return [];
        }
    }

    async startScript(name) {
        this.showLoading(`Starting ${name}...`);
        
        try {
            const response = await this.makeRequest(`/api/pm2/start/${name}`, {
                method: 'POST'
            });
            
            if (response.success) {
                this.showNotification(`${name} started successfully`, 'success');
                this.loadScripts(); // Refresh the list
            } else {
                throw new Error(response.error || 'Failed to start script');
            }
        } catch (error) {
            console.error('Start script error:', error);
            this.showNotification(`Failed to start ${name}: ${error.message}`, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async stopScript(name) {
        this.showLoading(`Stopping ${name}...`);
        
        try {
            const response = await this.makeRequest(`/api/pm2/stop/${name}`, {
                method: 'POST'
            });
            
            if (response.success) {
                this.showNotification(`${name} stopped successfully`, 'success');
                this.loadScripts(); // Refresh the list
            } else {
                throw new Error(response.error || 'Failed to stop script');
            }
        } catch (error) {
            console.error('Stop script error:', error);
            this.showNotification(`Failed to stop ${name}: ${error.message}`, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async restartScript(name) {
        this.showLoading(`Restarting ${name}...`);
        
        try {
            const response = await this.makeRequest(`/api/pm2/restart/${name}`, {
                method: 'POST'
            });
            
            if (response.success) {
                this.showNotification(`${name} restarted successfully`, 'success');
                this.loadScripts(); // Refresh the list
            } else {
                throw new Error(response.error || 'Failed to restart script');
            }
        } catch (error) {
            console.error('Restart script error:', error);
            this.showNotification(`Failed to restart ${name}: ${error.message}`, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async deleteScript(name) {
        if (!confirm(`Are you sure you want to delete ${name}? This action cannot be undone.`)) {
            return;
        }

        this.showLoading(`Deleting ${name}...`);
        
        try {
            const response = await this.makeRequest(`/api/pm2/delete/${name}`, {
                method: 'DELETE'
            });
            
            if (response.success) {
                this.showNotification(`${name} deleted successfully`, 'success');
                this.loadScripts(); // Refresh the list
            } else {
                throw new Error(response.error || 'Failed to delete script');
            }
        } catch (error) {
            console.error('Delete script error:', error);
            this.showNotification(`Failed to delete ${name}: ${error.message}`, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async showLog(name) {
        this.showLoading(`Loading log for ${name}...`);
        
        try {
            const response = await this.makeRequest(`/api/pm2/logs/${name}`);
            
            if (response.success) {
                const logContent = document.getElementById('logContent');
                if (logContent) {
                    logContent.innerHTML = `
                        <div class="log-header">
                            <h4>${name} Log</h4>
                            <button class="btn btn-sm btn-secondary" onclick="waPanel.refreshLog('${name}')">
                                <i class="fas fa-sync-alt"></i> Refresh
                            </button>
                        </div>
                        <div class="log-content">
                            <pre>${response.logs || 'No logs available'}</pre>
                        </div>
                    `;
                }
                
                this.showModal('logModal');
            } else {
                throw new Error(response.error || 'Failed to load logs');
            }
        } catch (error) {
            console.error('Show log error:', error);
            this.showNotification(`Failed to load log for ${name}: ${error.message}`, 'error');
        } finally {
            this.hideLoading();
        }
    }

    async loadSystemLogs() {
        this.showLoading('Loading system logs...');
        
        try {
            const response = await this.makeRequest('/api/logs');
            
            const systemLogs = document.getElementById('systemLogs');
            if (systemLogs) {
                systemLogs.innerHTML = `
                    <div class="log-content">
                        <pre>${response.logs || 'No system logs available'}</pre>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Load system logs error:', error);
            this.showNotification('Failed to load system logs', 'error');
        } finally {
            this.hideLoading();
        }
    }

    // Terminal/Exec Functions
    showTerminal(scriptName) {
        this.currentTerminalScript = scriptName;
        this.terminalOutput = [];
        
        const modal = document.getElementById('terminalModal');
        const header = modal?.querySelector('.modal-header h3');
        if (header) {
            header.innerHTML = `<i class="fas fa-terminal"></i> Terminal - ${scriptName}`;
        }
        
        this.showModal('terminalModal');
        this.clearTerminalOutput();
        this.addTerminalOutput(`Terminal session started for ${scriptName}`, 'info');
        this.addTerminalOutput(`Working directory: /scripts/${scriptName}`, 'info');
        this.addTerminalOutput('Type your command and press Enter or click Run', 'info');
    }

    async executeTerminalCommand() {
        const commandInput = document.getElementById('terminalCommand');
        const command = commandInput?.value?.trim();
        
        if (!command) {
            this.showNotification('Please enter a command', 'warning');
            return;
        }

        if (!this.currentTerminalScript) {
            this.showNotification('No script selected for terminal', 'error');
            return;
        }

        this.addTerminalOutput(`$ ${command}`, 'command');
        commandInput.value = '';

        try {
            const response = await this.makeRequest('/api/script/execute', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    name: this.currentTerminalScript,
                    command: command
                })
            });

            if (response.success) {
                if (response.stdout) {
                    this.addTerminalOutput(response.stdout, 'output');
                }
                if (response.stderr) {
                    this.addTerminalOutput(response.stderr, 'error');
                }
                this.addTerminalOutput(`Command completed with exit code: ${response.exitCode}`, 'info');
            } else {
                this.addTerminalOutput(`Error: ${response.error || 'Command failed'}`, 'error');
            }
        } catch (error) {
            console.error('Execute command error:', error);
            this.addTerminalOutput(`Error: ${error.message}`, 'error');
        }
    }

    addTerminalOutput(text, type = 'output') {
        const terminalOutput = document.getElementById('terminalOutput');
        if (terminalOutput) {
            const outputLine = document.createElement('div');
            outputLine.className = `terminal-line ${type}`;
            outputLine.textContent = text;
            terminalOutput.appendChild(outputLine);
            terminalOutput.scrollTop = terminalOutput.scrollHeight;
        }
    }

    clearTerminalOutput() {
        const terminalOutput = document.getElementById('terminalOutput');
        if (terminalOutput) {
            terminalOutput.innerHTML = '';
        }
    }

    copyTerminalOutput() {
        const terminalOutput = document.getElementById('terminalOutput');
        if (terminalOutput) {
            const text = terminalOutput.textContent;
            navigator.clipboard.writeText(text).then(() => {
                this.showNotification('Terminal output copied to clipboard', 'success');
            }).catch(() => {
                this.showNotification('Failed to copy to clipboard', 'error');
            });
        }
    }

    // File Viewer Functions
    async showFileViewer(scriptName) {
        this.showLoading(`Loading files for ${scriptName}...`);
        
        try {
            const response = await this.makeRequest(`/api/script/info/${scriptName}`);
            
            if (response.files) {
                this.renderFileList(response.files, scriptName);
                this.showModal('fileViewerModal');
            } else {
                throw new Error('Failed to load file list');
            }
        } catch (error) {
            console.error('Show file viewer error:', error);
            this.showNotification(`Failed to load files for ${scriptName}: ${error.message}`, 'error');
        } finally {
            this.hideLoading();
        }
    }

    renderFileList(files, scriptName) {
        const fileList = document.getElementById('fileList');
        if (fileList) {
            const html = files.map(file => `
                <div class="file-item" onclick="waPanel.selectFile('${file.name}', '${scriptName}')">
                    <i class="fas fa-${file.isDirectory ? 'folder' : 'file'}"></i>
                    <span>${file.name}</span>
                    <small>${this.formatFileSize(file.size)}</small>
                </div>
            `).join('');
            
            fileList.innerHTML = html;
        }
    }

    async selectFile(fileName, scriptName) {
        // For now, just show file info
        this.showNotification(`Selected: ${fileName}`, 'info');
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 B';
        const k = 1024;
        const sizes = ['B', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Loading Functions
    showLoading(text = 'Loading...', subtext = '') {
        const loadingScreen = document.getElementById('loadingScreen');
        const loadingText = document.getElementById('loadingText');
        const loadingSubtext = document.getElementById('loadingSubtext');
        
        if (loadingScreen && loadingText) {
            loadingText.textContent = text;
            if (loadingSubtext) {
                loadingSubtext.textContent = subtext;
            }
            loadingScreen.classList.add('show');
        }
    }

    hideLoading() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.classList.remove('show');
        }
    }

    updateLoadingProgress(percentage) {
        const progressBar = document.getElementById('loadingProgressBar');
        if (progressBar) {
            progressBar.style.width = `${percentage}%`;
        }
    }

    // Modal Functions
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('active');
        }
    }

    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('active');
        }
    }

    hideAllModals() {
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.classList.remove('active');
        });
    }

    hideLogModal() {
        this.hideModal('logModal');
    }

    hideTerminalModal() {
        this.hideModal('terminalModal');
        this.currentTerminalScript = null;
    }

    hideFileViewerModal() {
        this.hideModal('fileViewerModal');
    }

    toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            sidebar.classList.toggle('active');
        }
    }

    // Notification Functions
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }

    getNotificationIcon(type) {
        const icons = {
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-circle',
            'warning': 'fas fa-exclamation-triangle',
            'info': 'fas fa-info-circle'
        };
        return icons[type] || icons.info;
    }

    // Utility Functions
    refreshAll() {
        this.loadScripts();
        this.showNotification('Refreshing data...', 'info');
    }

    async refreshSystemStatus() {
        try {
            const response = await this.makeRequest('/api/system/status');
            this.updateSystemStatus(response);
        } catch (error) {
            console.error('Refresh system status error:', error);
            this.showNotification('Failed to refresh system status', 'error');
        }
    }

    updateSystemStatus(status) {
        const systemStatus = document.getElementById('systemStatus');
        if (systemStatus) {
            systemStatus.innerHTML = `
                <div class="system-card">
                    <h3><i class="fas fa-server"></i> System Status</h3>
                    <div class="status-item">
                        <span class="label">Uptime</span>
                        <span class="value">${this.formatUptime(status.uptime)}</span>
                    </div>
                    <div class="status-item">
                        <span class="label">Memory</span>
                        <span class="value">${status.memory}</span>
                    </div>
                    <div class="status-item">
                        <span class="label">CPU</span>
                        <span class="value">${status.cpu}</span>
                    </div>
                    <div class="status-item">
                        <span class="label">Disk</span>
                        <span class="value">${status.disk}</span>
                    </div>
                </div>
            `;
        }
    }

    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        
        if (days > 0) {
            return `${days}d ${hours}h ${minutes}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes}m`;
        }
    }

    async handleSystemUpdate(form) {
        const formData = new FormData(form);
        const file = formData.get('file');

        if (!file) {
            this.showNotification('Please select an update file', 'error');
            return;
        }

        this.showLoading('Updating system...', 'This may take a few minutes');

        try {
            const response = await fetch('/api/update', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                throw new Error(`Update failed: ${response.statusText}`);
            }

            const result = await response.json();
            
            if (result.success) {
                this.showNotification('System updated successfully', 'success');
                this.updateLoadingProgress(100);
                
                setTimeout(() => {
                    this.hideLoading();
                    // Optionally reload the page
                    // window.location.reload();
                }, 2000);
            } else {
                throw new Error(result.error || 'Update failed');
            }
        } catch (error) {
            console.error('System update error:', error);
            this.showNotification(`Update failed: ${error.message}`, 'error');
            this.hideLoading();
        }
    }
}

// Initialize the panel
const waPanel = new WAPanel();

// Global functions for backward compatibility
function showUploadModal() {
    waPanel.showModal('uploadProgressModal');
}

function hideUploadModal() {
    waPanel.hideModal('uploadProgressModal');
}

function hideLogModal() {
    waPanel.hideLogModal();
}

function hideTerminalModal() {
    waPanel.hideTerminalModal();
}

function hideFileViewerModal() {
    waPanel.hideFileViewerModal();
}

function refreshAll() {
    waPanel.refreshAll();
}

function testUpload() {
    console.log('Test upload function');
}

function checkPermissions() {
    console.log('Check permissions function');
} 