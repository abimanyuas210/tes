#!/usr/bin/env bash

if [ "$(uname -o)" = "Android" ]; then
  # Termux
  cd "$(dirname "$0")/backend"
  if [ ! -d "node_modules" ]; then
    npm install express cors pm2 multer fs-extra unzipper
  fi
  node server.js
else
  # Ubuntu/Linux
  cd "$(dirname "$0")/backend"
  if ! command -v node >/dev/null; then
    echo "Node.js belum terinstall. Install dulu: sudo apt update && sudo apt install nodejs npm -y"
    exit 1
  fi
  if ! command -v pm2 >/dev/null; then
    npm install -g pm2
  fi
  if [ ! -d "node_modules" ]; then
    npm install express cors pm2 multer fs-extra unzipper
  fi
  node server.js
fi 