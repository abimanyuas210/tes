const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const multer = require('multer');
const { spawn } = require('child_process');
const unzipper = require('unzipper');
const pm2 = require('pm2');
const { exec } = require('child_process');

const app = express();
const PORT = 3000;

const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const DB_PATH = path.join(__dirname, 'db.json');

fs.ensureDirSync(SCRIPTS_DIR);

const upload = multer({ 
  dest: '/tmp',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
    files: 1
  }
});

// Terminal session storage
const terminalSessions = new Map();

app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Helper: update status dari pm2 list
async function updatePM2Status() {
  return new Promise((resolve) => {
    pm2.connect((err) => {
      if (err) {
        console.error('PM2 connection error:', err);
        return resolve();
      }
      
      pm2.list((err, list) => {
        if (err) {
          console.error('PM2 list error:', err);
          pm2.disconnect();
          return resolve();
        }
        
        let db = [];
        try { 
          db = fs.readJsonSync(DB_PATH); 
        } catch (e) {
          console.error('Failed to read DB:', e);
          pm2.disconnect();
          return resolve();
        }
        
        db.forEach(script => {
          const found = list.find(proc => proc.name === script.name);
          if (found) {
            script.status = found.pm2_env.status === 'online' ? '🟢 Online' : '🔴 Offline';
          } else {
            script.status = 'stopped';
          }
        });
        
        try {
          fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
        } catch (e) {
          console.error('Failed to write DB:', e);
        }
        
        pm2.disconnect();
        resolve();
      });
    });
  });
}

// API: Get all scripts (with PM2 status)
app.get('/api/scripts', async (req, res) => {
  await updatePM2Status();
  let db = [];
  try {
    db = fs.readJsonSync(DB_PATH);
  } catch (e) {}
  res.json(db);
});

// API: Upload script
app.post('/api/upload', upload.single('file'), async (req, res) => {
  console.log('Script upload request received');
  console.log('Request body:', req.body);
  console.log('Request file:', req.file);
  
  const { name, command } = req.body;
  const file = req.file;
  
  if (!name || !command || !file) {
    console.log('Missing required fields:', { name, command, file: !!file });
    return res.status(400).json({ message: 'Lengkapi semua field!' });
  }
  
  console.log('Processing upload for:', name, 'Command:', command, 'File:', file.originalname);
  
  const folder = name.replace(/[^a-zA-Z0-9_-]/g, '_');
  const scriptPath = path.join(SCRIPTS_DIR, folder);
  
  try {
    // Create script directory
    await fs.ensureDir(scriptPath);
    console.log('Script directory created:', scriptPath);
    
    let mainFile = '';
    
    if (file.originalname.endsWith('.zip')) {
      console.log('Processing ZIP file...');
      
      // Extract ZIP to temporary directory first
      const tempExtractPath = path.join(SCRIPTS_DIR, 'temp_' + Date.now());
      await fs.ensureDir(tempExtractPath);
      
      const extractStream = fs.createReadStream(file.path).pipe(unzipper.Extract({ path: tempExtractPath }));
      await new Promise((resolve, reject) => {
        extractStream.on('close', resolve);
        extractStream.on('error', reject);
      });
      console.log('ZIP extracted to temp directory');
      
      // Find the main entry file
      const extractedFiles = await fs.readdir(tempExtractPath);
      console.log('Extracted files:', extractedFiles);
      
      // Check if there's only one folder and it contains index.js
      let shouldMoveContents = false;
      let sourceFolder = null;
      
      if (extractedFiles.length === 1) {
        const singleItem = extractedFiles[0];
        const singleItemPath = path.join(tempExtractPath, singleItem);
        const singleItemStat = await fs.stat(singleItemPath);
        
        if (singleItemStat.isDirectory()) {
          console.log('Found single folder:', singleItem);
          const folderContents = await fs.readdir(singleItemPath);
          console.log('Folder contents:', folderContents);
          
          // Check if folder contains index.js or other entry files
          const possibleEntryFiles = ['index.js', 'main.js', 'app.js', 'bot.js', 'start.js'];
          const hasEntryFile = folderContents.some(file => possibleEntryFiles.includes(file));
          
          if (hasEntryFile) {
            console.log('Single folder contains entry file, will move contents out');
            shouldMoveContents = true;
            sourceFolder = singleItemPath;
          }
        }
      }
      
      // Look for common entry files
      const possibleEntryFiles = ['index.js', 'main.js', 'app.js', 'bot.js', 'start.js'];
      let foundEntryFile = null;
      
      for (const entryFile of possibleEntryFiles) {
        const entryPath = path.join(tempExtractPath, entryFile);
        if (await fs.pathExists(entryPath)) {
          foundEntryFile = entryFile;
          break;
        }
      }
      
      if (!foundEntryFile) {
        // If no entry file found, use the first .js file
        for (const file of extractedFiles) {
          if (file.endsWith('.js')) {
            foundEntryFile = file;
            break;
          }
        }
      }
      
      if (foundEntryFile) {
        mainFile = foundEntryFile;
        console.log('Found entry file:', mainFile);
      } else {
        // Create a default index.js if no entry file found
        mainFile = 'index.js';
        console.log('No entry file found, will create default index.js');
      }
      
      // Copy files from temp to script directory
      if (shouldMoveContents && sourceFolder) {
        console.log('Moving contents from single folder to script directory');
        const folderContents = await fs.readdir(sourceFolder);
        
        for (const item of folderContents) {
          const sourcePath = path.join(sourceFolder, item);
          const targetPath = path.join(scriptPath, item);
          
          const stat = await fs.stat(sourcePath);
          if (stat.isDirectory()) {
            await fs.copy(sourcePath, targetPath);
          } else {
            await fs.copy(sourcePath, targetPath);
          }
        }
      } else {
        // Copy all files from temp to script directory
        for (const item of extractedFiles) {
          const sourcePath = path.join(tempExtractPath, item);
          const targetPath = path.join(scriptPath, item);
          
          const stat = await fs.stat(sourcePath);
          if (stat.isDirectory()) {
            await fs.copy(sourcePath, targetPath);
          } else {
            await fs.copy(sourcePath, targetPath);
          }
        }
      }
      
      // Clean up temp directory
      await fs.remove(tempExtractPath);
      
    } else if (file.originalname.endsWith('.js')) {
      console.log('Processing JS file...');
      mainFile = 'index.js';
      await fs.copy(file.path, path.join(scriptPath, mainFile));
      console.log('JS file copied as index.js');
    } else {
      console.log('Invalid file type:', file.originalname);
      return res.status(400).json({ message: 'File harus .js atau .zip' });
    }
    
    // Create package.json if it doesn't exist
    const packageJsonPath = path.join(scriptPath, 'package.json');
    if (!await fs.pathExists(packageJsonPath)) {
      const packageJson = {
        name: folder,
        version: "1.0.0",
        description: `Script: ${name}`,
        main: mainFile,
        scripts: {
          start: command,
          test: "echo \"Error: no test specified\" && exit 1"
        },
        dependencies: {}
      };
      await fs.writeJson(packageJsonPath, packageJson, { spaces: 2 });
      console.log('Created package.json');
    }
    
    // Auto install npm modules if package.json exists
    console.log('Checking for npm dependencies...');
    if (await fs.pathExists(packageJsonPath)) {
      try {
        console.log('Installing npm dependencies...');
        const npmInstall = spawn('npm', ['install'], { 
          cwd: scriptPath,
          stdio: ['pipe', 'pipe', 'pipe']
        });
        
        let npmOutput = '', npmError = '';
        npmInstall.stdout.on('data', (data) => {
          npmOutput += data.toString();
          console.log('NPM stdout:', data.toString());
        });
        npmInstall.stderr.on('data', (data) => {
          npmError += data.toString();
          console.log('NPM stderr:', data.toString());
        });
        
        await new Promise((resolve, reject) => {
          npmInstall.on('close', (code) => {
            if (code === 0) {
              console.log('NPM install completed successfully');
              resolve();
            } else {
              console.log('NPM install failed with code:', code);
              console.log('NPM error:', npmError);
              // Don't reject, just log the error
              resolve();
            }
          });
        });
      } catch (npmErr) {
        console.error('NPM install error:', npmErr);
        // Continue even if npm install fails
      }
    }
    
    // Create README.md if it doesn't exist
    const readmePath = path.join(scriptPath, 'README.md');
    if (!await fs.pathExists(readmePath)) {
      const readme = `# ${name}

Script uploaded via WA Panel.

## Usage

\`\`\`bash
${command}
\`\`\`

## Files

- \`${mainFile}\` - Main entry file
- \`package.json\` - Project configuration

## Dependencies

Run \`npm install\` to install dependencies.
`;
      await fs.writeFile(readmePath, readme);
      console.log('Created README.md');
    }
    
    console.log('Testing script with command:', command);
    console.log('Working directory:', scriptPath);
    console.log('Main file:', mainFile);
    
    // Test the script
    const [cmd, ...args] = command.split(' ');
    const testProc = spawn(cmd, args, { 
      cwd: scriptPath,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let stdout = '', stderr = '';
    let finished = false;
    
    const timeout = setTimeout(() => {
      if (!finished) {
        console.log('Test timeout reached, killing process');
        testProc.kill('SIGKILL');
        finished = true;
      }
    }, 10000);
    
    testProc.stdout.on('data', d => { 
      stdout += d.toString(); 
      console.log('Test stdout:', d.toString());
    });
    testProc.stderr.on('data', d => { 
      stderr += d.toString(); 
      console.log('Test stderr:', d.toString());
    });
    
    testProc.on('close', code => {
      clearTimeout(timeout);
      if (finished) return;
      finished = true;
      
      console.log('Test process closed with code:', code);
      
      let db = [];
      try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
      let testResult = '', lastError = '';
      
      if (code === 0) {
        testResult = '✅ OK';
        lastError = '';
        console.log('Test passed');
      } else {
        testResult = '❌ ERROR';
        lastError = stderr || stdout || 'Unknown error';
        console.log('Test failed:', lastError);
      }
      
      const scriptData = {
        name,
        folder,
        command,
        mainFile: mainFile,
        status: 'stopped',
        testResult,
        lastError,
        uploadTime: new Date().toISOString()
      };
      
      db = db.filter(s => s.name !== name);
      db.push(scriptData);
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      
      if (testResult === '✅ OK') {
        res.json({ message: 'Upload & test berhasil!' });
      } else {
        res.json({ message: 'Test gagal: ' + lastError });
      }
    });
    
  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ message: 'Gagal upload: ' + err.message });
  }
});

// API: Start script (PM2)
app.post('/api/pm2/start/:name', async (req, res) => {
  try {
    const { name } = req.params;
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
    
    const scriptPath = path.join(SCRIPTS_DIR, script.folder);
    const mainFile = script.mainFile || 'index.js';
    
    // Check if script path exists
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ message: 'Script folder tidak ditemukan' });
    }
    
    // Check if main file exists
    const mainFilePath = path.join(scriptPath, mainFile);
    if (!await fs.pathExists(mainFilePath)) {
      return res.status(404).json({ message: `Main file ${mainFile} tidak ditemukan` });
    }
    
    return new Promise((resolve, reject) => {
      pm2.connect((err) => {
        if (err) {
          pm2.disconnect();
          return res.status(500).json({ message: 'PM2 connection error' });
        }
        
        // Check if script is already running
        pm2.list((err, list) => {
          if (err) {
            pm2.disconnect();
            return res.status(500).json({ message: 'PM2 list error' });
          }
          
          const existingProcess = list.find(proc => proc.name === script.name);
          if (existingProcess) {
            pm2.disconnect();
            return res.status(400).json({ message: 'Script sudah berjalan' });
          }
          
          // Start the script
          pm2.start({
            name: script.name,
            script: mainFilePath,
            cwd: scriptPath,
            env: {
              NODE_ENV: 'production'
            }
          }, (err) => {
            pm2.disconnect();
            if (err) {
              return res.status(500).json({ message: 'Gagal start: ' + err.message });
            }
            
            script.status = '🟢 Online';
            fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
            res.json({ message: 'Script dijalankan!' });
          });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// API: Restart script (PM2)
app.post('/api/pm2/restart/:name', async (req, res) => {
  try {
    const { name } = req.params;
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
    
    return new Promise((resolve, reject) => {
      pm2.connect((err) => {
        if (err) {
          pm2.disconnect();
          return res.status(500).json({ message: 'PM2 connection error' });
        }
        
        pm2.restart(name, (err) => {
          pm2.disconnect();
          if (err) {
            return res.status(500).json({ message: 'Gagal restart: ' + err.message });
          }
          
          script.status = '🟢 Online';
          fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
          res.json({ message: 'Script direstart!' });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// API: Stop script (PM2)
app.post('/api/pm2/stop/:name', async (req, res) => {
  try {
    const { name } = req.params;
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
    
    return new Promise((resolve, reject) => {
      pm2.connect((err) => {
        if (err) {
          pm2.disconnect();
          return res.status(500).json({ message: 'PM2 connection error' });
        }
        
        pm2.stop(name, (err) => {
          pm2.disconnect();
          if (err) {
            return res.status(500).json({ message: 'Gagal stop: ' + err.message });
          }
          
          script.status = 'stopped';
          fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
          res.json({ message: 'Script distop!' });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// API: Delete script (PM2)
app.post('/api/pm2/delete/:name', async (req, res) => {
  try {
    const { name } = req.params;
    let db = [];
    try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
    const script = db.find(s => s.name === name);
    if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
    
    return new Promise((resolve, reject) => {
      pm2.connect((err) => {
        if (err) {
          pm2.disconnect();
          return res.status(500).json({ message: 'PM2 connection error' });
        }
        
        pm2.delete(name, (err) => {
          pm2.disconnect();
          if (err) {
            return res.status(500).json({ message: 'Gagal delete: ' + err.message });
          }
          
          // Remove from db and folder
          db = db.filter(s => s.name !== name);
          fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
          
          try {
            fs.removeSync(path.join(SCRIPTS_DIR, script.folder));
          } catch (removeErr) {
            console.error('Failed to remove script folder:', removeErr);
          }
          
          res.json({ message: 'Script dihapus!' });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error: ' + error.message });
  }
});

// API: Get last log/error
app.get('/api/log/:name', (req, res) => {
  const { name } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  // Cek log/error dari PM2
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.describe(name, (err, desc) => {
      pm2.disconnect();
      if (err || !desc || !desc[0]) return res.json({ log: script.lastError || '-' });
      const out = desc[0].pm2_env.pm_out_log_path;
      const errLog = desc[0].pm2_env.pm_err_log_path;
      let log = '';
      try {
        log = fs.readFileSync(errLog, 'utf8').split('\n').slice(-10).join('\n');
      } catch (e) {}
      res.json({ log: log || script.lastError || '-' });
    });
  });
});

// API: Update system (alias for self-update)
app.post('/api/update', upload.single('update'), async (req, res) => {
  console.log('System update request received');
  
  const file = req.file;
  if (!file) {
    console.log('No file provided');
    return res.status(400).json({ message: 'No update file provided' });
  }

  console.log('File received:', file.originalname, 'Size:', file.size);

  if (!file.originalname.endsWith('.zip')) {
    console.log('Invalid file type:', file.originalname);
    return res.status(400).json({ message: 'Update file must be a ZIP file' });
  }

  if (file.size === 0) {
    console.log('Empty file received');
    return res.status(400).json({ message: 'Update file is empty' });
  }

  const updateDir = path.join(__dirname, '../temp_update');
  const backupDir = path.join(__dirname, '../backup_' + Date.now());
  const projectRoot = path.join(__dirname, '..');

  console.log('Paths:', { updateDir, backupDir, projectRoot });

  try {
    // Create backup - exclude temp and backup directories
    console.log('Creating backup...');
    await fs.ensureDir(backupDir);
    
    const projectFiles = await fs.readdir(projectRoot);
    for (const item of projectFiles) {
      // Skip backup and temp directories
      if (item.startsWith('backup_') || item === 'temp_update' || item === 'node_modules') {
        console.log('Skipping backup item:', item);
        continue;
      }
      
      const sourcePath = path.join(projectRoot, item);
      const targetPath = path.join(backupDir, item);
      
      const stat = await fs.stat(sourcePath);
      if (stat.isDirectory()) {
        await fs.copy(sourcePath, targetPath);
      } else {
        await fs.copy(sourcePath, targetPath);
      }
    }
    console.log('Backup created successfully');
    
    // Extract update
    console.log('Extracting update...');
    await fs.ensureDir(updateDir);
    await fs.emptyDir(updateDir); // Clear directory first
    
    const extractStream = fs.createReadStream(file.path).pipe(unzipper.Extract({ path: updateDir }));
    await new Promise((resolve, reject) => {
      extractStream.on('close', resolve);
      extractStream.on('error', reject);
    });
    console.log('Update extracted successfully');
    
    // Find the main project folder in extracted files
    const extractedFiles = await fs.readdir(updateDir);
    console.log('Extracted files:', extractedFiles);
    
    let sourceDir = updateDir;
    
    // If there's a single folder, use it as source
    if (extractedFiles.length === 1) {
      const firstItem = path.join(updateDir, extractedFiles[0]);
      const stat = await fs.stat(firstItem);
      if (stat.isDirectory()) {
        sourceDir = firstItem;
        console.log('Using single directory as source:', sourceDir);
      }
    }
    
    // Copy files to project root (excluding sensitive files)
    console.log('Applying update...');
    const filesToCopy = await fs.readdir(sourceDir);
    console.log('Files to copy:', filesToCopy);
    
    for (const item of filesToCopy) {
      const sourcePath = path.join(sourceDir, item);
      const targetPath = path.join(projectRoot, item);
      
      // Skip sensitive files and directories
      if (['node_modules', '.git', 'backup_', 'temp_update', 'package-lock.json'].some(skip => item.includes(skip))) {
        console.log('Skipping:', item);
        continue;
      }
      
      const stat = await fs.stat(sourcePath);
      if (stat.isDirectory()) {
        console.log('Copying directory:', item);
        // Remove existing directory first if it exists
        if (await fs.pathExists(targetPath)) {
          await fs.remove(targetPath);
        }
        await fs.copy(sourcePath, targetPath);
      } else {
        console.log('Copying file:', item);
        await fs.copy(sourcePath, targetPath);
      }
    }
    
    // Clean up
    console.log('Cleaning up...');
    await fs.remove(updateDir);
    await fs.remove(file.path);
    console.log('Cleanup completed');
    
    console.log('Update applied successfully');
    res.json({ 
      message: 'Update applied successfully! Server will restart in 3 seconds...',
      backupLocation: backupDir
    });
    
    // Restart server after 3 seconds
    setTimeout(() => {
      console.log('Restarting server...');
      process.exit(0);
    }, 3000);
    
  } catch (error) {
    console.error('Update failed:', error);
    
    // Try to restore from backup
    try {
      if (await fs.pathExists(backupDir)) {
        console.log('Restoring from backup...');
        
        const backupFiles = await fs.readdir(backupDir);
        for (const item of backupFiles) {
          const sourcePath = path.join(backupDir, item);
          const targetPath = path.join(projectRoot, item);
          
          const stat = await fs.stat(sourcePath);
          if (stat.isDirectory()) {
            if (await fs.pathExists(targetPath)) {
              await fs.remove(targetPath);
            }
            await fs.copy(sourcePath, targetPath);
          } else {
            await fs.copy(sourcePath, targetPath);
          }
        }
        
        await fs.remove(backupDir);
        console.log('Restore completed');
      }
    } catch (restoreError) {
      console.error('Failed to restore from backup:', restoreError);
    }
    
    // Clean up temp files
    try {
      if (await fs.pathExists(updateDir)) {
        await fs.remove(updateDir);
      }
      if (file && await fs.pathExists(file.path)) {
        await fs.remove(file.path);
      }
    } catch (cleanupError) {
      console.error('Failed to cleanup temp files:', cleanupError);
    }
    
    res.status(500).json({ 
      message: 'Update failed: ' + error.message,
      error: error.message,
      stack: error.stack
    });
  }
});

// Get update status
app.get('/api/update-status', (req, res) => {
  const packageJson = require('../package.json');
  res.json({
    version: packageJson.version || '1.0.0',
    lastUpdate: new Date().toISOString(),
    serverUptime: process.uptime()
  });
});

// Execute command in terminal with real-time output
app.post('/api/terminal/execute', (req, res) => {
  const { name, command } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const scriptPath = path.join(SCRIPTS_DIR, script.folder);
  const sessionId = `${name}_${Date.now()}`;
  
  console.log('Executing command:', command, 'in directory:', scriptPath);
  
  // Parse command
  const [cmd, ...args] = command.split(' ');
  const process = spawn(cmd, args, { 
    cwd: scriptPath,
    stdio: ['pipe', 'pipe', 'pipe'],
    env: {
      ...process.env,
      NODE_ENV: 'production'
    }
  });
  
  let output = '';
  let error = '';
  
  process.stdout.on('data', (data) => {
    output += data.toString();
    console.log('Terminal stdout:', data.toString());
  });
  
  process.stderr.on('data', (data) => {
    error += data.toString();
    console.log('Terminal stderr:', data.toString());
  });
  
  process.on('close', (code) => {
    console.log('Terminal process closed with code:', code);
    terminalSessions.set(sessionId, {
      output: output,
      error: error,
      exitCode: code,
      finished: true,
      pid: process.pid
    });
  });
  
  process.on('error', (err) => {
    console.error('Terminal process error:', err);
    terminalSessions.set(sessionId, {
      output: output,
      error: error + '\nProcess error: ' + err.message,
      exitCode: -1,
      finished: true,
      pid: null
    });
  });
  
  res.json({ 
    sessionId: sessionId,
    message: 'Command started',
    pid: process.pid
  });
});

// Get terminal output
app.get('/api/terminal/output/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const session = terminalSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ message: 'Session not found' });
  }
  
  res.json(session);
});

// List files in script directory
app.get('/api/script/files/:name', (req, res) => {
  const { name } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const scriptPath = path.join(SCRIPTS_DIR, script.folder);
  
  try {
    const files = fs.readdirSync(scriptPath, { withFileTypes: true });
    const fileList = files.map(file => ({
      name: file.name,
      type: file.isDirectory() ? 'directory' : 'file',
      size: file.isFile() ? fs.statSync(path.join(scriptPath, file.name)).size : 0
    }));
    
    res.json({ files: fileList });
  } catch (error) {
    res.status(500).json({ message: 'Failed to read files: ' + error.message });
  }
});

// Get file content
app.get('/api/script/file/:name/:filename', (req, res) => {
  const { name, filename } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const filePath = path.join(SCRIPTS_DIR, script.folder, filename);
  
  try {
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    const content = fs.readFileSync(filePath, 'utf8');
    const stats = fs.statSync(filePath);
    
    res.json({
      content: content,
      size: stats.size,
      modified: stats.mtime,
      filename: filename
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to read file: ' + error.message });
  }
});

// Kill terminal process
app.post('/api/terminal/kill/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const session = terminalSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ message: 'Session not found' });
  }
  
  // Try to kill the process
  try {
    if (session.pid) {
      process.kill(session.pid, 'SIGTERM');
    }
    session.finished = true;
    res.json({ message: 'Process killed' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to kill process: ' + error.message });
  }
});

// Test endpoint
app.get('/api/test', (req, res) => {
  res.json({ 
    message: 'Server is running',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// Debug endpoint
app.get('/api/debug', (req, res) => {
  res.json({
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    cwd: process.cwd(),
    env: process.env.NODE_ENV,
    pid: process.pid
  });
});

// Test upload endpoint
app.post('/api/test-upload', upload.single('file'), (req, res) => {
  console.log('Test upload request received');
  console.log('File:', req.file);
  console.log('Body:', req.body);
  
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }
  
  res.json({
    message: 'Test upload successful',
    file: {
      originalname: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype,
      path: req.file.path
    }
  });
});

// Check file system permissions
app.get('/api/check-permissions', async (req, res) => {
  try {
    const checks = {
      scriptsDir: {
        exists: await fs.pathExists(SCRIPTS_DIR),
        writable: false,
        readable: false
      },
      tempDir: {
        exists: await fs.pathExists('/tmp'),
        writable: false,
        readable: false
      },
      dbFile: {
        exists: await fs.pathExists(DB_PATH),
        writable: false,
        readable: false
      }
    };
    
    // Check permissions
    try {
      await fs.access(SCRIPTS_DIR, fs.constants.W_OK);
      checks.scriptsDir.writable = true;
    } catch (e) {
      checks.scriptsDir.writable = false;
    }
    
    try {
      await fs.access(SCRIPTS_DIR, fs.constants.R_OK);
      checks.scriptsDir.readable = true;
    } catch (e) {
      checks.scriptsDir.readable = false;
    }
    
    try {
      await fs.access('/tmp', fs.constants.W_OK);
      checks.tempDir.writable = true;
    } catch (e) {
      checks.tempDir.writable = false;
    }
    
    try {
      await fs.access('/tmp', fs.constants.R_OK);
      checks.tempDir.readable = true;
    } catch (e) {
      checks.tempDir.readable = false;
    }
    
    try {
      await fs.access(DB_PATH, fs.constants.W_OK);
      checks.dbFile.writable = true;
    } catch (e) {
      checks.dbFile.writable = false;
    }
    
    try {
      await fs.access(DB_PATH, fs.constants.R_OK);
      checks.dbFile.readable = true;
    } catch (e) {
      checks.dbFile.readable = false;
    }
    
    res.json({
      message: 'Permission check completed',
      checks: checks,
      currentUser: process.env.USER || process.env.USERNAME,
      currentDir: process.cwd()
    });
  } catch (error) {
    res.status(500).json({
      message: 'Permission check failed',
      error: error.message
    });
  }
});

// Auto install missing modules endpoint
app.post('/api/install-missing/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const scriptPath = path.join(SCRIPTS_DIR, name);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const packageJsonPath = path.join(scriptPath, 'package.json');
    if (!await fs.pathExists(packageJsonPath)) {
      return res.status(400).json({ error: 'No package.json found' });
    }
    
    console.log(`Installing missing modules for ${name}...`);
    
    const npmInstall = spawn('npm', ['install'], { 
      cwd: scriptPath,
      stdio: ['pipe', 'pipe', 'pipe']
    });
    
    let output = '', error = '';
    npmInstall.stdout.on('data', (data) => {
      output += data.toString();
      console.log('NPM stdout:', data.toString());
    });
    npmInstall.stderr.on('data', (data) => {
      error += data.toString();
      console.log('NPM stderr:', data.toString());
    });
    
    await new Promise((resolve, reject) => {
      npmInstall.on('close', (code) => {
        if (code === 0) {
          console.log(`Missing modules installed for ${name}`);
          resolve();
        } else {
          console.log(`Failed to install missing modules for ${name}`);
          reject(new Error(`NPM install failed with code: ${code}`));
        }
      });
    });
    
    res.json({ 
      success: true, 
      message: `Missing modules installed for ${name}`,
      output 
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Check missing modules endpoint
app.get('/api/check-missing/:name', async (req, res) => {
  try {
    const { name } = req.params;
    const scriptPath = path.join(SCRIPTS_DIR, name);
    
    if (!await fs.pathExists(scriptPath)) {
      return res.status(404).json({ error: 'Script not found' });
    }
    
    const packageJsonPath = path.join(scriptPath, 'package.json');
    const nodeModulesPath = path.join(scriptPath, 'node_modules');
    
    if (!await fs.pathExists(packageJsonPath)) {
      return res.json({ hasMissing: false, message: 'No package.json found' });
    }
    
    const hasMissing = !await fs.pathExists(nodeModulesPath);
    
    res.json({ 
      hasMissing,
      message: hasMissing ? 'Missing node_modules' : 'All modules installed'
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// API: Get PM2 status
app.get('/api/pm2/status', (req, res) => {
  pm2.connect((err) => {
    if (err) {
      return res.status(500).json({ message: 'PM2 connection error' });
    }
    
    pm2.list((err, list) => {
      pm2.disconnect();
      if (err) {
        return res.status(500).json({ message: 'PM2 list error' });
      }
      
      res.json({ processes: list || [] });
    });
  });
});

// API: Get script status
app.get('/api/pm2/status/:name', (req, res) => {
  const { name } = req.params;
  
  pm2.connect((err) => {
    if (err) {
      return res.status(500).json({ message: 'PM2 connection error' });
    }
    
    pm2.describe(name, (err, desc) => {
      pm2.disconnect();
      if (err || !desc || !desc[0]) {
        return res.json({ status: 'stopped' });
      }
      
      const process = desc[0];
      res.json({
        status: process.pm2_env.status,
        uptime: process.pm2_env.pm_uptime,
        memory: process.monit.memory,
        cpu: process.monit.cpu
      });
    });
  });
});

// API: Get system logs
app.get('/api/system/logs', (req, res) => {
  try {
    // For now, return empty logs since we don't have a proper logging system
    // In the future, this could read from actual log files
    res.json({
      logs: [
        {
          timestamp: new Date().toISOString(),
          level: 'info',
          message: 'System is running normally'
        },
        {
          timestamp: new Date(Date.now() - 60000).toISOString(),
          level: 'info',
          message: 'WA Panel started successfully'
        }
      ]
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to load system logs' });
  }
});

app.listen(PORT, () => {
  console.log(`WA Panel aktif di http://localhost:${PORT}`);
}); 