# 🦖 Pterodactyl NodeJS Panel

A modern, feature-rich web panel for managing Node.js applications with a beautiful Pterodactyl-inspired design. Built with Express.js, Socket.IO, and modern web technologies.

## ✨ Features

### 🎯 Core Features
- **Modern Dashboard** - Real-time statistics and application overview
- **Application Management** - Start, stop, restart, and delete Node.js applications
- **File Manager** - Browse and manage application files with drag & drop
- **Terminal Access** - Execute commands in application directories
- **Log Viewer** - Real-time application logs with filtering
- **System Monitoring** - CPU, memory, and disk usage tracking

### 🎨 UI/UX Features
- **Dark Theme** - Beautiful dark mode with Pterodactyl-inspired design
- **Responsive Design** - Works perfectly on desktop and mobile
- **Real-time Updates** - Live status updates via WebSocket
- **Smooth Animations** - Modern CSS transitions and effects
- **Intuitive Navigation** - Clean sidebar navigation

### 🔧 Technical Features
- **JWT Authentication** - Secure login system
- **PM2 Integration** - Full PM2 process management
- **File Upload** - Support for .js, .json, .zip, .tar.gz files
- **WebSocket Support** - Real-time communication
- **Rate Limiting** - API protection
- **Error Handling** - Comprehensive error management

## 🚀 Quick Start

### Prerequisites
- Node.js 16+ 
- npm 8+
- PM2 (auto-installed)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd pterodactyl-nodejs-panel
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the panel**
   ```bash
   # Development mode
   npm run dev
   
   # Production mode
   npm start
   
   # With PM2 (recommended)
   npm run pm2
   ```

4. **Access the panel**
   ```
   http://localhost:3000
   ```

### Default Credentials
- **Username**: `admin`
- **Password**: `password`

⚠️ **Important**: Change the default password in production!

## 📋 Usage Guide

### Dashboard
The dashboard provides an overview of your system:
- **Application Statistics** - Total, running, and stopped applications
- **System Resources** - CPU, memory, and disk usage
- **Recent Activity** - Latest application events
- **Quick Actions** - Start, stop, and manage applications

### Applications
Manage your Node.js applications:
1. **Upload Application** - Click "Upload Application" button
2. **Select File** - Choose .js, .json, or .zip file
3. **Enter Name** - Provide a unique application name
4. **Upload** - File will be extracted and dependencies installed

**Application Actions:**
- ▶️ **Start** - Launch the application
- ⏸️ **Stop** - Pause the application
- 🔄 **Restart** - Restart the application
- 📋 **Logs** - View application logs
- 🗑️ **Delete** - Remove the application

### File Manager
Browse and manage application files:
- **Navigate** - Click folders to explore
- **Download** - Click files to download
- **Upload** - Drag & drop files to upload
- **View** - Preview file contents

### Terminal
Execute commands in application directories:
1. **Select Application** - Choose from dropdown
2. **Enter Command** - Type your command
3. **Execute** - Press Enter to run
4. **History** - Use arrow keys to navigate command history

### Logs
View application logs:
1. **Select Application** - Choose from dropdown
2. **Set Lines** - Choose number of log lines (50-500)
3. **Refresh** - Click refresh to update logs
4. **Auto-refresh** - Logs update automatically

### System
Monitor system information:
- **Node.js Version** - Current Node.js version
- **NPM Version** - Package manager version
- **PM2 Version** - Process manager version
- **Platform** - Operating system info
- **Uptime** - System uptime

## 🔧 Configuration

### Environment Variables
Create a `.env` file in the root directory:

```env
PORT=3000
JWT_SECRET=your-super-secret-jwt-key-change-this
NODE_ENV=production
```

### PM2 Configuration
The panel uses PM2 for process management. PM2 will be installed automatically.

### File Upload Limits
- **Maximum file size**: 100MB
- **Allowed file types**: .js, .json, .zip, .tar.gz, .rar
- **Upload directory**: `backend/uploads/`

## 📁 Project Structure

```
pterodactyl-nodejs-panel/
├── backend/
│   ├── server.js          # Main server file
│   ├── uploads/           # Upload directory
│   ├── scripts/           # Application directory
│   └── logs/             # Log files
├── frontend/
│   ├── index.html         # Main HTML file
│   ├── script.js          # Frontend JavaScript
│   └── style.css          # CSS styles
├── package.json           # Dependencies
└── README.md             # This file
```

## 🔌 API Endpoints

### Authentication
- `POST /api/auth/login` - User login

### Dashboard
- `GET /api/dashboard/stats` - Dashboard statistics

### Applications
- `GET /api/applications` - List all applications
- `POST /api/applications/:name/start` - Start application
- `POST /api/applications/:name/stop` - Stop application
- `POST /api/applications/:name/restart` - Restart application
- `DELETE /api/applications/:name` - Delete application
- `GET /api/applications/:name/logs` - Get application logs

### File Management
- `GET /api/files` - List files in directory
- `POST /api/upload` - Upload file

### Terminal
- `POST /api/terminal/execute` - Execute command

### System
- `GET /api/system/info` - System information
- `GET /api/health` - Health check

## 🛠️ Development

### Available Scripts
```bash
npm start          # Start production server
npm run dev        # Start development server
npm run pm2        # Start with PM2
npm run build      # Build frontend assets
npm run test       # Run tests
npm run lint       # Lint code
npm run format     # Format code
```

### Development Mode
```bash
npm run dev
```
This will start the server with nodemon for automatic restarts.

### Building Frontend
```bash
npm run build
```
This compiles SCSS and bundles JavaScript.

## 🔒 Security Features

- **JWT Authentication** - Secure token-based authentication
- **Rate Limiting** - API request throttling
- **Helmet.js** - Security headers
- **Input Validation** - File type and size validation
- **CORS Protection** - Cross-origin request handling
- **Error Handling** - Comprehensive error management

## 🐛 Troubleshooting

### Common Issues

1. **Port 3000 already in use**
   ```bash
   # Find process using port 3000
   lsof -i :3000
   
   # Kill process
   kill -9 <PID>
   ```

2. **PM2 not found**
   ```bash
   npm install -g pm2
   ```

3. **Permission denied**
   ```bash
   chmod +x start.sh startpm2.sh
   ```

4. **Node modules not found**
   ```bash
   npm install
   ```

### Logs

- **PM2 logs**: `pm2 logs pterodactyl-panel`
- **Application logs**: Use log viewer in panel
- **System logs**: Check `/api/logs` endpoint

### Performance Issues

1. **High CPU usage**
   - Check running applications
   - Monitor system resources
   - Restart applications if needed

2. **Memory issues**
   - Monitor memory usage
   - Restart applications
   - Check for memory leaks

3. **Slow response times**
   - Check network connectivity
   - Monitor server resources
   - Review application logs

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Development Guidelines

- Follow the existing code style
- Add tests for new features
- Update documentation
- Test thoroughly before submitting

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Pterodactyl** - For the design inspiration
- **PM2** - For process management
- **Express.js** - For the web framework
- **Socket.IO** - For real-time communication
- **Tailwind CSS** - For the styling framework

## 📞 Support

If you encounter any issues or have questions:

1. Check the troubleshooting section
2. Review the logs
3. Create an issue on GitHub
4. Join our community

---

**Made with ❤️ by the Pterodactyl NodeJS Panel Team**