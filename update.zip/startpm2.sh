#!/bin/bash

# Pterodactyl NodeJS Panel - PM2 Start Script
# Modern panel for Node.js application management with PM2

echo "🦖 Pterodactyl NodeJS Panel - PM2 Mode"
echo "=========================================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}$1${NC}"
}

print_success() {
    echo -e "${GREEN}$1${NC}"
}

print_pm2() {
    echo -e "${PURPLE}[PM2]${NC} $1"
}

# Check if Node.js is installed
check_nodejs() {
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed. Please install Node.js 16+ first."
        exit 1
    fi
    
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 16 ]; then
        print_error "Node.js version 16+ is required. Current version: $(node --version)"
        exit 1
    fi
    
    print_status "Node.js version: $(node --version)"
}

# Check if npm is installed
check_npm() {
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    print_status "npm version: $(npm --version)"
}

# Install dependencies
install_dependencies() {
    print_header "Installing dependencies..."
    
    if [ ! -d "node_modules" ]; then
        print_status "Installing npm packages..."
        npm install
        
        if [ $? -eq 0 ]; then
            print_status "Dependencies installed successfully"
        else
            print_error "Failed to install dependencies"
            exit 1
        fi
    else
        print_status "Dependencies already installed"
    fi
}

# Install PM2 globally if not installed
install_pm2() {
    if ! command -v pm2 &> /dev/null; then
        print_header "Installing PM2..."
        npm install -g pm2
        
        if [ $? -eq 0 ]; then
            print_status "PM2 installed successfully"
        else
            print_warning "Failed to install PM2 globally. You may need to run with sudo."
            print_status "Trying with sudo..."
            sudo npm install -g pm2
        fi
    else
        print_status "PM2 already installed: $(pm2 --version)"
    fi
}

# Create necessary directories
create_directories() {
    print_header "Creating directories..."
    
    mkdir -p backend/uploads
    mkdir -p backend/scripts
    mkdir -p backend/logs
    
    print_status "Directories created"
}

# Check if PM2 process already exists
check_existing_process() {
    if pm2 list | grep -q "pterodactyl-panel"; then
        print_warning "Pterodactyl panel is already running in PM2"
        read -p "Do you want to restart it? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            print_pm2 "Restarting existing process..."
            pm2 restart pterodactyl-panel
            show_status
        else
            print_status "Keeping existing process running"
            show_status
            exit 0
        fi
    fi
}

# Start the application with PM2
start_with_pm2() {
    print_header "Starting Pterodactyl NodeJS Panel with PM2..."
    
    # Set environment variables
    export NODE_ENV=production
    export PORT=3000
    
    # Start with PM2
    print_pm2 "Starting server..."
    pm2 start backend/server.js --name pterodactyl-panel --time
    
    if [ $? -eq 0 ]; then
        print_success "✅ Panel started successfully with PM2!"
        print_status "Panel is running at: http://localhost:3000"
        print_status "Default credentials: admin / password"
        
        # Save PM2 configuration
        pm2 save
        
        # Setup PM2 startup script
        print_pm2 "Setting up PM2 startup script..."
        pm2 startup
        print_status "PM2 will start automatically on system boot"
        
    else
        print_error "Failed to start panel with PM2"
        exit 1
    fi
}

# Show PM2 status
show_status() {
    echo
    print_header "PM2 Status:"
    pm2 status
    
    echo
    print_header "Useful PM2 Commands:"
    echo "  pm2 status                    - Show all processes"
    echo "  pm2 logs pterodactyl-panel   - View panel logs"
    echo "  pm2 restart pterodactyl-panel - Restart panel"
    echo "  pm2 stop pterodactyl-panel   - Stop panel"
    echo "  pm2 delete pterodactyl-panel - Remove panel from PM2"
    echo "  pm2 monit                     - Monitor processes"
    echo
}

# Show panel information
show_panel_info() {
    echo
    print_header "🎉 Pterodactyl NodeJS Panel is ready!"
    echo
    print_status "📊 Dashboard: http://localhost:3000"
    print_status "🔧 API: http://localhost:3000/api"
    print_status "📋 Health: http://localhost:3000/api/health"
    echo
    print_status "Default credentials:"
    print_status "  Username: admin"
    print_status "  Password: password"
    echo
    print_warning "⚠️  Remember to change the default password in production!"
    echo
    print_status "📚 Documentation: Check README.md for detailed usage guide"
    echo
}

# Main execution
main() {
    print_header "Pterodactyl NodeJS Panel - PM2 Startup"
    echo
    
    # Check prerequisites
    check_nodejs
    check_npm
    
    # Install dependencies
    install_dependencies
    
    # Install PM2
    install_pm2
    
    # Create directories
    create_directories
    
    # Check existing process
    check_existing_process
    
    # Start with PM2
    start_with_pm2
    
    # Show status
    show_status
    
    # Show panel information
    show_panel_info
}

# Run main function
main "$@" 