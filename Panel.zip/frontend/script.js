document.addEventListener('DOMContentLoaded', () => {
  fetchScripts();
  document.getElementById('uploadForm').addEventListener('submit', uploadScript);
});

function fetchScripts() {
  fetch('/api/scripts')
    .then(res => res.json())
    .then(data => renderScripts(data));
}

function renderScripts(scripts) {
  const tbody = document.querySelector('#scriptsTable tbody');
  tbody.innerHTML = '';
  scripts.forEach(script => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${script.name}</td>
      <td>${script.command}</td>
      <td>${script.status || '-'}</td>
      <td>${script.testResult || '-'}</td>
      <td><button onclick="showLog('${script.name}')">Lihat Log</button></td>
      <td>
        <button onclick="startScript('${script.name}')">Start</button>
        <button onclick="stopScript('${script.name}')">Stop</button>
        <button onclick="restartScript('${script.name}')">Restart</button>
        <button onclick="deleteScript('${script.name}')">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function uploadScript(e) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  fetch('/api/upload', {
    method: 'POST',
    body: formData
  })
    .then(res => res.json())
    .then(data => {
      document.getElementById('uploadResult').textContent = data.message;
      fetchScripts();
    })
    .catch(err => {
      document.getElementById('uploadResult').textContent = 'Upload gagal';
    });
}

function startScript(name) {
  fetch('/api/start', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) })
    .then(res => res.json()).then(data => { alert(data.message); fetchScripts(); });
}
function stopScript(name) {
  fetch('/api/stop', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) })
    .then(res => res.json()).then(data => { alert(data.message); fetchScripts(); });
}
function restartScript(name) {
  fetch('/api/restart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) })
    .then(res => res.json()).then(data => { alert(data.message); fetchScripts(); });
}
function deleteScript(name) {
  if (!confirm('Yakin hapus script?')) return;
  fetch('/api/delete', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }) })
    .then(res => res.json()).then(data => { alert(data.message); fetchScripts(); });
}
function showLog(name) {
  fetch(`/api/log/${name}`)
    .then(res => res.json())
    .then(data => { alert(data.log); });
} 