// WA Panel - Pterodactyl Style
class WAPanel {
    constructor() {
        this.currentSection = 'dashboard';
        this.scripts = [];
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadScripts();
        this.updateDashboardStats();
        this.setupNavigation();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = e.currentTarget.getAttribute('href').substring(1);
                this.showSection(section);
            });
        });

        // Sidebar toggle
        document.querySelector('.sidebar-toggle').addEventListener('click', () => {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Upload forms
        document.getElementById('uploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.uploadScript(e.target);
        });

        document.getElementById('modalUploadForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.uploadScript(e.target);
        });

        // System update form
        document.getElementById('updateForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleSystemUpdate(e.target);
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close').forEach(btn => {
            btn.addEventListener('click', () => {
                this.hideAllModals();
            });
        });

        // Close modals on overlay click
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    this.hideAllModals();
                }
            });
        });

        // File upload styling
        document.querySelectorAll('input[type="file"]').forEach(input => {
            input.addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const label = e.target.nextElementSibling;
                    label.querySelector('span').textContent = file.name;
                }
            });
        });
    }

    setupNavigation() {
        // Set active nav item
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
                e.currentTarget.classList.add('active');
            });
        });
    }

    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('section').forEach(section => {
            section.classList.remove('active');
        });

        // Show target section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
            this.currentSection = sectionName;
        }

        // Update page title
        const pageTitle = document.querySelector('.page-title');
        switch(sectionName) {
            case 'dashboard':
                pageTitle.textContent = 'Dashboard';
                break;
            case 'scripts':
                pageTitle.textContent = 'Script Management';
                break;
            case 'upload':
                pageTitle.textContent = 'Upload Script';
                break;
            case 'logs':
                pageTitle.textContent = 'System Logs';
                break;
            case 'system':
                pageTitle.textContent = 'System Management';
                break;
        }

        // Load section-specific content
        if (sectionName === 'scripts') {
            this.renderScriptsTable();
        } else if (sectionName === 'dashboard') {
            this.updateDashboardStats();
            this.renderRecentScripts();
        } else if (sectionName === 'system') {
            this.refreshSystemStatus();
        }
    }

    async loadScripts() {
        try {
            const response = await fetch('/api/scripts');
            this.scripts = await response.json();
            this.updateDashboardStats();
            this.renderRecentScripts();
        } catch (error) {
            console.error('Failed to load scripts:', error);
        }
    }

    updateDashboardStats() {
        const running = this.scripts.filter(s => s.status === '🟢 Online').length;
        const stopped = this.scripts.filter(s => s.status === 'stopped').length;
        const tested = this.scripts.filter(s => s.testResult === '✅ OK').length;
        const errors = this.scripts.filter(s => s.testResult === '❌ ERROR').length;

        document.getElementById('runningScripts').textContent = running;
        document.getElementById('stoppedScripts').textContent = stopped;
        document.getElementById('testedScripts').textContent = tested;
        document.getElementById('errorScripts').textContent = errors;
    }

    renderRecentScripts() {
        const container = document.getElementById('recentScriptsList');
        const recentScripts = this.scripts.slice(0, 5); // Show last 5 scripts

        if (recentScripts.length === 0) {
            container.innerHTML = '<p style="color: #9ca3af; text-align: center; padding: 2rem;">No scripts uploaded yet</p>';
            return;
        }

        container.innerHTML = recentScripts.map(script => `
            <div class="script-item">
                <div>
                    <div style="font-weight: 600; color: #f3f4f6;">${script.name}</div>
                    <div style="font-size: 0.875rem; color: #9ca3af;">${script.command}</div>
                </div>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                    <div class="action-buttons">
                        <button class="btn-sm btn-info" onclick="waPanel.showLog('${script.name}')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderScriptsTable() {
        const tbody = document.querySelector('#scriptsTable tbody');
        
        if (this.scripts.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #9ca3af;">No scripts found</td></tr>';
            return;
        }

        tbody.innerHTML = this.scripts.map(script => `
            <tr>
                <td>
                    <div style="font-weight: 600; color: #f3f4f6;">${script.name}</div>
                    <div style="font-size: 0.75rem; color: #9ca3af;">${script.folder}</div>
                </td>
                <td style="font-family: monospace; font-size: 0.875rem;">${script.command}</td>
                <td>
                    <span class="status-badge ${this.getStatusClass(script.status)}">${script.status}</span>
                </td>
                <td>
                    <span class="status-badge ${script.testResult === '✅ OK' ? 'running' : 'error'}">${script.testResult}</span>
                </td>
                <td style="font-size: 0.875rem; color: #9ca3af;">Just now</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-sm btn-success" onclick="waPanel.startScript('${script.name}')" title="Start">
                            <i class="fas fa-play"></i>
                        </button>
                        <button class="btn-sm btn-warning" onclick="waPanel.stopScript('${script.name}')" title="Stop">
                            <i class="fas fa-pause"></i>
                        </button>
                        <button class="btn-sm btn-info" onclick="waPanel.restartScript('${script.name}')" title="Restart">
                            <i class="fas fa-redo"></i>
                        </button>
                        <button class="btn-sm btn-info" onclick="waPanel.showLog('${script.name}')" title="View Log">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-sm btn-danger" onclick="waPanel.deleteScript('${script.name}')" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    getStatusClass(status) {
        if (status === '🟢 Online') return 'running';
        if (status === 'stopped') return 'stopped';
        return 'error';
    }

    async uploadScript(form) {
        const formData = new FormData(form);
        const resultDiv = form.id === 'modalUploadForm' ? 
            document.getElementById('modalUploadResult') : 
            document.getElementById('uploadResult');

        try {
            resultDiv.textContent = 'Uploading...';
            resultDiv.className = 'upload-result';

            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();
            
            if (response.ok) {
                resultDiv.textContent = result.message;
                resultDiv.className = 'upload-result success';
                form.reset();
                this.loadScripts();
                
                if (form.id === 'modalUploadForm') {
                    setTimeout(() => this.hideUploadModal(), 2000);
                }
            } else {
                resultDiv.textContent = result.message || 'Upload failed';
                resultDiv.className = 'upload-result error';
            }
        } catch (error) {
            resultDiv.textContent = 'Upload failed: ' + error.message;
            resultDiv.className = 'upload-result error';
        }
    }

    async startScript(name) {
        try {
            const response = await fetch('/api/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to start script', 'error');
        }
    }

    async stopScript(name) {
        try {
            const response = await fetch('/api/stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to stop script', 'error');
        }
    }

    async restartScript(name) {
        try {
            const response = await fetch('/api/restart', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to restart script', 'error');
        }
    }

    async deleteScript(name) {
        if (!confirm('Are you sure you want to delete this script?')) return;
        
        try {
            const response = await fetch('/api/delete', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name })
            });
            const result = await response.json();
            this.showNotification(result.message, response.ok ? 'success' : 'error');
            this.loadScripts();
        } catch (error) {
            this.showNotification('Failed to delete script', 'error');
        }
    }

    async showLog(name) {
        try {
            const response = await fetch(`/api/log/${name}`);
            const result = await response.json();
            
            document.getElementById('logContent').textContent = result.log || 'No logs available';
            this.showModal('logModal');
        } catch (error) {
            this.showNotification('Failed to load logs', 'error');
        }
    }

    showUploadModal() {
        this.showModal('uploadModal');
    }

    hideUploadModal() {
        this.hideModal('uploadModal');
    }

    hideLogModal() {
        this.hideModal('logModal');
    }

    showModal(modalId) {
        document.getElementById(modalId).classList.add('active');
    }

    hideModal(modalId) {
        document.getElementById(modalId).classList.remove('active');
    }

    hideAllModals() {
        document.querySelectorAll('.modal-overlay').forEach(modal => {
            modal.classList.remove('active');
        });
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            color: white;
            font-weight: 500;
            z-index: 3000;
            animation: slideIn 0.3s ease;
            ${type === 'success' ? 'background: #10b981;' : 'background: #ef4444;'}
        `;

        document.body.appendChild(notification);

        // Remove after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    refreshAll() {
        this.loadScripts();
        this.showNotification('Refreshed all data', 'success');
    }

    async refreshSystemStatus() {
        try {
            const response = await fetch('/api/update-status');
            const status = await response.json();
            
            document.getElementById('systemVersion').textContent = status.version;
            document.getElementById('systemUptime').textContent = this.formatUptime(status.serverUptime);
            document.getElementById('lastUpdate').textContent = new Date(status.lastUpdate).toLocaleString();
            
            this.showNotification('System status refreshed', 'success');
        } catch (error) {
            this.showNotification('Failed to refresh system status', 'error');
        }
    }

    async handleSystemUpdate(form) {
        const formData = new FormData(form);
        const resultDiv = document.getElementById('updateResult');
        
        try {
            resultDiv.textContent = 'Applying update...';
            resultDiv.className = 'update-result warning';
            
            const response = await fetch('/api/self-update', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (response.ok) {
                resultDiv.textContent = result.message;
                resultDiv.className = 'update-result success';
                form.reset();
                
                // Show countdown for restart
                let countdown = 3;
                const countdownInterval = setInterval(() => {
                    resultDiv.textContent = `Update applied! Server restarting in ${countdown} seconds...`;
                    countdown--;
                    if (countdown < 0) {
                        clearInterval(countdownInterval);
                        resultDiv.textContent = 'Server is restarting... Please wait and refresh the page.';
                    }
                }, 1000);
                
                // Auto refresh after 5 seconds
                setTimeout(() => {
                    window.location.reload();
                }, 5000);
            } else {
                resultDiv.textContent = result.message || 'Update failed';
                resultDiv.className = 'update-result error';
            }
        } catch (error) {
            resultDiv.textContent = 'Update failed: ' + error.message;
            resultDiv.className = 'update-result error';
        }
    }

    formatUptime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);
        
        if (hours > 0) {
            return `${hours}h ${minutes}m ${secs}s`;
        } else if (minutes > 0) {
            return `${minutes}m ${secs}s`;
        } else {
            return `${secs}s`;
        }
    }
}

// Initialize the panel when DOM is loaded
let waPanel;
document.addEventListener('DOMContentLoaded', () => {
    waPanel = new WAPanel();
});

// Global functions for onclick handlers
function showUploadModal() {
    waPanel.showUploadModal();
}

function hideUploadModal() {
    waPanel.hideUploadModal();
}

function hideLogModal() {
    waPanel.hideLogModal();
}

function refreshAll() {
    waPanel.refreshAll();
} 