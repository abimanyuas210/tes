#!/bin/bash

# WA Panel - PM2 Start Script
echo "🚀 Starting WA Panel with PM2..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

# Navigate to project directory
cd "$(dirname "$0")"

# Check if package.json exists
if [ ! -f "package.json" ]; then
    echo "❌ package.json not found. Please run this script from the project root."
    exit 1
fi

# Install PM2 globally if not installed
if ! command -v pm2 &> /dev/null; then
    echo "📦 Installing PM2 globally..."
    npm install -g pm2
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install PM2."
        exit 1
    fi
fi

# Install dependencies if node_modules doesn't exist
if [ ! -d "node_modules" ]; then
    echo "📦 Installing dependencies..."
    npm install
    if [ $? -ne 0 ]; then
        echo "❌ Failed to install dependencies."
        exit 1
    fi
fi

# Check if backend directory exists
if [ ! -d "backend" ]; then
    echo "❌ Backend directory not found."
    exit 1
fi

# Check if server.js exists
if [ ! -f "backend/server.js" ]; then
    echo "❌ server.js not found in backend directory."
    exit 1
fi

# Stop existing PM2 process if running
echo "🛑 Stopping existing PM2 processes..."
pm2 delete wa-panel 2>/dev/null || true

# Start the server with PM2
echo "🌐 Starting WA Panel with PM2..."
pm2 start backend/server.js --name "wa-panel" --watch

# Show status
echo ""
echo "📊 PM2 Status:"
pm2 status

echo ""
echo "📱 Access the panel at: http://localhost:3000"
echo "📋 PM2 Commands:"
echo "   pm2 logs wa-panel     - View logs"
echo "   pm2 restart wa-panel  - Restart panel"
echo "   pm2 stop wa-panel     - Stop panel"
echo "   pm2 delete wa-panel   - Delete panel process"
echo "" 