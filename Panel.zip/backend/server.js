const express = require('express');
const cors = require('cors');
const fs = require('fs-extra');
const path = require('path');
const multer = require('multer');
const { spawn } = require('child_process');
const unzipper = require('unzipper');
const pm2 = require('pm2');
const { exec } = require('child_process');

const app = express();
const PORT = 3000;

const SCRIPTS_DIR = path.join(__dirname, 'scripts');
const DB_PATH = path.join(__dirname, 'db.json');

fs.ensureDirSync(SCRIPTS_DIR);

const upload = multer({ 
  dest: '/tmp',
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
    files: 1
  }
});

// Terminal session storage
const terminalSessions = new Map();

app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Helper: update status dari pm2 list
async function updatePM2Status() {
  return new Promise((resolve) => {
    pm2.connect((err) => {
      if (err) return resolve();
      pm2.list((err, list) => {
        let db = [];
        try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
        db.forEach(script => {
          const found = list.find(proc => proc.name === script.name);
          if (found) {
            script.status = found.pm2_env.status === 'online' ? '🟢 Online' : '🔴 Offline';
          } else {
            script.status = 'stopped';
          }
        });
        fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
        pm2.disconnect();
        resolve();
      });
    });
  });
}

// API: Get all scripts (with PM2 status)
app.get('/api/scripts', async (req, res) => {
  await updatePM2Status();
  let db = [];
  try {
    db = fs.readJsonSync(DB_PATH);
  } catch (e) {}
  res.json(db);
});

// API: Upload script
app.post('/api/upload', upload.single('file'), async (req, res) => {
  console.log('Script upload request received');
  console.log('Request body:', req.body);
  console.log('Request file:', req.file);
  
  const { name, command } = req.body;
  const file = req.file;
  
  if (!name || !command || !file) {
    console.log('Missing required fields:', { name, command, file: !!file });
    return res.status(400).json({ message: 'Lengkapi semua field!' });
  }
  
  console.log('Processing upload for:', name, 'Command:', command, 'File:', file.originalname);
  
  const folder = name.replace(/[^a-zA-Z0-9_-]/g, '_');
  const scriptPath = path.join(SCRIPTS_DIR, folder);
  
  try {
    await fs.ensureDir(scriptPath);
    console.log('Script directory created:', scriptPath);
    
    let entryFile = '';
    
    if (file.originalname.endsWith('.zip')) {
      console.log('Processing ZIP file...');
      // Ekstrak zip
      const extractStream = fs.createReadStream(file.path).pipe(unzipper.Extract({ path: scriptPath }));
      await new Promise((resolve, reject) => {
        extractStream.on('close', resolve);
        extractStream.on('error', reject);
      });
      console.log('ZIP extracted successfully');
      entryFile = path.join(scriptPath, 'index.js');
    } else if (file.originalname.endsWith('.js')) {
      console.log('Processing JS file...');
      entryFile = path.join(scriptPath, 'index.js');
      await fs.move(file.path, entryFile, { overwrite: true });
      console.log('JS file moved successfully');
    } else {
      console.log('Invalid file type:', file.originalname);
      return res.status(400).json({ message: 'File harus .js atau .zip' });
    }
    
    console.log('Testing script with command:', command);
    // Uji coba script (tanpa PM2)
    const [cmd, ...args] = command.split(' ');
    const testProc = spawn(cmd, args, { cwd: scriptPath });
    let stdout = '', stderr = '';
    let finished = false;
    
    const timeout = setTimeout(() => {
      if (!finished) {
        console.log('Test timeout reached, killing process');
        testProc.kill('SIGKILL');
        finished = true;
      }
    }, 10000);
    
    testProc.stdout.on('data', d => { 
      stdout += d.toString(); 
      console.log('Test stdout:', d.toString());
    });
    testProc.stderr.on('data', d => { 
      stderr += d.toString(); 
      console.log('Test stderr:', d.toString());
    });
    
    testProc.on('close', code => {
      clearTimeout(timeout);
      if (finished) return;
      finished = true;
      
      console.log('Test process closed with code:', code);
      
      let db = [];
      try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
      let testResult = '', lastError = '';
      
      if (code === 0) {
        testResult = '✅ OK';
        lastError = '';
        console.log('Test passed');
      } else {
        testResult = '❌ ERROR';
        lastError = stderr || stdout || 'Unknown error';
        console.log('Test failed:', lastError);
      }
      
      const scriptData = {
        name,
        folder,
        command,
        status: 'stopped',
        testResult,
        lastError
      };
      
      db = db.filter(s => s.name !== name);
      db.push(scriptData);
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      
      if (testResult === '✅ OK') {
        res.json({ message: 'Upload & test berhasil!' });
      } else {
        res.json({ message: 'Test gagal: ' + lastError });
      }
    });
    
  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ message: 'Gagal upload: ' + err.message });
  }
});

// API: Start script
app.post('/api/start', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.start({
      name: script.name,
      script: script.command.split(' ')[0],
      args: script.command.split(' ').slice(1),
      cwd: path.join(SCRIPTS_DIR, script.folder)
    }, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal start: ' + err.message });
      script.status = '🟢 Online';
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      res.json({ message: 'Script dijalankan!' });
    });
  });
});

// API: Stop script
app.post('/api/stop', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.stop(name, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal stop: ' + err.message });
      script.status = 'stopped';
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      res.json({ message: 'Script distop!' });
    });
  });
});

// API: Restart script
app.post('/api/restart', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.restart(name, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal restart: ' + err.message });
      script.status = '🟢 Online';
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      res.json({ message: 'Script direstart!' });
    });
  });
});

// API: Delete script
app.post('/api/delete', (req, res) => {
  const { name } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.delete(name, (err) => {
      pm2.disconnect();
      if (err) return res.status(500).json({ message: 'Gagal delete: ' + err.message });
      // Hapus dari db dan folder
      db = db.filter(s => s.name !== name);
      fs.writeJsonSync(DB_PATH, db, { spaces: 2 });
      fs.removeSync(path.join(SCRIPTS_DIR, script.folder));
      res.json({ message: 'Script dihapus!' });
    });
  });
});

// API: Get last log/error
app.get('/api/log/:name', (req, res) => {
  const { name } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  // Cek log/error dari PM2
  pm2.connect((err) => {
    if (err) return res.status(500).json({ message: 'PM2 error' });
    pm2.describe(name, (err, desc) => {
      pm2.disconnect();
      if (err || !desc || !desc[0]) return res.json({ log: script.lastError || '-' });
      const out = desc[0].pm2_env.pm_out_log_path;
      const errLog = desc[0].pm2_env.pm_err_log_path;
      let log = '';
      try {
        log = fs.readFileSync(errLog, 'utf8').split('\n').slice(-10).join('\n');
      } catch (e) {}
      res.json({ log: log || script.lastError || '-' });
    });
  });
});

// Self Update endpoint
app.post('/api/self-update', upload.single('update'), async (req, res) => {
  console.log('Self update request received');
  
  const file = req.file;
  if (!file) {
    console.log('No file provided');
    return res.status(400).json({ message: 'No update file provided' });
  }

  console.log('File received:', file.originalname, 'Size:', file.size);

  if (!file.originalname.endsWith('.zip')) {
    console.log('Invalid file type:', file.originalname);
    return res.status(400).json({ message: 'Update file must be a ZIP file' });
  }

  if (file.size === 0) {
    console.log('Empty file received');
    return res.status(400).json({ message: 'Update file is empty' });
  }

  const updateDir = path.join(__dirname, '../temp_update');
  const backupDir = path.join(__dirname, '../backup_' + Date.now());
  const projectRoot = path.join(__dirname, '..');

  console.log('Paths:', { updateDir, backupDir, projectRoot });

  try {
    // Create backup
    console.log('Creating backup...');
    await fs.ensureDir(backupDir);
    await fs.copy(projectRoot, backupDir);
    console.log('Backup created successfully');
    
    // Extract update
    console.log('Extracting update...');
    await fs.ensureDir(updateDir);
    await fs.emptyDir(updateDir); // Clear directory first
    
    const extractStream = fs.createReadStream(file.path).pipe(unzipper.Extract({ path: updateDir }));
    await new Promise((resolve, reject) => {
      extractStream.on('close', resolve);
      extractStream.on('error', reject);
    });
    console.log('Update extracted successfully');
    
    // Find the main project folder in extracted files
    const extractedFiles = await fs.readdir(updateDir);
    console.log('Extracted files:', extractedFiles);
    
    let sourceDir = updateDir;
    
    // If there's a single folder, use it as source
    if (extractedFiles.length === 1) {
      const firstItem = path.join(updateDir, extractedFiles[0]);
      const stat = await fs.stat(firstItem);
      if (stat.isDirectory()) {
        sourceDir = firstItem;
        console.log('Using single directory as source:', sourceDir);
      }
    }
    
    // Copy files to project root (excluding node_modules and sensitive files)
    console.log('Applying update...');
    const filesToCopy = await fs.readdir(sourceDir);
    console.log('Files to copy:', filesToCopy);
    
    for (const item of filesToCopy) {
      const sourcePath = path.join(sourceDir, item);
      const targetPath = path.join(projectRoot, item);
      
      // Skip sensitive files and directories
      if (['node_modules', '.git', 'backup_', 'temp_update', 'package-lock.json'].some(skip => item.includes(skip))) {
        console.log('Skipping:', item);
        continue;
      }
      
      const stat = await fs.stat(sourcePath);
      if (stat.isDirectory()) {
        console.log('Copying directory:', item);
        await fs.copy(sourcePath, targetPath, { overwrite: true });
      } else {
        console.log('Copying file:', item);
        await fs.copy(sourcePath, targetPath);
      }
    }
    
    // Clean up
    console.log('Cleaning up...');
    await fs.remove(updateDir);
    await fs.remove(file.path);
    console.log('Cleanup completed');
    
    console.log('Update applied successfully');
    res.json({ 
      message: 'Update applied successfully! Server will restart in 3 seconds...',
      backupLocation: backupDir
    });
    
    // Restart server after 3 seconds
    setTimeout(() => {
      console.log('Restarting server...');
      process.exit(0);
    }, 3000);
    
  } catch (error) {
    console.error('Update failed:', error);
    
    // Try to restore from backup
    try {
      if (await fs.pathExists(backupDir)) {
        console.log('Restoring from backup...');
        await fs.copy(backupDir, projectRoot, { overwrite: true });
        await fs.remove(backupDir);
        console.log('Restore completed');
      }
    } catch (restoreError) {
      console.error('Failed to restore from backup:', restoreError);
    }
    
    // Clean up temp files
    try {
      if (await fs.pathExists(updateDir)) {
        await fs.remove(updateDir);
      }
      if (file && await fs.pathExists(file.path)) {
        await fs.remove(file.path);
      }
    } catch (cleanupError) {
      console.error('Failed to cleanup temp files:', cleanupError);
    }
    
    res.status(500).json({ 
      message: 'Update failed: ' + error.message,
      error: error.message,
      stack: error.stack
    });
  }
});

// Get update status
app.get('/api/update-status', (req, res) => {
  const packageJson = require('../package.json');
  res.json({
    version: packageJson.version || '1.0.0',
    lastUpdate: new Date().toISOString(),
    serverUptime: process.uptime()
  });
});

// Execute command in terminal with real-time output
app.post('/api/terminal/execute', (req, res) => {
  const { name, command } = req.body;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const scriptPath = path.join(SCRIPTS_DIR, script.folder);
  const sessionId = `${name}_${Date.now()}`;
  
  // Parse command
  const [cmd, ...args] = command.split(' ');
  const process = spawn(cmd, args, { 
    cwd: scriptPath,
    stdio: ['pipe', 'pipe', 'pipe']
  });
  
  let output = '';
  let error = '';
  
  process.stdout.on('data', (data) => {
    output += data.toString();
    // Send to connected clients via WebSocket if available
  });
  
  process.stderr.on('data', (data) => {
    error += data.toString();
  });
  
  process.on('close', (code) => {
    terminalSessions.set(sessionId, {
      output: output,
      error: error,
      exitCode: code,
      finished: true
    });
  });
  
  res.json({ 
    sessionId: sessionId,
    message: 'Command started',
    pid: process.pid
  });
});

// Get terminal output
app.get('/api/terminal/output/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const session = terminalSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ message: 'Session not found' });
  }
  
  res.json(session);
});

// List files in script directory
app.get('/api/script/files/:name', (req, res) => {
  const { name } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const scriptPath = path.join(SCRIPTS_DIR, script.folder);
  
  try {
    const files = fs.readdirSync(scriptPath, { withFileTypes: true });
    const fileList = files.map(file => ({
      name: file.name,
      type: file.isDirectory() ? 'directory' : 'file',
      size: file.isFile() ? fs.statSync(path.join(scriptPath, file.name)).size : 0
    }));
    
    res.json({ files: fileList });
  } catch (error) {
    res.status(500).json({ message: 'Failed to read files: ' + error.message });
  }
});

// Get file content
app.get('/api/script/file/:name/:filename', (req, res) => {
  const { name, filename } = req.params;
  let db = [];
  try { db = fs.readJsonSync(DB_PATH); } catch (e) {}
  const script = db.find(s => s.name === name);
  if (!script) return res.status(404).json({ message: 'Script tidak ditemukan' });
  
  const filePath = path.join(SCRIPTS_DIR, script.folder, filename);
  
  try {
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'File not found' });
    }
    
    const content = fs.readFileSync(filePath, 'utf8');
    const stats = fs.statSync(filePath);
    
    res.json({
      content: content,
      size: stats.size,
      modified: stats.mtime,
      filename: filename
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to read file: ' + error.message });
  }
});

// Kill terminal process
app.post('/api/terminal/kill/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  const session = terminalSessions.get(sessionId);
  
  if (!session) {
    return res.status(404).json({ message: 'Session not found' });
  }
  
  // Try to kill the process
  try {
    if (session.pid) {
      process.kill(session.pid, 'SIGTERM');
    }
    session.finished = true;
    res.json({ message: 'Process killed' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to kill process: ' + error.message });
  }
});

// Test endpoint
app.get('/api/test', (req, res) => {
  res.json({ 
    message: 'Server is running',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage()
  });
});

// Debug endpoint
app.get('/api/debug', (req, res) => {
  res.json({
    nodeVersion: process.version,
    platform: process.platform,
    arch: process.arch,
    cwd: process.cwd(),
    env: process.env.NODE_ENV,
    pid: process.pid
  });
});

// Test upload endpoint
app.post('/api/test-upload', upload.single('file'), (req, res) => {
  console.log('Test upload request received');
  console.log('File:', req.file);
  console.log('Body:', req.body);
  
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }
  
  res.json({
    message: 'Test upload successful',
    file: {
      originalname: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype,
      path: req.file.path
    }
  });
});

// Check file system permissions
app.get('/api/check-permissions', async (req, res) => {
  try {
    const checks = {
      scriptsDir: {
        exists: await fs.pathExists(SCRIPTS_DIR),
        writable: false,
        readable: false
      },
      tempDir: {
        exists: await fs.pathExists('/tmp'),
        writable: false,
        readable: false
      },
      dbFile: {
        exists: await fs.pathExists(DB_PATH),
        writable: false,
        readable: false
      }
    };
    
    // Check permissions
    try {
      await fs.access(SCRIPTS_DIR, fs.constants.W_OK);
      checks.scriptsDir.writable = true;
    } catch (e) {
      checks.scriptsDir.writable = false;
    }
    
    try {
      await fs.access(SCRIPTS_DIR, fs.constants.R_OK);
      checks.scriptsDir.readable = true;
    } catch (e) {
      checks.scriptsDir.readable = false;
    }
    
    try {
      await fs.access('/tmp', fs.constants.W_OK);
      checks.tempDir.writable = true;
    } catch (e) {
      checks.tempDir.writable = false;
    }
    
    try {
      await fs.access('/tmp', fs.constants.R_OK);
      checks.tempDir.readable = true;
    } catch (e) {
      checks.tempDir.readable = false;
    }
    
    try {
      await fs.access(DB_PATH, fs.constants.W_OK);
      checks.dbFile.writable = true;
    } catch (e) {
      checks.dbFile.writable = false;
    }
    
    try {
      await fs.access(DB_PATH, fs.constants.R_OK);
      checks.dbFile.readable = true;
    } catch (e) {
      checks.dbFile.readable = false;
    }
    
    res.json({
      message: 'Permission check completed',
      checks: checks,
      currentUser: process.env.USER || process.env.USERNAME,
      currentDir: process.cwd()
    });
  } catch (error) {
    res.status(500).json({
      message: 'Permission check failed',
      error: error.message
    });
  }
});

app.listen(PORT, () => {
  console.log(`WA Panel aktif di http://localhost:${PORT}`);
}); 