#!/bin/bash

# Pterodactyl NodeJS Panel - Start Script
# Modern panel for Node.js application management

echo "🦖 Pterodactyl NodeJS Panel"
echo "================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "${BLUE}$1${NC}"
}

# Check if Node.js is installed
check_nodejs() {
    if ! command -v node &> /dev/null; then
        print_error "Node.js is not installed. Please install Node.js 16+ first."
        exit 1
    fi
    
    NODE_VERSION=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 16 ]; then
        print_error "Node.js version 16+ is required. Current version: $(node --version)"
        exit 1
    fi
    
    print_status "Node.js version: $(node --version)"
}

# Check if npm is installed
check_npm() {
    if ! command -v npm &> /dev/null; then
        print_error "npm is not installed. Please install npm first."
        exit 1
    fi
    
    print_status "npm version: $(npm --version)"
}

# Install dependencies
install_dependencies() {
    print_header "Installing dependencies..."
    
    if [ ! -d "node_modules" ]; then
        print_status "Installing npm packages..."
        npm install
        
        if [ $? -eq 0 ]; then
            print_status "Dependencies installed successfully"
        else
            print_error "Failed to install dependencies"
            exit 1
        fi
    else
        print_status "Dependencies already installed"
    fi
}

# Install PM2 globally if not installed
install_pm2() {
    if ! command -v pm2 &> /dev/null; then
        print_header "Installing PM2..."
        npm install -g pm2
        
        if [ $? -eq 0 ]; then
            print_status "PM2 installed successfully"
        else
            print_warning "Failed to install PM2 globally. You may need to run with sudo."
            print_status "Trying with sudo..."
            sudo npm install -g pm2
        fi
    else
        print_status "PM2 already installed: $(pm2 --version)"
    fi
}

# Create necessary directories
create_directories() {
    print_header "Creating directories..."
    
    mkdir -p backend/uploads
    mkdir -p backend/scripts
    mkdir -p backend/logs
    
    print_status "Directories created"
}

# Check if port 3000 is available
check_port() {
    if lsof -Pi :3000 -sTCP:LISTEN -t >/dev/null ; then
        print_warning "Port 3000 is already in use"
        read -p "Do you want to kill the process using port 3000? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            PID=$(lsof -ti:3000)
            kill -9 $PID
            print_status "Process killed"
        else
            print_error "Please free port 3000 or change the port in the configuration"
            exit 1
        fi
    fi
}

# Start the application
start_application() {
    print_header "Starting Pterodactyl NodeJS Panel..."
    
    # Set environment variables
    export NODE_ENV=production
    export PORT=3000
    
    # Start the application
    print_status "Starting server..."
    node backend/server.js &
    SERVER_PID=$!
    
    # Wait a moment for server to start
    sleep 3
    
    # Check if server started successfully
    if kill -0 $SERVER_PID 2>/dev/null; then
        print_status "Server started successfully (PID: $SERVER_PID)"
        print_status "Panel is running at: http://localhost:3000"
        print_status "Press Ctrl+C to stop the server"
        
        # Wait for interrupt signal
        trap 'cleanup' INT
        wait $SERVER_PID
    else
        print_error "Failed to start server"
        exit 1
    fi
}

# Cleanup function
cleanup() {
    print_header "Stopping server..."
    
    if [ ! -z "$SERVER_PID" ]; then
        kill $SERVER_PID 2>/dev/null
        print_status "Server stopped"
    fi
    
    print_status "Goodbye! 👋"
    exit 0
}

# Main execution
main() {
    print_header "Pterodactyl NodeJS Panel - Startup"
    echo
    
    # Check prerequisites
    check_nodejs
    check_npm
    
    # Install dependencies
    install_dependencies
    
    # Install PM2
    install_pm2
    
    # Create directories
    create_directories
    
    # Check port availability
    check_port
    
    # Start application
    start_application
}

# Run main function
main "$@" 