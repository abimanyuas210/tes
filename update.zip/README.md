# WA Panel - Script Management System

A modern, responsive web panel for managing WhatsApp scripts with PM2 integration, file upload, terminal access, and system monitoring.

## 🚀 Features

- **📊 Dashboard** - Real-time statistics and recent scripts
- **🤖 Script Management** - Start, stop, restart, delete scripts
- **📤 Upload System** - Upload .zip and .js files with progress tracking
- **💻 Terminal Access** - Execute commands per script directory
- **📁 File Viewer** - Browse and manage script files
- **📋 Log Viewer** - View and refresh script logs
- **⚙️ System Management** - Monitor system status and update panel
- **📱 Responsive Design** - Works on desktop and mobile
- **🎨 Modern UI** - Dark theme with smooth animations

## 📋 Requirements

- Node.js 14+ 
- npm or yarn
- PM2 (auto-installed)
- Unzip utility

## 🛠️ Installation

### Quick Start

1. **Clone or download the project**
   ```bash
   git clone <repository-url>
   cd wa-panel
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the panel**
   ```bash
   # Normal start
   ./start.sh
   
   # Or with PM2 (recommended)
   ./startpm2.sh
   ```

4. **Access the panel**
   ```
   http://localhost:3000
   ```

### Manual Installation

1. **Install Node.js and npm**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install nodejs npm -y
   
   # Or download from https://nodejs.org/
   ```

2. **Install PM2 globally**
   ```bash
   npm install -g pm2
   ```

3. **Install project dependencies**
   ```bash
   npm install
   ```

4. **Start the server**
   ```bash
   node backend/server.js
   ```

## 🎯 Usage

### Starting the Panel

```bash
# Normal start
./start.sh

# With PM2 (recommended for production)
./startpm2.sh

# Manual start
node backend/server.js
```

### PM2 Commands

```bash
# View status
pm2 status

# View logs
pm2 logs wa-panel

# Restart panel
pm2 restart wa-panel

# Stop panel
pm2 stop wa-panel

# Delete panel process
pm2 delete wa-panel
```

### External Access with Ngrok

```bash
# Install ngrok
npm install -g ngrok

# Start panel
./startpm2.sh

# In another terminal, start ngrok
ngrok http 3000
```

## 📁 Project Structure

```
wa-panel/
├── backend/
│   ├── server.js          # Main server file
│   ├── scripts/           # Uploaded scripts directory
│   └── db.json           # Database file
├── frontend/
│   ├── index.html         # Main HTML file
│   └── script.js          # Frontend JavaScript
├── start.sh              # Normal start script
├── startpm2.sh           # PM2 start script
├── ngrok.sh              # Ngrok setup script
└── package.json          # Dependencies
```

## 🔧 API Endpoints

### Script Management
- `GET /api/scripts` - Get all scripts
- `POST /api/upload` - Upload script file
- `POST /api/pm2/start/:name` - Start script
- `POST /api/pm2/stop/:name` - Stop script
- `POST /api/pm2/restart/:name` - Restart script
- `DELETE /api/pm2/delete/:name` - Delete script
- `GET /api/pm2/logs/:name` - Get script logs

### Script Execution
- `POST /api/script/execute` - Execute command in script directory
- `GET /api/script/info/:name` - Get script file info
- `POST /api/script/install/:name` - Install modules for script

### System Management
- `GET /api/logs` - Get system logs
- `GET /api/system/status` - Get system status
- `POST /api/update` - Update panel system

## 🎨 UI Features

### Dashboard
- Real-time script statistics
- Recent scripts with quick actions
- System status overview

### Script Management
- Table view with all scripts
- Status badges (running, stopped, error)
- Action buttons for each script
- Bulk operations

### Upload System
- Drag & drop file upload
- Progress tracking with steps
- Real-time upload logs
- Auto-install modules

### Terminal Access
- Command execution per script
- Real-time output display
- Command history
- Copy output to clipboard

### File Viewer
- Browse script files
- File size and type info
- File content preview
- Download files

## 🔒 Security Features

- File type validation
- Directory traversal protection
- Error handling and logging
- Input sanitization
- Secure file uploads

## 🐛 Troubleshooting

### Common Issues

1. **Port 3000 already in use**
   ```bash
   # Find process using port 3000
   lsof -i :3000
   
   # Kill process
   kill -9 <PID>
   ```

2. **PM2 not found**
   ```bash
   npm install -g pm2
   ```

3. **Permission denied**
   ```bash
   chmod +x start.sh startpm2.sh
   ```

4. **Node modules not found**
   ```bash
   npm install
   ```

### Logs

- **PM2 logs**: `pm2 logs wa-panel`
- **System logs**: Check `/api/logs` endpoint
- **Script logs**: Use log viewer in panel

## 📝 License

MIT License - see LICENSE file for details

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Support

For issues and questions:
- Create an issue on GitHub
- Check the troubleshooting section
- Review the logs for error details

---

**Made with ❤️ for WhatsApp script management**